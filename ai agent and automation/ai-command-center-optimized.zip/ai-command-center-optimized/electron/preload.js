const { contextBridge, ipcRenderer } = require('electron');

// Minimal, explicit surface. The renderer never sees raw API keys:
// it asks main to save/remove/test them, and asks main to make the
// actual provider HTTP call (provider:call) so the key never has to
// pass through renderer JS/DOM.
contextBridge.exposeInMainWorld('bridge', {
  creds: {
    save: (providerId, key) => ipcRenderer.invoke('creds:save', { providerId, key }),
    status: () => ipcRenderer.invoke('creds:status'),
    remove: (providerId) => ipcRenderer.invoke('creds:remove', { providerId }),
    hasKey: (providerId) => ipcRenderer.invoke('creds:hasKey', { providerId })
  },
  provider: {
    call: (args) => ipcRenderer.invoke('provider:call', args),
    test: (providerId) => ipcRenderer.invoke('provider:test', { providerId })
  },
  ollama: {
    list: () => ipcRenderer.invoke('ollama:list'),
    chat: (model, messages, requestId) => ipcRenderer.invoke('ollama:chat', { model, messages, requestId })
  },
  request: {
    cancel: (requestId) => ipcRenderer.invoke('request:cancel', requestId)
  },
  system: {
    hardwareProfile: () => ipcRenderer.invoke('system:hardwareProfile')
  },
  config: {
    get: (key) => ipcRenderer.invoke('config:get', key),
    set: (key, value) => ipcRenderer.invoke('config:set', { key, value })
  },
  workspace: {
    select: () => ipcRenderer.invoke('workspace:select'),
    current: () => ipcRenderer.invoke('workspace:current')
  },
  tools: {
    execute: (name, args) => ipcRenderer.invoke('tools:execute', { name, args })
  },
  security: {
    scanSecrets: () => ipcRenderer.invoke('security:scanSecrets'),
    scanDependencies: () => ipcRenderer.invoke('security:scanDependencies'),
    scanNetwork: () => ipcRenderer.invoke('security:scanNetwork'),
    getLockdown: () => ipcRenderer.invoke('security:getLockdown'),
    setLockdown: (enabled) => ipcRenderer.invoke('security:setLockdown', enabled),
    getStopAll: () => ipcRenderer.invoke('security:getStopAll'),
    setStopAll: (enabled) => ipcRenderer.invoke('security:setStopAll', enabled),
    auditAppend: (entry) => ipcRenderer.invoke('security:auditAppend', entry),
    auditGet: () => ipcRenderer.invoke('security:auditGet')
  },
  mcp: {
    connect: (conn) => ipcRenderer.invoke('mcp:connect', conn),
    disconnect: (id) => ipcRenderer.invoke('mcp:disconnect', { id }),
    callTool: (id, toolName, args) => ipcRenderer.invoke('mcp:callTool', { id, toolName, args }),
    status: () => ipcRenderer.invoke('mcp:status')
  },
  localModel: {
    list: () => ipcRenderer.invoke('localmodel:list'),
    hardware: () => ipcRenderer.invoke('localmodel:hardware'),
    load: (modelPath) => ipcRenderer.invoke('localmodel:load', modelPath),
    unload: () => ipcRenderer.invoke('localmodel:unload'),
    chat: (modelPath, messages, requestId) => ipcRenderer.invoke('localmodel:chat', { modelPath, messages, requestId }),
    setGpu: (pref) => ipcRenderer.invoke('localmodel:setGpu', pref)
  },
  rag: {
    ingest: (relPath) => ipcRenderer.invoke('rag:ingest', { relPath }),
    query: (question, topK) => ipcRenderer.invoke('rag:query', { question, topK }),
    status: () => ipcRenderer.invoke('rag:status'),
    clear: () => ipcRenderer.invoke('rag:clear')
  },
  localApi: {
    getToken: () => ipcRenderer.invoke('localapi:getToken'),
    regenerateToken: () => ipcRenderer.invoke('localapi:regenerateToken'),
    start: (port, lan) => ipcRenderer.invoke('localapi:start', { port, lan }),
    stop: () => ipcRenderer.invoke('localapi:stop'),
    status: () => ipcRenderer.invoke('localapi:status')
  },
  webhook: {
    // Renderer-side listener for inbound Local API webhooks. Returns an
    // unsubscribe function so React effects can clean up properly instead
    // of stacking a new listener on every re-render.
    onReceived: (cb) => {
      const handler = (_e, payload) => cb(payload);
      ipcRenderer.on('webhook:received', handler);
      return () => ipcRenderer.removeListener('webhook:received', handler);
    }
  },
  repo: {
    index: () => ipcRenderer.invoke('repo:index'),
    symbols: (query) => ipcRenderer.invoke('repo:symbols', { query }),
    dependencies: (relPath) => ipcRenderer.invoke('repo:dependencies', { relPath }),
    search: (pattern, caseSensitive) => ipcRenderer.invoke('repo:search', { pattern, caseSensitive }),
    tests: () => ipcRenderer.invoke('repo:tests')
  }
});
