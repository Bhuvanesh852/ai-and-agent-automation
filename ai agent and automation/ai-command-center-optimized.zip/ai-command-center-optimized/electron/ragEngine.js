// Local RAG (retrieval-augmented generation) — no cloud embeddings API, no
// extra native dependency. Retrieval here is TF-IDF + cosine similarity over
// chunked text, not neural embeddings. Be upfront about that limitation: it's
// a real, working, fully-local retrieval method (great for keyword/entity-
// heavy lookups), but it will miss purely semantic paraphrases a true
// embedding model would catch. Upgrading to node-llama-cpp's embedding
// context (already a dependency) is a natural next step, tracked in the
// README rather than silently pretended to already exist.

const fs = require('node:fs/promises');
const path = require('node:path');
const crypto = require('node:crypto');

const INDEXABLE_EXT = new Set([
  '.txt', '.md', '.mdx', '.js', '.jsx', '.ts', '.tsx', '.py', '.json',
  '.java', '.go', '.rb', '.php', '.html', '.css', '.yml', '.yaml', '.csv'
]);
const SKIP_DIRS = new Set(['node_modules', '.git', 'dist', 'release', 'build', '.venv', '__pycache__']);
const CHUNK_SIZE = 900;
const CHUNK_OVERLAP = 150;
const MAX_CHUNKS = 4000;
const MAX_FILE_BYTES = 1.5 * 1024 * 1024;

function indexFile(workspaceRoot) {
  const hash = crypto.createHash('sha1').update(workspaceRoot || 'no-workspace').digest('hex').slice(0, 16);
  return { hash };
}

function chunkText(text) {
  const chunks = [];
  let start = 0;
  while (start < text.length && chunks.length < MAX_CHUNKS) {
    const end = Math.min(start + CHUNK_SIZE, text.length);
    chunks.push(text.slice(start, end));
    if (end >= text.length) break;
    start = end - CHUNK_OVERLAP;
  }
  return chunks;
}

function tokenize(text) {
  return (text.toLowerCase().match(/[a-z0-9]+/g) || []).filter(t => t.length > 2);
}

async function loadIndex(indexPath) {
  try {
    return JSON.parse(await fs.readFile(indexPath, 'utf-8'));
  } catch {
    return { chunks: [], indexedFiles: {} };
  }
}

async function saveIndex(indexPath, index) {
  await fs.mkdir(path.dirname(indexPath), { recursive: true });
  await fs.writeFile(indexPath, JSON.stringify(index), 'utf-8');
}

function getIndexPath(app, workspaceRoot) {
  const { hash } = indexFile(workspaceRoot);
  return path.join(app.getPath('userData'), 'rag-index', `${hash}.json`);
}

async function walkIndexable(dir, root, out) {
  if (out.length >= 500) return;
  let entries;
  try {
    entries = await fs.readdir(dir, { withFileTypes: true });
  } catch {
    return;
  }
  for (const entry of entries) {
    if (out.length >= 500) return;
    if (entry.isDirectory()) {
      if (SKIP_DIRS.has(entry.name)) continue;
      await walkIndexable(path.join(dir, entry.name), root, out);
    } else {
      const ext = path.extname(entry.name).toLowerCase();
      if (INDEXABLE_EXT.has(ext)) {
        out.push(path.join(dir, entry.name));
      }
    }
  }
}

// Ingests one file (relative to workspace) or, if relPath is omitted/".",
// walks the whole workspace and (re)indexes every supported text file.
async function ingest({ app, workspaceRoot, relPath }) {
  if (!workspaceRoot) return { ok: false, result: 'No workspace folder is open.' };
  const indexPath = getIndexPath(app, workspaceRoot);
  const index = await loadIndex(indexPath);

  let targets = [];
  if (relPath && relPath !== '.') {
    const full = path.resolve(workspaceRoot, relPath);
    if (!full.startsWith(path.resolve(workspaceRoot))) {
      return { ok: false, result: 'Refused: path escapes the workspace folder.' };
    }
    targets = [full];
  } else {
    await walkIndexable(workspaceRoot, workspaceRoot, targets);
  }

  let filesIndexed = 0;
  let chunksAdded = 0;
  for (const file of targets) {
    let stat;
    try {
      stat = await fs.stat(file);
      if (stat.size > MAX_FILE_BYTES) continue;
    } catch {
      continue;
    }
    let content;
    try {
      content = await fs.readFile(file, 'utf-8');
    } catch {
      continue;
    }
    const rel = path.relative(workspaceRoot, file);
    // Remove any previous chunks for this file so re-ingesting doesn't duplicate.
    index.chunks = index.chunks.filter(c => c.file !== rel);

    const pieces = chunkText(content);
    pieces.forEach((text, i) => {
      index.chunks.push({ id: `${rel}#${i}`, file: rel, chunkIndex: i, text });
    });
    index.indexedFiles[rel] = { mtimeMs: stat.mtimeMs, chunkCount: pieces.length };
    filesIndexed++;
    chunksAdded += pieces.length;
    if (index.chunks.length > MAX_CHUNKS) {
      index.chunks = index.chunks.slice(-MAX_CHUNKS);
    }
  }

  await saveIndex(indexPath, index);
  return { ok: true, result: { filesIndexed, chunksAdded, totalChunks: index.chunks.length } };
}

async function query({ app, workspaceRoot, question, topK = 5 }) {
  if (!workspaceRoot) return { ok: false, result: 'No workspace folder is open.' };
  const indexPath = getIndexPath(app, workspaceRoot);
  const index = await loadIndex(indexPath);
  if (index.chunks.length === 0) {
    return { ok: true, result: { matches: [], note: 'Nothing indexed yet — run rag_ingest first.' } };
  }

  // Build TF-IDF over the current chunk set, on the fly (small corpora, so
  // this stays cheap — avoids maintaining a stale cached vector index).
  const docTokens = index.chunks.map(c => tokenize(c.text));
  const df = new Map();
  docTokens.forEach(tokens => {
    new Set(tokens).forEach(t => df.set(t, (df.get(t) || 0) + 1));
  });
  const N = docTokens.length;
  const idf = (t) => Math.log((N + 1) / ((df.get(t) || 0) + 1)) + 1;

  function vectorize(tokens) {
    const tf = new Map();
    tokens.forEach(t => tf.set(t, (tf.get(t) || 0) + 1));
    const vec = new Map();
    for (const [t, count] of tf.entries()) {
      vec.set(t, (count / tokens.length) * idf(t));
    }
    return vec;
  }

  function cosine(a, b) {
    let dot = 0, normA = 0, normB = 0;
    for (const v of a.values()) normA += v * v;
    for (const v of b.values()) normB += v * v;
    for (const [t, v] of a.entries()) {
      if (b.has(t)) dot += v * b.get(t);
    }
    if (normA === 0 || normB === 0) return 0;
    return dot / (Math.sqrt(normA) * Math.sqrt(normB));
  }

  const queryVec = vectorize(tokenize(question));
  const scored = index.chunks.map((c, i) => ({
    ...c,
    score: cosine(queryVec, vectorize(docTokens[i]))
  }));
  scored.sort((a, b) => b.score - a.score);
  const matches = scored.filter(m => m.score > 0).slice(0, topK).map(m => ({
    file: m.file,
    chunkIndex: m.chunkIndex,
    score: Math.round(m.score * 1000) / 1000,
    text: m.text.slice(0, 800)
  }));

  return {
    ok: true,
    result: {
      matches,
      note: matches.length === 0
        ? 'No relevant chunks found — this is lexical (TF-IDF) retrieval, so try the exact terms likely used in the documents.'
        : 'Retrieval is lexical (TF-IDF), not neural embeddings — treat as keyword-weighted relevance, not full semantic understanding.'
    }
  };
}

async function status({ app, workspaceRoot }) {
  if (!workspaceRoot) return { ok: true, result: { indexed: false, files: [], totalChunks: 0 } };
  const indexPath = getIndexPath(app, workspaceRoot);
  const index = await loadIndex(indexPath);
  return {
    ok: true,
    result: {
      indexed: index.chunks.length > 0,
      files: Object.entries(index.indexedFiles || {}).map(([file, meta]) => ({ file, chunkCount: meta.chunkCount })),
      totalChunks: index.chunks.length
    }
  };
}

async function clear({ app, workspaceRoot }) {
  if (!workspaceRoot) return { ok: false, result: 'No workspace folder is open.' };
  const indexPath = getIndexPath(app, workspaceRoot);
  await saveIndex(indexPath, { chunks: [], indexedFiles: {} });
  return { ok: true, result: 'RAG index cleared for this workspace.' };
}

module.exports = { ingest, query, status, clear };
