// Free, keyless "internet awareness" tool using DuckDuckGo's public Instant
// Answer API (https://api.duckduckgo.com/?format=json). No account, no key,
// no scraping — this is DuckDuckGo's own documented, keyless JSON endpoint.
//
// Honesty note (matters for the app's "no fake capabilities" rule): this
// returns short instant-answer abstracts and related topics, NOT full search
// engine results pages. It's genuinely useful for facts/definitions/current
// entities, but it is not equivalent to a real search engine's result set —
// the tool description shown to agents says so explicitly.

async function webSearch(query) {
  if (!query || !query.trim()) {
    return { ok: false, result: 'Empty query.' };
  }
  const url = `https://api.duckduckgo.com/?q=${encodeURIComponent(query)}&format=json&no_html=1&skip_disambig=1`;
  try {
    const res = await fetch(url, { headers: { 'User-Agent': 'AI-Command-Center/0.1 (local desktop app)' } });
    if (!res.ok) {
      return { ok: false, result: `Search request failed (status ${res.status}).` };
    }
    const data = await res.json();
    const relatedTopics = (data.RelatedTopics || [])
      .filter(t => t.Text)
      .slice(0, 5)
      .map(t => t.Text);

    if (!data.AbstractText && relatedTopics.length === 0) {
      return {
        ok: true,
        result: {
          query,
          note: 'No instant-answer abstract found for this query. This free tool only covers factual/entity lookups, not full web search — for anything requiring a real search engine, tell the user to search manually.',
          relatedTopics: []
        }
      };
    }

    return {
      ok: true,
      result: {
        query,
        heading: data.Heading || null,
        abstract: data.AbstractText || null,
        abstractSource: data.AbstractSource || null,
        abstractUrl: data.AbstractURL || null,
        relatedTopics
      }
    };
  } catch (err) {
    return { ok: false, result: `Search failed: ${String(err && err.message ? err.message : err)}` };
  }
}

module.exports = { webSearch };
