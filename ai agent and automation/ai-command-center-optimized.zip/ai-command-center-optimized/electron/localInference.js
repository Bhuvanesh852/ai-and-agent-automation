// Self-owned local inference — NOT Ollama. Loads GGUF model files directly
// from disk using node-llama-cpp (MIT-licensed Node bindings to llama.cpp).
//
// Honesty note: this app does not reimplement GGUF parsing or CUDA/Vulkan
// inference kernels from scratch — that is llama.cpp's own, separately
// maintained C/C++ engine, wrapped here. What this app owns is the
// integration: the model registry, the router, the agent/tool loop, the
// approval system, and the UI around it. Claiming to have hand-written a
// production inference engine in this file would be exactly the kind of
// fabricated capability the project's own spec says not to produce.
//
// API note: node-llama-cpp's exact surface has changed across major
// versions. This targets the documented v3.x API (https://node-llama-cpp.withcat.ai/).
// If `npm install` resolves a different major version and something here
// doesn't match, that library's own docs are the source of truth — this is
// flagged rather than silently guessed at.

const fs = require('node:fs/promises');
const path = require('node:path');
const os = require('node:os');

let llamaModulePromise = null;
let llamaInstance = null;
let current = null; // { modelPath, model, context, session }
let gpuPref = 'auto'; // 'auto' | 'cuda' | 'vulkan' | 'metal' | false (CPU-only)

function setGpuBackend(pref) {
  gpuPref = pref;
  llamaInstance = null; // force re-init with new backend on next load
  current = null;       // stale model belonged to the old backend instance
}

async function getLlamaModule() {
  if (!llamaModulePromise) {
    llamaModulePromise = import('node-llama-cpp');
  }
  return llamaModulePromise;
}

async function unloadModel() {
  if (current) {
    try { await current.context?.dispose?.(); } catch { /* best-effort cleanup */ }
    try { await current.model?.dispose?.(); } catch { /* best-effort cleanup */ }
  }
  current = null;
}

// Graceful hardware fallback (spec section 53): refuse to load rather than
// let the process crash or thrash if the file clearly won't fit in RAM.
// This is a coarse heuristic (file size vs free RAM), not a real memory
// simulator — GGUF files are usually somewhat larger than their runtime
// footprint once quantized layers are mapped, so this errs conservative.
async function checkHardwareFit(modelPath) {
  const stat = await fs.stat(modelPath);
  const fileSizeGB = stat.size / 1024 ** 3;
  const freeRamGB = os.freemem() / 1024 ** 3;
  const totalRamGB = os.totalmem() / 1024 ** 3;
  const required = fileSizeGB * 1.2; // rough headroom for KV cache + runtime overhead
  if (required > freeRamGB) {
    return {
      fits: false,
      message: `This model file is ~${fileSizeGB.toFixed(1)} GB. Estimated RAM needed (~${required.toFixed(1)} GB) exceeds your free RAM (~${freeRamGB.toFixed(1)} GB of ${totalRamGB.toFixed(1)} GB total). Close other applications, or pick a smaller/more quantized model (e.g. a Q4_K_M GGUF instead of Q8/FP16).`
    };
  }
  return { fits: true, fileSizeGB, freeRamGB, totalRamGB };
}

async function loadModel(modelPath) {
  if (current?.modelPath === modelPath) {
    return { ok: true, alreadyLoaded: true };
  }

  const fit = await checkHardwareFit(modelPath);
  if (!fit.fits) {
    return { ok: false, error: fit.message };
  }

  let mod;
  try {
    mod = await getLlamaModule();
  } catch (err) {
    return {
      ok: false,
      error: `node-llama-cpp is not installed/available (${String(err?.message || err)}). Run "npm install" first — this is a native module, so the first install can take longer while it fetches a prebuilt binary for your platform.`
    };
  }

  try {
    await unloadModel();
    const { getLlama, LlamaChatSession } = mod;
    const llama = llamaInstance || (llamaInstance = await getLlama({ gpu: gpuPref }));
    const model = await llama.loadModel({ modelPath });
    const context = await model.createContext();
    const session = new LlamaChatSession({ contextSequence: context.getSequence() });
    current = { modelPath, model, context, session };
    return { ok: true, contextSize: context.contextSize ?? null };
  } catch (err) {
    current = null;
    return { ok: false, error: `Failed to load model: ${String(err?.message || err)}` };
  }
}

async function chat({ modelPath, messages, signal }) {
  const loadRes = await loadModel(modelPath);
  if (!loadRes.ok) return loadRes;

  // node-llama-cpp's chat session keeps its own running history internally
  // once primed; for this app's stateless-per-call pattern we replay the
  // conversation as a single composed prompt so history from the UI is
  // always respected even across model switches.
  const systemMsg = messages.find(m => m.role === 'system');
  const turns = messages.filter(m => m.role === 'user' || m.role === 'assistant');
  const lastUserIdx = [...turns].map(m => m.role).lastIndexOf('user');
  const priorTurns = turns.slice(0, lastUserIdx);
  const lastUser = turns[lastUserIdx];

  if (!lastUser) {
    return { ok: false, error: 'No user message to respond to.' };
  }

  let composedPrompt = '';
  if (systemMsg) composedPrompt += `[System instructions]\n${systemMsg.content}\n\n`;
  if (priorTurns.length > 0) {
    composedPrompt += priorTurns.map(t => `${t.role === 'user' ? 'User' : 'Assistant'}: ${t.content}`).join('\n') + '\n\n';
  }
  composedPrompt += lastUser.content;

  try {
    // node-llama-cpp v3's session.prompt accepts a `signal` to stop
    // generation early; if a different installed version ignores it,
    // this becomes a no-op rather than an error.
    const response = await current.session.prompt(composedPrompt, { signal });
    return { ok: true, content: response };
  } catch (err) {
    if (err?.name === 'AbortError' || signal?.aborted) return { ok: false, error: 'ABORTED' };
    return { ok: false, error: `Local inference failed: ${String(err?.message || err)}` };
  }
}

async function listModelFiles(dirs) {
  const found = [];
  for (const dir of dirs) {
    let entries;
    try {
      entries = await fs.readdir(dir, { withFileTypes: true });
    } catch {
      continue;
    }
    for (const entry of entries) {
      if (entry.isFile() && entry.name.toLowerCase().endsWith('.gguf')) {
        const full = path.join(dir, entry.name);
        try {
          const stat = await fs.stat(full);
          found.push({ path: full, name: entry.name, sizeGB: Math.round((stat.size / 1024 ** 3) * 10) / 10 });
        } catch {
          // unreadable file, skip
        }
      }
    }
  }
  return found;
}

function hardwareSummary() {
  return {
    totalRamGB: Math.round((os.totalmem() / 1024 ** 3) * 10) / 10,
    freeRamGB: Math.round((os.freemem() / 1024 ** 3) * 10) / 10,
    cpuCores: (os.cpus() || []).length
  };
}

async function chatStream({ modelPath, messages, onToken }) {
  const loadRes = await loadModel(modelPath);
  if (!loadRes.ok) return loadRes;

  const systemMsg = messages.find(m => m.role === 'system');
  const turns = messages.filter(m => m.role === 'user' || m.role === 'assistant');
  const lastUserIdx = [...turns].map(m => m.role).lastIndexOf('user');
  const priorTurns = turns.slice(0, lastUserIdx);
  const lastUser = turns[lastUserIdx];
  if (!lastUser) return { ok: false, error: 'No user message to respond to.' };

  let composedPrompt = '';
  if (systemMsg) composedPrompt += `[System instructions]\n${systemMsg.content}\n\n`;
  if (priorTurns.length > 0) {
    composedPrompt += priorTurns.map(t => `${t.role === 'user' ? 'User' : 'Assistant'}: ${t.content}`).join('\n') + '\n\n';
  }
  composedPrompt += lastUser.content;

  try {
    let full = '';
    await current.session.prompt(composedPrompt, {
      onTextChunk: (chunk) => { full += chunk; onToken && onToken(chunk); }
    });
    return { ok: true, content: full };
  } catch (err) {
    return { ok: false, error: `Local inference failed: ${String(err?.message || err)}` };
  }
}

module.exports = { loadModel, unloadModel, chat, chatStream, listModelFiles, hardwareSummary, checkHardwareFit, setGpuBackend };
