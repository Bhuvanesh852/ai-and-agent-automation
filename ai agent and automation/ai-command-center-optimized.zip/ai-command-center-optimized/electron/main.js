const { app, BrowserWindow, ipcMain, safeStorage, dialog } = require('electron');
const path = require('node:path');
const os = require('node:os');
const fs = require('node:fs/promises');
const Store = require('electron-store');
const { executeTool } = require('./toolExecutor.js');
const { scanSecrets } = require('./secretScanner.js');
const { scanDependencies } = require('./dependencyScanner.js');
const { scanNetwork } = require('./networkGuard.js');
const mcpClient = require('./mcpClient.js');
const localInference = require('./localInference.js');
const ragEngine = require('./ragEngine.js');
const apiServer = require('./apiServer.js');
const repoIndexer = require('./repoIndexer.js');

const isDev = process.env.NODE_ENV === 'development';

// --- Provider allowlist (SECURITY FIX) --------------------------------
// Previously `provider:call` accepted `url`, `headers`, `keyHeaderName`,
// and `keyPrefix` straight from the renderer and used them as-is. A
// compromised or buggy renderer (an XSS in a dependency, a malicious
// tool-result string that made it back into UI state, a compromised npm
// package used at build time, etc.) could therefore ask main to send a
// saved API key to ANY url with ANY header name — i.e. directly exfiltrate
// the credential to an attacker-controlled server, with the main process
// happily attaching the decrypted key for it.
//
// Fix: the renderer may only ever say *which* known provider it wants to
// call (`providerId`) plus provider-specific, narrow data (a `modelId` for
// Gemini's path segment, a request `body`). Main process alone owns the
// destination host, path template, auth header name, and key prefix for
// every provider — none of that is renderer-controllable anymore.
const PROVIDER_CONFIGS = {
  groq: {
    keyHeaderName: 'Authorization',
    keyPrefix: 'Bearer ',
    buildUrl: () => 'https://api.groq.com/openai/v1/chat/completions',
    // Lightweight, side-effect-free request used by "Test Connection".
    buildTestRequest: (key) => ({
      url: 'https://api.groq.com/openai/v1/models',
      method: 'GET',
      headers: { Authorization: `Bearer ${key}` }
    })
  },
  gemini: {
    keyHeaderName: 'x-goog-api-key',
    keyPrefix: '',
    // modelId is encodeURIComponent'd, so it can only ever occupy this one
    // path segment — it cannot inject "/" to escape onto a different path,
    // let alone a different host.
    buildUrl: ({ modelId }) => {
      if (!modelId || typeof modelId !== 'string') throw new Error('modelId is required for the Gemini adapter.');
      return `https://generativelanguage.googleapis.com/v1beta/models/${encodeURIComponent(modelId)}:generateContent`;
    },
    buildTestRequest: (key) => ({
      url: 'https://generativelanguage.googleapis.com/v1beta/models',
      method: 'GET',
      headers: { 'x-goog-api-key': key }
    })
  },
  openrouter: {
    keyHeaderName: 'Authorization',
    keyPrefix: 'Bearer ',
    extraHeaders: {
      'HTTP-Referer': 'https://local.aicommandcenter.app',
      'X-Title': 'AI Command Center'
    },
    buildUrl: () => 'https://openrouter.ai/api/v1/chat/completions',
    // OpenRouter's key-info endpoint also reports quota/limit state, which
    // is why the test result below can distinguish "invalid key" from
    // "valid key, but rate-limited/out of quota" for this provider.
    buildTestRequest: (key) => ({
      url: 'https://openrouter.ai/api/v1/auth/key',
      method: 'GET',
      headers: { Authorization: `Bearer ${key}` }
    })
  },
  // --- Additional free-tier providers -----------------------------------
  // All three are OpenAI-/chat/completions-compatible, so the renderer uses
  // one generic adapter for them. Main still owns host + auth header here,
  // which is the whole point of the allowlist: the renderer can only name a
  // providerId, never a destination.
  cerebras: {
    keyHeaderName: 'Authorization',
    keyPrefix: 'Bearer ',
    buildUrl: () => 'https://api.cerebras.ai/v1/chat/completions',
    buildTestRequest: (key) => ({
      url: 'https://api.cerebras.ai/v1/models',
      method: 'GET',
      headers: { Authorization: `Bearer ${key}` }
    })
  },
  mistral: {
    keyHeaderName: 'Authorization',
    keyPrefix: 'Bearer ',
    buildUrl: () => 'https://api.mistral.ai/v1/chat/completions',
    buildTestRequest: (key) => ({
      url: 'https://api.mistral.ai/v1/models',
      method: 'GET',
      headers: { Authorization: `Bearer ${key}` }
    })
  },
  'github-models': {
    keyHeaderName: 'Authorization',
    keyPrefix: 'Bearer ',
    buildUrl: () => 'https://models.inference.ai.azure.com/chat/completions',
    buildTestRequest: (key) => ({
      url: 'https://models.inference.ai.azure.com/models',
      method: 'GET',
      headers: { Authorization: `Bearer ${key}` }
    })
  }
};

const PROVIDER_TEST_TIMEOUT_MS = 8000;

// Default place to look for user-supplied GGUF model files, independent of
// any workspace folder — so local models work even before a project is open.
function defaultModelsDir() {
  return path.join(app.getPath('userData'), 'models');
}

async function fs_ensureDir(dir) {
  try {
    await fs.mkdir(dir, { recursive: true });
  } catch { /* best-effort */ }
}

// Runtime-only kill switch — intentionally NOT persisted, so a restart
// always comes back up in a normal (non-stopped) state.
let stopAllFlag = false;

// Per-request cancellation: the renderer generates a requestId per turn and
// can cancel it via 'request:cancel'. This aborts the actual in-flight
// network call (not just "stop before the next step"), so Stop is immediate
// rather than waiting for a slow provider response to finish first.
const activeRequests = new Map();
function withCancellation(requestId) {
  const controller = new AbortController();
  if (requestId) activeRequests.set(requestId, controller);
  return {
    signal: controller.signal,
    done: () => { if (requestId) activeRequests.delete(requestId); }
  };
}

// Plain-text config (non-secret): which providers are "configured",
// model registry overrides, UI prefs. Secrets never live here in plaintext.
const store = new Store({ name: 'app-config' });

// --- MCP bridge -----------------------------------------------------------
// electron/mcpServer.js runs as a separate, standalone process (spawned by
// an MCP client like Claude Desktop, not by this app) and has no access to
// electron-store. It reads the workspace root from a plain JSON file instead
// — this keeps that file in sync whenever the workspace changes here.
function syncMcpConfig(workspaceRoot) {
  try {
    const mcpHome = path.join(os.homedir(), '.ai-command-center');
    require('node:fs').mkdirSync(mcpHome, { recursive: true });
    require('node:fs').writeFileSync(
      path.join(mcpHome, 'mcp-config.json'),
      JSON.stringify({ workspaceRoot }, null, 2)
    );
  } catch (err) {
    console.warn('Could not sync MCP config:', err.message);
  }
}
syncMcpConfig(store.get('workspaceRoot', null));

// Encrypted secret store: only holds OS-encrypted blobs (via safeStorage).
// Never logged, never sent to the renderer in cleartext, never written into
// generated code or chat.
const secretStore = new Store({ name: 'secrets' });

function keyFor(providerId) {
  return `cred:${providerId}`;
}

function saveCredential(providerId, plaintextKey) {
  if (!safeStorage.isEncryptionAvailable()) {
    throw new Error('OS-level secret encryption is not available on this machine.');
  }
  const encrypted = safeStorage.encryptString(plaintextKey);
  secretStore.set(keyFor(providerId), encrypted.toString('base64'));
  const meta = store.get('providerMeta', {});
  meta[providerId] = { status: 'configured', last4: plaintextKey.slice(-4) };
  store.set('providerMeta', meta);
  return { status: 'configured', last4: plaintextKey.slice(-4) };
}

function readCredential(providerId) {
  const encoded = secretStore.get(keyFor(providerId));
  if (!encoded) return null;
  if (!safeStorage.isEncryptionAvailable()) return null;
  try {
    const buf = Buffer.from(encoded, 'base64');
    return safeStorage.decryptString(buf);
  } catch {
    return null;
  }
}

function removeCredential(providerId) {
  secretStore.delete(keyFor(providerId));
  const meta = store.get('providerMeta', {});
  delete meta[providerId];
  store.set('providerMeta', meta);
}

function getHardwareProfile() {
  const totalRamGB = Math.round((os.totalmem() / 1024 ** 3) * 10) / 10;
  const freeRamGB = Math.round((os.freemem() / 1024 ** 3) * 10) / 10;
  const cpus = os.cpus() || [];
  const lowResource = totalRamGB <= 8.5 || cpus.length <= 4;
  return {
    platform: os.platform(),
    release: os.release(),
    arch: os.arch(),
    totalRamGB,
    freeRamGB,
    cpuModel: cpus[0]?.model || 'unknown',
    cpuCores: cpus.length,
    recommendedMode: lowResource ? 'low-resource' : 'standard'
  };
}

function createWindow() {
  const win = new BrowserWindow({
    width: 1360,
    height: 860,
    minWidth: 980,
    minHeight: 640,
    backgroundColor: '#0b0d12',
    webPreferences: {
      preload: path.join(__dirname, 'preload.js'),
      contextIsolation: true,
      nodeIntegration: false,
      sandbox: true
    }
  });

  if (isDev) {
    win.loadURL('http://localhost:5173');
    win.webContents.openDevTools({ mode: 'detach' });
  } else {
    win.loadFile(path.join(__dirname, '..', 'dist', 'index.html'));
  }
}

app.whenReady().then(() => {
  // --- Credentials (never exposed to renderer in cleartext) ---
  ipcMain.handle('creds:save', (_e, { providerId, key }) => {
    return saveCredential(providerId, key);
  });
  ipcMain.handle('creds:status', () => {
    return store.get('providerMeta', {});
  });
  ipcMain.handle('creds:remove', (_e, { providerId }) => {
    removeCredential(providerId);
    return { status: 'missing' };
  });
  // Used only inside main-process fetch calls; never returned to renderer.
  ipcMain.handle('creds:hasKey', (_e, { providerId }) => {
    return !!readCredential(providerId);
  });

  // --- Proxy provider HTTP calls through main process so the raw key ---
  // --- never has to be sent to the renderer/DOM at all. ---
  // SECURITY FIX: the destination URL and auth header are now looked up
  // from PROVIDER_CONFIGS (main-process-owned) by providerId, never taken
  // from the renderer. The renderer can no longer choose the URL, the
  // header name, or the key prefix — only which known provider to call.
  ipcMain.handle('provider:call', async (_e, { providerId, modelId, body, requestId }) => {
    const config = PROVIDER_CONFIGS[providerId];
    if (!config) {
      return { ok: false, status: 0, error: 'UNKNOWN_PROVIDER' };
    }
    if (store.get('lockdownMode', false)) {
      return { ok: false, status: 0, error: 'LOCKDOWN_ACTIVE' };
    }
    const key = readCredential(providerId);
    if (!key) {
      return { ok: false, status: 401, error: 'NO_CREDENTIAL' };
    }

    let url;
    try {
      url = config.buildUrl({ modelId });
    } catch (err) {
      return { ok: false, status: 0, error: String(err && err.message ? err.message : err) };
    }

    const finalHeaders = { 'Content-Type': 'application/json', ...(config.extraHeaders || {}) };
    if (config.keyHeaderName) {
      finalHeaders[config.keyHeaderName] = config.keyPrefix ? `${config.keyPrefix}${key}` : key;
    }

    const { signal, done } = withCancellation(requestId);
    try {
      const res = await fetch(url, { method: 'POST', headers: finalHeaders, body, signal });
      const text = await res.text();
      return { ok: res.ok, status: res.status, body: text };
    } catch (err) {
      if (err?.name === 'AbortError') return { ok: false, status: 0, error: 'ABORTED' };
      return { ok: false, status: 0, error: String(err && err.message ? err.message : err) };
    } finally {
      done();
    }
  });

  // --- Real provider connection test (fixes the old "Test Connection" ---
  // --- button, which only ever checked whether *a* key was saved, not ---
  // --- whether it actually authenticates with the provider). Sends one ---
  // --- small, side-effect-free request and classifies the outcome. ---
  ipcMain.handle('provider:test', async (_e, { providerId }) => {
    const config = PROVIDER_CONFIGS[providerId];
    if (!config || !config.buildTestRequest) {
      return { ok: false, error: 'UNSUPPORTED_PROVIDER' };
    }
    if (store.get('lockdownMode', false)) {
      return { ok: false, error: 'LOCKDOWN_ACTIVE' };
    }
    const key = readCredential(providerId);
    if (!key) {
      return { ok: false, error: 'NO_CREDENTIAL' };
    }

    const { url, method, headers } = config.buildTestRequest(key);
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), PROVIDER_TEST_TIMEOUT_MS);
    try {
      const res = await fetch(url, { method: method || 'GET', headers, signal: controller.signal });
      if (res.status === 401 || res.status === 403) {
        return { ok: false, error: 'INVALID_KEY', status: res.status };
      }
      if (res.status === 429) {
        return { ok: false, error: 'QUOTA_EXCEEDED', status: res.status };
      }
      if (!res.ok) {
        return { ok: false, error: 'PROVIDER_ERROR', status: res.status };
      }
      return { ok: true, status: res.status };
    } catch (err) {
      if (err?.name === 'AbortError') return { ok: false, error: 'TIMEOUT' };
      return { ok: false, error: 'NETWORK_ERROR', detail: String(err && err.message ? err.message : err) };
    } finally {
      clearTimeout(timer);
    }
  });

  // --- Local Ollama probe (no key required, runs on localhost) ---
  ipcMain.handle('ollama:list', async () => {
    try {
      const res = await fetch('http://127.0.0.1:11434/api/tags');
      if (!res.ok) return { ok: false, models: [] };
      const data = await res.json();
      return { ok: true, models: (data.models || []).map(m => m.name) };
    } catch {
      return { ok: false, models: [] };
    }
  });
  ipcMain.handle('ollama:chat', async (_e, { model, messages, requestId }) => {
    const { signal, done } = withCancellation(requestId);
    try {
      const res = await fetch('http://127.0.0.1:11434/api/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ model, messages, stream: false }),
        signal
      });
      const data = await res.json();
      return { ok: res.ok, content: data?.message?.content || '' };
    } catch (err) {
      if (err?.name === 'AbortError') return { ok: false, error: 'ABORTED' };
      return { ok: false, error: String(err && err.message ? err.message : err) };
    } finally {
      done();
    }
  });

  ipcMain.handle('request:cancel', (_e, requestId) => {
    const controller = activeRequests.get(requestId);
    if (controller) controller.abort();
    return true;
  });

  ipcMain.handle('system:hardwareProfile', () => getHardwareProfile());

  // --- Non-secret app config (project state, UI prefs, model registry) ---
  ipcMain.handle('config:get', (_e, key) => store.get(key));
  ipcMain.handle('config:set', (_e, { key, value }) => {
    store.set(key, value);
    return true;
  });

  // --- Workspace folder (sandbox root for all tool execution) ---
  ipcMain.handle('workspace:select', async () => {
    const win = BrowserWindow.getFocusedWindow();
    const result = await dialog.showOpenDialog(win, { properties: ['openDirectory'] });
    if (result.canceled || !result.filePaths[0]) return null;
    store.set('workspaceRoot', result.filePaths[0]);
    syncMcpConfig(result.filePaths[0]);
    return result.filePaths[0];
  });
  ipcMain.handle('workspace:current', () => store.get('workspaceRoot', null));

  // --- Agent tool execution, sandboxed to the workspace root. Risky tools ---
  // --- (write_file, run_terminal, git_commit) are gated by the renderer's ---
  // --- approval-checkpoint UI *before* this handler is ever invoked; the ---
  // --- path-containment check below is defense-in-depth on top of that. ---
  ipcMain.handle('tools:execute', async (_e, { name, args }) => {
    const workspaceRoot = store.get('workspaceRoot', null);
    const isLockedDown = store.get('lockdownMode', false);
    try {
      const result = await executeTool(name, args, { workspaceRoot, isLockedDown });
      return result;
    } catch (err) {
      return { ok: false, result: String(err && err.message ? err.message : err) };
    }
  });

  // --- Security Center: direct scan entry points (independent of any agent) ---
  ipcMain.handle('security:scanSecrets', async () => {
    return scanSecrets(store.get('workspaceRoot', null));
  });
  ipcMain.handle('security:scanDependencies', async () => {
    return scanDependencies(store.get('workspaceRoot', null));
  });
  ipcMain.handle('security:scanNetwork', async () => {
    return scanNetwork(store.get('workspaceRoot', null));
  });

  // --- MCP client: connect this app OUT to external MCP servers ---------
  ipcMain.handle('mcp:connect', async (_e, { id, name, command, args, cwd }) => {
    return mcpClient.connect({ id, name, command, args, cwd });
  });
  ipcMain.handle('mcp:disconnect', async (_e, { id }) => {
    return mcpClient.disconnect(id);
  });
  ipcMain.handle('mcp:callTool', async (_e, { id, toolName, args }) => {
    return mcpClient.callTool(id, toolName, args);
  });
  ipcMain.handle('mcp:status', () => mcpClient.status());

  // --- Lockdown Mode: persisted, disables external network calls and ---
  // --- privileged tools until explicitly turned off. ---
  ipcMain.handle('security:getLockdown', () => store.get('lockdownMode', false));
  ipcMain.handle('security:setLockdown', (_e, enabled) => {
    store.set('lockdownMode', !!enabled);
    return !!enabled;
  });

  // --- STOP ALL AGENTS: runtime-only kill switch. ---
  ipcMain.handle('security:getStopAll', () => stopAllFlag);
  ipcMain.handle('security:setStopAll', (_e, enabled) => {
    stopAllFlag = !!enabled;
    if (stopAllFlag) {
      // Previously this only blocked *new* requests — anything already
      // in flight (a slow provider response, a long local-model generation)
      // kept running to completion. Actually abort every active request so
      // STOP ALL is immediate, matching what the UI already claims.
      for (const controller of activeRequests.values()) {
        controller.abort();
      }
      activeRequests.clear();
    }
    return stopAllFlag;
  });

  // --- Audit log: short structured entries only. Never stores raw tool ---
  // --- output, file contents, or command results — callers pass a summary. ---
  ipcMain.handle('security:auditAppend', (_e, entry) => {
    const log = store.get('auditLog', []);
    const safeEntry = {
      ts: Date.now(),
      category: String(entry?.category || 'general').slice(0, 40),
      message: String(entry?.message || '').slice(0, 400)
    };
    log.push(safeEntry);
    store.set('auditLog', log.slice(-500));
    return true;
  });
  ipcMain.handle('security:auditGet', () => store.get('auditLog', []));

  // --- Local, no-Ollama GGUF inference (node-llama-cpp) ---
  async function listLocalModelFiles() {
    await fs_ensureDir(defaultModelsDir());
    const workspaceRoot = store.get('workspaceRoot', null);
    const dirs = [defaultModelsDir()];
    if (workspaceRoot) dirs.push(path.join(workspaceRoot, 'models'));
    return localInference.listModelFiles(dirs);
  }
  ipcMain.handle('localmodel:list', async () => {
    const files = await listLocalModelFiles();
    return { ok: true, models: files, modelsDir: defaultModelsDir() };
  });
  ipcMain.handle('localmodel:hardware', () => localInference.hardwareSummary());
  ipcMain.handle('localmodel:setGpu', (_e, pref) => { localInference.setGpuBackend(pref); return true; });
  ipcMain.handle('localmodel:load', async (_e, modelPath) => {
    // The renderer previously could send ANY absolute path here and it would
    // be loaded as-is — meaning a compromised or buggy renderer/agent could
    // trigger reading an arbitrary file on disk into the inference engine.
    // Only allow files that actually live inside one of the two directories
    // we ourselves list in localmodel:list (the app's models dir, or the
    // open workspace's models/ subfolder), resolved via realpath so a
    // symlink can't point the "allowed" path somewhere else.
    try {
      const workspaceRoot = store.get('workspaceRoot', null);
      const allowedDirs = [defaultModelsDir()];
      if (workspaceRoot) allowedDirs.push(path.join(workspaceRoot, 'models'));

      const realTarget = await fs.realpath(modelPath);
      const isAllowed = (
        await Promise.all(allowedDirs.map(async (dir) => {
          try {
            const realDir = await fs.realpath(dir);
            return realTarget === realDir || realTarget.startsWith(realDir + path.sep);
          } catch {
            return false;
          }
        }))
      ).some(Boolean);

      if (!isAllowed) {
        return { ok: false, error: 'Refused: model file is outside the approved models folder(s).' };
      }
      return await localInference.loadModel(realTarget);
    } catch (err) {
      return { ok: false, error: String(err && err.message ? err.message : err) };
    }
  });
  ipcMain.handle('localmodel:unload', async () => {
    await localInference.unloadModel();
    return { ok: true };
  });
  ipcMain.handle('localmodel:chat', async (_e, { modelPath, messages, requestId }) => {
    const { signal, done } = withCancellation(requestId);
    try {
      return await localInference.chat({ modelPath, messages, signal });
    } finally {
      done();
    }
  });

  // --- Local RAG (TF-IDF retrieval, no cloud embeddings) ---
  ipcMain.handle('rag:ingest', async (_e, { relPath }) => {
    return ragEngine.ingest({ app, workspaceRoot: store.get('workspaceRoot', null), relPath });
  });
  ipcMain.handle('rag:query', async (_e, { question, topK }) => {
    return ragEngine.query({ app, workspaceRoot: store.get('workspaceRoot', null), question, topK });
  });
  ipcMain.handle('rag:status', async () => {
    return ragEngine.status({ app, workspaceRoot: store.get('workspaceRoot', null) });
  });
  ipcMain.handle('rag:clear', async () => {
    return ragEngine.clear({ app, workspaceRoot: store.get('workspaceRoot', null) });
  });

  // --- OpenAI-compatible local HTTP API (loopback only, off by default) ---
  function getOrCreateLocalApiToken() {
    let token = readCredential('localapi');
    if (!token) {
      token = apiServer.generateToken();
      saveCredential('localapi', token);
    }
    return token;
  }
  ipcMain.handle('localapi:getToken', () => getOrCreateLocalApiToken());
  ipcMain.handle('localapi:regenerateToken', () => {
    const token = apiServer.generateToken();
    saveCredential('localapi', token);
    return token;
  });
  ipcMain.handle('localapi:start', async (_e, { port, lan }) => {
    try {
      const token = getOrCreateLocalApiToken();
      const result = await apiServer.start({
        port: port || 8788,
        host: lan ? 'lan' : 'loopback',
        token,
        getCredential: readCredential,
        isLockedDown: () => store.get('lockdownMode', false),
        listLocalModels: listLocalModelFiles,
        // The workflow engine lives in the renderer, so an inbound webhook
        // is forwarded there rather than executed here.
        onWebhook: (evt) => {
          const win = BrowserWindow.getAllWindows()[0];
          if (win && !win.isDestroyed()) win.webContents.send('webhook:received', evt);
        }
      });
      return result;
    } catch (err) {
      return { ok: false, error: String(err && err.message ? err.message : err) };
    }
  });
  ipcMain.handle('localapi:stop', async () => apiServer.stop());
  ipcMain.handle('localapi:status', () => apiServer.status());

  // --- Repository-aware indexing: symbols, import graph, grep, tests ---
  ipcMain.handle('repo:index', async () => {
    return repoIndexer.buildIndex({ app, workspaceRoot: store.get('workspaceRoot', null) });
  });
  ipcMain.handle('repo:symbols', async (_e, { query }) => {
    return repoIndexer.findSymbols({ app, workspaceRoot: store.get('workspaceRoot', null), query });
  });
  ipcMain.handle('repo:dependencies', async (_e, { relPath }) => {
    return repoIndexer.dependencyGraph({ app, workspaceRoot: store.get('workspaceRoot', null), relPath });
  });
  ipcMain.handle('repo:search', async (_e, { pattern, caseSensitive }) => {
    return repoIndexer.grepSearch({ workspaceRoot: store.get('workspaceRoot', null), pattern, caseSensitive });
  });
  ipcMain.handle('repo:tests', async () => {
    return repoIndexer.discoverTests({ app, workspaceRoot: store.get('workspaceRoot', null) });
  });

  createWindow();

  app.on('activate', () => {
    if (BrowserWindow.getAllWindows().length === 0) createWindow();
  });
});

app.on('window-all-closed', () => {
  if (process.platform !== 'darwin') app.quit();
});

app.on('before-quit', async () => {
  try { await apiServer.stop(); } catch { /* best-effort */ }
});
