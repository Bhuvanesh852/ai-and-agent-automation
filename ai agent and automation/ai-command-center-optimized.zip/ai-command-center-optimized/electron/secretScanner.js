// Local-only secret scanner. Never sends anything anywhere — the whole point
// is to find leaks *before* they reach a model or a git commit. Matched
// secret values are always masked before being returned to the renderer
// (and therefore before they could ever end up in a chat sent to a model).
const fs = require('node:fs/promises');
const path = require('node:path');

const SKIP_DIRS = new Set(['node_modules', '.git', 'dist', 'release', '.next', 'build', '.venv', '__pycache__']);
const MAX_FILES = 2000;
const MAX_FILE_BYTES = 2 * 1024 * 1024; // skip huge files (binaries, bundles)
const TEXT_EXT_HINT = new Set([
  '.js', '.jsx', '.ts', '.tsx', '.py', '.json', '.env', '.yml', '.yaml', '.toml',
  '.ini', '.cfg', '.md', '.txt', '.sh', '.ps1', '.java', '.go', '.rb', '.php', '.html', '.css'
]);

// Each pattern: { id, label, severity, regex } — regex must have a capturing
// group around the sensitive value so it can be masked independently of the
// surrounding match.
const PATTERNS = [
  { id: 'aws_access_key', label: 'AWS Access Key ID', severity: 'Critical', regex: /\b(AKIA[0-9A-Z]{16})\b/g },
  { id: 'aws_secret', label: 'Possible AWS Secret Key', severity: 'Critical', regex: /aws(.{0,20})?(secret|SECRET)[_-]?(access)?[_-]?(key|KEY)\s*[:=]\s*['"]([A-Za-z0-9\/+=]{40})['"]/g, groupIndex: 5 },
  { id: 'private_key_block', label: 'Private Key Block', severity: 'Critical', regex: /(-----BEGIN (?:RSA |EC |OPENSSH |DSA )?PRIVATE KEY-----)/g },
  { id: 'generic_api_key', label: 'Generic API Key Assignment', severity: 'High', regex: /\b(api[_-]?key|apikey)\s*[:=]\s*['"]([A-Za-z0-9_\-\.]{16,})['"]/gi, groupIndex: 2 },
  { id: 'generic_secret', label: 'Generic Secret/Token Assignment', severity: 'High', regex: /\b(secret|token|access[_-]?token|auth[_-]?token)\s*[:=]\s*['"]([A-Za-z0-9_\-\.]{16,})['"]/gi, groupIndex: 2 },
  { id: 'password_assignment', label: 'Hardcoded Password Assignment', severity: 'High', regex: /\b(password|passwd|pwd)\s*[:=]\s*['"]([^'"]{4,})['"]/gi, groupIndex: 2 },
  { id: 'slack_token', label: 'Slack Token', severity: 'High', regex: /\b(xox[baprs]-[0-9A-Za-z-]{10,})\b/g },
  { id: 'google_api_key', label: 'Google API Key', severity: 'High', regex: /\b(AIza[0-9A-Za-z_\-]{35})\b/g },
  { id: 'jwt_like', label: 'JWT-looking Token', severity: 'Medium', regex: /\b(eyJ[A-Za-z0-9_-]{10,}\.[A-Za-z0-9_-]{10,}\.[A-Za-z0-9_-]{10,})\b/g },
  { id: 'connection_string', label: 'Database Connection String with Credentials', severity: 'Critical', regex: /\b((?:postgres|postgresql|mysql|mongodb(?:\+srv)?):\/\/[^:\s]+:[^@\s]+@[^\s'"]+)/gi }
];

function mask(value) {
  if (!value) return '[redacted]';
  if (value.length <= 6) return '*'.repeat(value.length);
  return `${value.slice(0, 3)}${'*'.repeat(Math.min(10, value.length - 5))}${value.slice(-2)}`;
}

async function walk(dir, root, out, budget) {
  if (out.length >= MAX_FILES || budget.count >= MAX_FILES) return;
  let entries;
  try {
    entries = await fs.readdir(dir, { withFileTypes: true });
  } catch {
    return;
  }
  for (const entry of entries) {
    if (budget.count >= MAX_FILES) return;
    if (entry.isDirectory()) {
      if (SKIP_DIRS.has(entry.name)) continue;
      await walk(path.join(dir, entry.name), root, out, budget);
    } else {
      budget.count++;
      const full = path.join(dir, entry.name);
      const ext = path.extname(entry.name).toLowerCase();
      const isEnvFile = entry.name === '.env' || entry.name.startsWith('.env.');
      if (!isEnvFile && !TEXT_EXT_HINT.has(ext)) continue;
      out.push({ full, rel: path.relative(root, full) });
    }
  }
}

async function scanSecrets(workspaceRoot) {
  if (!workspaceRoot) {
    return { ok: false, result: 'No workspace folder is open.' };
  }
  const files = [];
  await walk(workspaceRoot, workspaceRoot, files, { count: 0 });

  const findings = [];
  for (const f of files) {
    let content;
    try {
      const stat = await fs.stat(f.full);
      if (stat.size > MAX_FILE_BYTES) continue;
      content = await fs.readFile(f.full, 'utf-8');
    } catch {
      continue;
    }

    const lines = content.split('\n');
    for (const pattern of PATTERNS) {
      pattern.regex.lastIndex = 0;
      let match;
      while ((match = pattern.regex.exec(content)) !== null) {
        const upToMatch = content.slice(0, match.index);
        const lineNum = upToMatch.split('\n').length;
        const rawValue = pattern.groupIndex ? match[pattern.groupIndex] : match[1];
        findings.push({
          id: pattern.id,
          label: pattern.label,
          severity: pattern.severity,
          file: f.rel,
          line: lineNum,
          preview: mask(rawValue || match[0]),
          isEnvFile: f.rel === '.env' || f.rel.startsWith('.env.')
        });
        if (findings.length > 500) break;
      }
      if (findings.length > 500) break;
    }
  }

  return {
    ok: true,
    result: {
      filesScanned: files.length,
      findings,
      scannedAt: Date.now()
    }
  };
}

module.exports = { scanSecrets };
