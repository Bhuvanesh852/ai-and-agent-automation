// Internet layer. Everything here is keyless and free — no account, no API
// key, no scraping of a paid product. These are each provider's own public,
// documented JSON endpoint.
//
// HONESTY NOTE: this is not a commercial search API. It is four free public
// sources queried in parallel and merged. That combination is genuinely good
// for facts, definitions, papers, current entities and technical discussion,
// and genuinely weaker than a paid SERP API for long-tail commercial queries.
// The tool descriptions shown to the model say exactly that, so the model
// does not overclaim to the user.
//
//   DuckDuckGo Instant Answer  - facts, definitions, entities
//   Wikipedia REST             - encyclopedic background
//   Hacker News (Algolia)      - current technical discussion + links
//   arXiv Atom API             - research papers
//
// read_url then fetches any one result and converts it to plain text so the
// model can actually read the page instead of guessing from a snippet.

const USER_AGENT = 'AI-Command-Center/0.5 (local desktop app)';
const FETCH_TIMEOUT_MS = 12000;
const MAX_PAGE_CHARS = 60000;

// Hosts the generic http_request tool may never reach, regardless of what a
// workflow or model asks for. Blocks SSRF into the loopback interface, link
// local metadata services (cloud credential theft), and private LAN ranges.
const BLOCKED_HOST_RE = /^(localhost|127\.|0\.0\.0\.0|\[?::1\]?|169\.254\.|10\.|192\.168\.|172\.(1[6-9]|2\d|3[01])\.)/i;

function withTimeout(ms) {
  const c = new AbortController();
  const t = setTimeout(() => c.abort(), ms);
  return { signal: c.signal, done: () => clearTimeout(t) };
}

async function getJSON(url) {
  const { signal, done } = withTimeout(FETCH_TIMEOUT_MS);
  try {
    const res = await fetch(url, { headers: { 'User-Agent': USER_AGENT, Accept: 'application/json' }, signal });
    if (!res.ok) return null;
    return await res.json();
  } catch {
    return null;
  } finally {
    done();
  }
}

async function getText(url) {
  const { signal, done } = withTimeout(FETCH_TIMEOUT_MS);
  try {
    const res = await fetch(url, { headers: { 'User-Agent': USER_AGENT }, signal });
    if (!res.ok) return null;
    return await res.text();
  } catch {
    return null;
  } finally {
    done();
  }
}

// --- individual sources ---------------------------------------------------

async function duckduckgo(query) {
  const data = await getJSON(
    `https://api.duckduckgo.com/?q=${encodeURIComponent(query)}&format=json&no_html=1&skip_disambig=1`
  );
  if (!data) return [];
  const out = [];
  if (data.AbstractText) {
    out.push({
      source: 'duckduckgo',
      title: data.Heading || query,
      snippet: data.AbstractText,
      url: data.AbstractURL || null
    });
  }
  for (const t of (data.RelatedTopics || []).slice(0, 4)) {
    if (t.Text) out.push({ source: 'duckduckgo', title: t.Text.split(' - ')[0], snippet: t.Text, url: t.FirstURL || null });
  }
  return out;
}

async function wikipedia(query) {
  const search = await getJSON(
    `https://en.wikipedia.org/w/api.php?action=query&list=search&srsearch=${encodeURIComponent(query)}&format=json&srlimit=3&origin=*`
  );
  const hits = search?.query?.search || [];
  const results = [];
  for (const hit of hits) {
    const summary = await getJSON(
      `https://en.wikipedia.org/api/rest_v1/page/summary/${encodeURIComponent(hit.title.replace(/ /g, '_'))}`
    );
    results.push({
      source: 'wikipedia',
      title: hit.title,
      snippet: summary?.extract || String(hit.snippet || '').replace(/<[^>]+>/g, ''),
      url: summary?.content_urls?.desktop?.page || `https://en.wikipedia.org/wiki/${encodeURIComponent(hit.title)}`
    });
  }
  return results;
}

async function hackerNews(query) {
  const data = await getJSON(
    `https://hn.algolia.com/api/v1/search?query=${encodeURIComponent(query)}&tags=story&hitsPerPage=5`
  );
  return (data?.hits || []).map(h => ({
    source: 'hackernews',
    title: h.title,
    snippet: `${h.points ?? 0} points, ${h.num_comments ?? 0} comments (${String(h.created_at || '').slice(0, 10)})`,
    url: h.url || `https://news.ycombinator.com/item?id=${h.objectID}`
  }));
}

async function arxiv(query) {
  const xml = await getText(
    `https://export.arxiv.org/api/query?search_query=all:${encodeURIComponent(query)}&start=0&max_results=3`
  );
  if (!xml) return [];
  const entries = xml.split('<entry>').slice(1);
  return entries.map(e => ({
    source: 'arxiv',
    title: (e.match(/<title>([\s\S]*?)<\/title>/)?.[1] || '').trim().replace(/\s+/g, ' '),
    snippet: (e.match(/<summary>([\s\S]*?)<\/summary>/)?.[1] || '').trim().replace(/\s+/g, ' ').slice(0, 500),
    url: (e.match(/<id>([\s\S]*?)<\/id>/)?.[1] || '').trim()
  }));
}

const SOURCES = { duckduckgo, wikipedia, hackernews: hackerNews, arxiv };

// --- public API -----------------------------------------------------------

/**
 * Query several free sources at once and merge the results.
 * @param {string}   query
 * @param {string[]} [sources]  subset of Object.keys(SOURCES); defaults to all
 */
async function research(query, sources) {
  if (!query || !query.trim()) return { ok: false, result: 'Empty query.' };
  const picked = (sources && sources.length ? sources : Object.keys(SOURCES)).filter(s => SOURCES[s]);

  // Promise.allSettled, not Promise.all: one source being down or rate-limited
  // must degrade the result set, never fail the whole research call.
  const settled = await Promise.allSettled(picked.map(s => SOURCES[s](query)));
  const results = settled.flatMap(r => (r.status === 'fulfilled' ? r.value : []));
  const failed = picked.filter((s, i) => settled[i].status === 'rejected');

  if (results.length === 0) {
    return {
      ok: true,
      result: {
        query,
        results: [],
        note:
          'No free source returned anything for this query. These sources cover facts, encyclopedic topics, ' +
          'technical discussion and papers — they do not cover long-tail commercial or local-business queries. ' +
          'Tell the user plainly that you could not find this rather than guessing.'
      }
    };
  }

  return {
    ok: true,
    result: {
      query,
      sourcesQueried: picked,
      sourcesFailed: failed,
      count: results.length,
      results: results.slice(0, 15),
      note: 'Snippets only. Use read_url on a promising result to read the actual page before relying on it.'
    }
  };
}

/** Fetch one URL and convert it to readable plain text. */
async function readUrl(url) {
  if (!/^https?:\/\//i.test(url || '')) {
    return { ok: false, result: 'read_url needs a full http(s):// URL.' };
  }
  let host;
  try {
    host = new URL(url).hostname;
  } catch {
    return { ok: false, result: 'Malformed URL.' };
  }
  if (BLOCKED_HOST_RE.test(host)) {
    return { ok: false, result: 'Refused: that host is on the loopback/private/metadata blocklist.' };
  }

  const html = await getText(url);
  if (html === null) return { ok: false, result: `Could not fetch ${url} (network error, timeout, or non-200 status).` };

  const text = htmlToText(html);
  return {
    ok: true,
    result: {
      url,
      title: (html.match(/<title[^>]*>([\s\S]*?)<\/title>/i)?.[1] || '').trim().slice(0, 300) || null,
      chars: text.length,
      truncated: text.length >= MAX_PAGE_CHARS,
      text: text.slice(0, MAX_PAGE_CHARS)
    }
  };
}

function htmlToText(html) {
  return String(html)
    .replace(/<script[\s\S]*?<\/script>/gi, ' ')
    .replace(/<style[\s\S]*?<\/style>/gi, ' ')
    .replace(/<noscript[\s\S]*?<\/noscript>/gi, ' ')
    .replace(/<!--[\s\S]*?-->/g, ' ')
    .replace(/<\/(p|div|section|article|li|tr|h[1-6])>/gi, '\n')
    .replace(/<br\s*\/?>/gi, '\n')
    .replace(/<[^>]+>/g, ' ')
    .replace(/&nbsp;/g, ' ')
    .replace(/&amp;/g, '&')
    .replace(/&lt;/g, '<')
    .replace(/&gt;/g, '>')
    .replace(/&quot;/g, '"')
    .replace(/&#39;/g, "'")
    .replace(/[ \t]+/g, ' ')
    .replace(/\n\s*\n\s*\n+/g, '\n\n')
    .trim();
}

/**
 * Generic outbound HTTP call — the "connect to anything" primitive behind the
 * HTTP workflow node and the http_request tool. Deliberately NOT a free-for-all:
 *
 *  - private/loopback/metadata hosts are blocked (SSRF)
 *  - it is registered as a RISKY tool, so an agent calling it hits the human
 *    approval modal first
 *  - Lockdown Mode is enforced by the caller in main.js before we get here
 */
async function httpRequest({ url, method = 'GET', headers = {}, body = null }) {
  if (!/^https?:\/\//i.test(url || '')) return { ok: false, result: 'http_request needs a full http(s):// URL.' };
  let host;
  try {
    host = new URL(url).hostname;
  } catch {
    return { ok: false, result: 'Malformed URL.' };
  }
  if (BLOCKED_HOST_RE.test(host)) {
    return { ok: false, result: 'Refused: that host is on the loopback/private/metadata blocklist.' };
  }

  const safeMethod = String(method).toUpperCase();
  if (!['GET', 'POST', 'PUT', 'PATCH', 'DELETE'].includes(safeMethod)) {
    return { ok: false, result: `Unsupported method "${method}".` };
  }

  const { signal, done } = withTimeout(FETCH_TIMEOUT_MS);
  try {
    const res = await fetch(url, {
      method: safeMethod,
      headers: { 'User-Agent': USER_AGENT, ...headers },
      body: body && safeMethod !== 'GET' ? (typeof body === 'string' ? body : JSON.stringify(body)) : undefined,
      signal
    });
    const text = (await res.text()).slice(0, 20000);
    let parsed = null;
    try { parsed = JSON.parse(text); } catch { /* not JSON, text is fine */ }
    return { ok: true, result: { status: res.status, ok: res.ok, json: parsed, text: parsed ? null : text } };
  } catch (err) {
    return { ok: false, result: `Request failed: ${String(err?.message || err)}` };
  } finally {
    done();
  }
}

module.exports = { research, readUrl, httpRequest, htmlToText };
