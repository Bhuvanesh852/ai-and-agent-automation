// OpenAI-compatible local HTTP API — for local clients only (curl, editor
// extensions, scripts on this machine), NOT a public inference server.
//
// Security posture (matches the project's own Security Center rules):
// - Binds to 127.0.0.1 by default. An explicit, off-by-default "LAN mode"
//   toggle allows binding to 0.0.0.0 for other devices on your network to
//   reach it — the bearer token is still required either way; this is the
//   full scope of "distributed" access here (one machine serving many local
//   clients), not multi-node sharded inference.
// - Requires a bearer token on every request (generated locally, shown once
//   in the Local API panel, regenerable). Without it, any other process on
//   the machine could silently call into your configured provider keys.
// - Does not expose the agent tool-calling loop (file/terminal/git/RAG) —
//   only plain chat completions against configured models. Tool-using
//   agent orchestration stays a renderer-side feature with its own
//   approval gates; this endpoint deliberately has less power, not more.
// - Honors Lockdown Mode exactly like the rest of the app: cloud provider
//   calls are refused while it's active; local Ollama/GGUF still work.
//
// Uses only Node's built-in http module — no new HTTP framework dependency.

const http = require('node:http');
const crypto = require('node:crypto');
const localInference = require('./localInference.js');

let server = null;
let boundPort = null;
let boundHost = null;

// Single source of truth for cloud model IDs, shared with the renderer's
// registry (src/gateway/registry.js) via shared/cloudModels.json — plain
// JSON loads fine under both Node's CJS require() (here) and Vite's ESM
// import (renderer), so the two lists can no longer drift out of sync the
// way two hand-maintained copies previously did.
const CLOUD_MODELS = require('../shared/cloudModels.json');

function splitModelString(model) {
  const idx = String(model || '').indexOf(':');
  if (idx === -1) return { provider: model, modelId: '' };
  return { provider: model.slice(0, idx), modelId: model.slice(idx + 1) };
}

function json(res, status, body) {
  const text = JSON.stringify(body);
  res.writeHead(status, { 'Content-Type': 'application/json', 'Content-Length': Buffer.byteLength(text) });
  res.end(text);
}

function readBody(req) {
  return new Promise((resolve, reject) => {
    let data = '';
    req.on('data', chunk => {
      data += chunk;
      if (data.length > 5 * 1024 * 1024) {
        reject(new Error('Request body too large.'));
        req.destroy();
      }
    });
    req.on('end', () => resolve(data));
    req.on('error', reject);
  });
}

async function callOllamaDirect(modelId, messages) {
  const res = await fetch('http://127.0.0.1:11434/api/chat', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ model: modelId, messages, stream: false })
  });
  const data = await res.json();
  if (!res.ok) throw new Error(data?.error || `Ollama request failed (${res.status}).`);
  return data?.message?.content || '';
}

async function callCloudDirect({ provider, modelId, messages, getCredential, isLockedDown }) {
  if (isLockedDown()) {
    throw new Error('Lockdown Mode is active — external network calls are disabled.');
  }
  const key = getCredential(provider);
  if (!key) throw new Error(`No ${provider} API key configured (Settings in the desktop app).`);

  if (provider === 'groq' || provider === 'openrouter') {
    const url = provider === 'groq'
      ? 'https://api.groq.com/openai/v1/chat/completions'
      : 'https://openrouter.ai/api/v1/chat/completions';
    const res = await fetch(url, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${key}` },
      body: JSON.stringify({ model: modelId, messages })
    });
    const data = await res.json();
    if (!res.ok) throw new Error(data?.error?.message || `${provider} request failed (${res.status}).`);
    return data.choices?.[0]?.message?.content || '';
  }

  if (provider === 'gemini') {
    const contents = messages.filter(m => m.role !== 'system').map(m => ({
      role: m.role === 'assistant' ? 'model' : 'user',
      parts: [{ text: m.content }]
    }));
    const systemMsg = messages.find(m => m.role === 'system');
    const url = `https://generativelanguage.googleapis.com/v1beta/models/${modelId}:generateContent`;
    const res = await fetch(url, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'x-goog-api-key': key },
      body: JSON.stringify({ contents, ...(systemMsg ? { systemInstruction: { parts: [{ text: systemMsg.content }] } } : {}) })
    });
    const data = await res.json();
    if (!res.ok) throw new Error(data?.error?.message || `Gemini request failed (${res.status}).`);
    return data.candidates?.[0]?.content?.parts?.map(p => p.text).join('') || '';
  }

  throw new Error(`Unknown provider: ${provider}`);
}

async function streamOllama(modelId, messages, res, sendChunk) {
  const upstream = await fetch('http://127.0.0.1:11434/api/chat', {
    method: 'POST', headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ model: modelId, messages, stream: true })
  });
  if (!upstream.ok || !upstream.body) throw new Error(`Ollama stream failed (${upstream.status}).`);
  const reader = upstream.body.getReader();
  const decoder = new TextDecoder();
  let buf = '';
  while (true) {
    const { done, value } = await reader.read();
    if (done) break;
    buf += decoder.decode(value, { stream: true });
    let nl;
    while ((nl = buf.indexOf('\n')) !== -1) {
      const line = buf.slice(0, nl).trim();
      buf = buf.slice(nl + 1);
      if (!line) continue;
      const obj = JSON.parse(line);
      if (obj.message?.content) sendChunk(obj.message.content);
      if (obj.done) return;
    }
  }
}

async function streamLocal(modelId, messages, sendChunk) {
  const r = await localInference.chatStream({ modelPath: modelId, messages, onToken: sendChunk });
  if (!r.ok) throw new Error(r.error);
}

// Groq/OpenRouter are OpenAI-compatible: pipe their SSE straight through
// rather than re-implementing chunk parsing — this is genuine token-by-token
// streaming, not synthesized.
async function streamCloudPassthrough({ provider, modelId, messages, getCredential, res }) {
  const key = getCredential(provider);
  if (!key) throw new Error(`No ${provider} API key configured.`);
  const url = provider === 'groq'
    ? 'https://api.groq.com/openai/v1/chat/completions'
    : 'https://openrouter.ai/api/v1/chat/completions';
  const upstream = await fetch(url, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${key}` },
    body: JSON.stringify({ model: modelId, messages, stream: true })
  });
  if (!upstream.ok || !upstream.body) {
    const errText = await upstream.text().catch(() => '');
    throw new Error(`${provider} stream failed (${upstream.status}): ${errText.slice(0, 200)}`);
  }
  res.writeHead(200, { 'Content-Type': 'text/event-stream', 'Cache-Control': 'no-cache', Connection: 'keep-alive' });
  const reader = upstream.body.getReader();
  const decoder = new TextDecoder();
  while (true) {
    const { done, value } = await reader.read();
    if (done) break;
    res.write(decoder.decode(value, { stream: true }));
  }
  res.end();
}

function makeHandler({ token, getCredential, isLockedDown, listLocalModels, onWebhook }) {
  return async (req, res) => {
    const url = new URL(req.url, 'http://127.0.0.1');

    if (url.pathname === '/health') {
      return json(res, 200, { status: 'ok' });
    }

    // Everything past this point requires the bearer token.
    const auth = req.headers['authorization'] || '';
    const provided = auth.startsWith('Bearer ') ? auth.slice(7) : null;
    if (!provided || provided !== token) {
      return json(res, 401, { error: { message: 'Missing or invalid bearer token.' } });
    }

    // --- Workflow webhook trigger --------------------------------------
    // POST /webhook/<path> fires any workflow whose trigger.webhook node
    // declares that path. Sits BEHIND the same bearer token as everything
    // else: an unauthenticated webhook endpoint on a machine bound to the
    // LAN would be a remote trigger for arbitrary local automation.
    if (url.pathname.startsWith('/webhook/') && req.method === 'POST') {
      const hookPath = decodeURIComponent(url.pathname.slice('/webhook/'.length));
      if (!hookPath) return json(res, 400, { error: { message: 'Missing webhook path.' } });
      if (typeof onWebhook !== 'function') {
        return json(res, 503, { error: { message: 'No webhook handler is attached (is the app window open?).' } });
      }
      let payload = null;
      try {
        const raw = await readBody(req);
        try { payload = JSON.parse(raw); } catch { payload = raw; }
      } catch (err) {
        return json(res, 400, { error: { message: String(err?.message || err) } });
      }
      // Fire-and-forget: the workflow runs in the renderer and may take
      // minutes, so the caller gets an immediate accepted-response rather
      // than a held-open connection.
      onWebhook({ path: hookPath, payload });
      return json(res, 202, { ok: true, accepted: hookPath });
    }

    if (url.pathname === '/v1/models' && req.method === 'GET') {
      const localFiles = await listLocalModels();
      const data = [
        ...CLOUD_MODELS.map(m => ({ id: `${m.provider}:${m.model_id}`, object: 'model', owned_by: m.provider })),
        ...localFiles.map(f => ({ id: `local:${f.path}`, object: 'model', owned_by: 'local-native' }))
      ];
      return json(res, 200, { object: 'list', data });
    }

    if (url.pathname === '/v1/chat/completions' && req.method === 'POST') {
      let body;
      try {
        body = JSON.parse(await readBody(req));
      } catch {
        return json(res, 400, { error: { message: 'Invalid JSON body.' } });
      }

      const { model, messages, stream } = body || {};
      if (!model || !Array.isArray(messages)) {
        return json(res, 400, { error: { message: '"model" and "messages" are required.' } });
      }
      const { provider, modelId } = splitModelString(model);

      if (stream) {
        if (isLockedDown() && provider !== 'ollama' && provider !== 'local') {
          return json(res, 403, { error: { message: 'Lockdown Mode is active — external network calls are disabled.' } });
        }
        try {
          if (provider === 'groq' || provider === 'openrouter') {
            return await streamCloudPassthrough({ provider, modelId, messages, getCredential, res });
          }
          res.writeHead(200, { 'Content-Type': 'text/event-stream', 'Cache-Control': 'no-cache', Connection: 'keep-alive' });
          const id = `chatcmpl-${crypto.randomUUID()}`;
          const created = Math.floor(Date.now() / 1000);
          const sendChunk = (text) => {
            const chunk = { id, object: 'chat.completion.chunk', created, model, choices: [{ index: 0, delta: { content: text }, finish_reason: null }] };
            res.write(`data: ${JSON.stringify(chunk)}\n\n`);
          };
          if (provider === 'ollama') await streamOllama(modelId, messages, res, sendChunk);
          else if (provider === 'local') await streamLocal(modelId, messages, sendChunk);
          else if (provider === 'gemini') { sendChunk(await callCloudDirect({ provider, modelId, messages, getCredential, isLockedDown })); }
          else throw new Error(`Unknown provider: ${provider}`);
          res.write(`data: ${JSON.stringify({ id, object: 'chat.completion.chunk', created, model, choices: [{ index: 0, delta: {}, finish_reason: 'stop' }] })}\n\n`);
          res.write('data: [DONE]\n\n');
          return res.end();
        } catch (err) {
          // Headers may already be sent for a real stream — best effort.
          if (!res.headersSent) return json(res, 502, { error: { message: String(err?.message || err) } });
          res.write(`data: ${JSON.stringify({ error: { message: String(err?.message || err) } })}\n\n`);
          return res.end();
        }
      }

      let content;
      try {
        if (provider === 'ollama') {
          content = await callOllamaDirect(modelId, messages);
        } else if (provider === 'local') {
          const r = await localInference.chat({ modelPath: modelId, messages });
          if (!r.ok) throw new Error(r.error);
          content = r.content;
        } else {
          content = await callCloudDirect({ provider, modelId, messages, getCredential, isLockedDown });
        }
      } catch (err) {
        return json(res, 502, { error: { message: String(err?.message || err) } });
      }

      const completion = {
        id: `chatcmpl-${crypto.randomUUID()}`,
        object: 'chat.completion',
        created: Math.floor(Date.now() / 1000),
        model,
        choices: [{ index: 0, message: { role: 'assistant', content }, finish_reason: 'stop' }]
      };
      return json(res, 200, completion);
    }

    return json(res, 404, { error: { message: 'Not found.' } });
  };
}

function generateToken() {
  return crypto.randomBytes(24).toString('hex');
}

function start({ port, host, token, getCredential, isLockedDown, listLocalModels, onWebhook }) {
  return new Promise((resolve, reject) => {
    if (server) {
      return resolve({ ok: true, alreadyRunning: true, port: boundPort });
    }
    server = http.createServer(makeHandler({ token, getCredential, isLockedDown, listLocalModels, onWebhook }));
    server.on('error', (err) => {
      server = null;
      reject(err);
    });
    const bindHost = host === 'lan' ? '0.0.0.0' : '127.0.0.1';
    server.listen(port, bindHost, () => {
      boundPort = port;
      boundHost = bindHost;
      resolve({ ok: true, port, host: bindHost });
    });
  });
}

function stop() {
  return new Promise((resolve) => {
    if (!server) return resolve({ ok: true });
    server.close(() => {
      server = null;
      boundPort = null;
      boundHost = null;
      resolve({ ok: true });
    });
  });
}

function status() {
  return { running: !!server, port: boundPort, host: boundHost };
}

module.exports = { start, stop, status, generateToken };
