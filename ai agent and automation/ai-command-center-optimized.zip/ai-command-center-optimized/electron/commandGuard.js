// Allowlist/denylist-based command risk classification for run_terminal.
// "Block dangerous commands by default" + "Require approval for system-level
// commands" from the security spec. This runs BEFORE the human approval
// modal even appears, so a denied command never reaches exec() at all —
// approval only gates commands that are risky-but-legitimate, never ones
// on the hard block list.

const BLOCK_PATTERNS = [
  { id: 'rm_rf_root', re: /\brm\s+-rf\s+(\/|~|\*|C:\\|\/\*)\b/i, reason: 'Recursive force-delete of a root/home/drive path.' },
  { id: 'del_system', re: /\bdel\s+\/[sf].*[Cc]:\\\\?\s*$/i, reason: 'Recursive delete targeting a system drive.' },
  { id: 'format_drive', re: /\bformat\s+[a-zA-Z]:/i, reason: 'Disk format command.' },
  { id: 'diskpart', re: /\bdiskpart\b/i, reason: 'Low-level disk partitioning tool.' },
  { id: 'shutdown', re: /\b(shutdown|restart-computer)\b/i, reason: 'System power-state command.' },
  { id: 'reg_delete', re: /\breg\s+delete\b/i, reason: 'Windows Registry deletion.' },
  { id: 'disable_defender', re: /\bset-mppreference\b.*disable|disable-windowsdefender|netsh\s+advfirewall\s+set.*state\s+off/i, reason: 'Attempts to disable Windows security protections — never allowed.' },
  { id: 'fork_bomb', re: /:\(\)\s*\{\s*:\|:&\s*\};:/, reason: 'Fork bomb pattern.' },
  { id: 'curl_pipe_shell', re: /\b(curl|wget|iwr|invoke-webrequest)\b[^\n]*\|\s*(sh|bash|powershell|iex)\b/i, reason: 'Downloads and immediately executes remote code — classic supply-chain risk.' },
  { id: 'credential_dump', re: /\b(mimikatz|lsass|sam\s+hive|reg\s+save\s+hklm\\sam)\b/i, reason: 'Credential-dumping tooling/target.' },
  { id: 'reverse_shell', re: /\b(nc|ncat|netcat)\s+.*-e\s|\/dev\/tcp\/|bash\s+-i\s+>&|python[23]?\s+-c\s+.*socket\.socket/i, reason: 'Reverse-shell pattern — establishes an outbound interactive shell.' },
  { id: 'base64_exec', re: /(base64\s+-d|frombase64string|-decode)[^\n]*\|\s*(sh|bash|powershell|iex)/i, reason: 'Decodes and executes an obfuscated payload — common malware-delivery pattern.' },
  { id: 'lolbin_download', re: /\b(certutil\s+-urlcache|certutil\s+-decode|bitsadmin\s+\/transfer|mshta\b|regsvr32\s+\/[isu]:)/i, reason: 'Living-off-the-land binary abused for remote payload download/execution.' },
  { id: 'persistence', re: /\b(schtasks\s+\/create|new-scheduledtask|crontab\s+-e|reg\s+add\s+.*\\run\b)/i, reason: 'Installs a persistence mechanism (scheduled task / registry run key / cron job).' },
  { id: 'firewall_or_av_tamper', re: /\b(netsh\s+advfirewall\s+set|ufw\s+disable|iptables\s+-F|Set-MpPreference\s+-DisableRealtimeMonitoring)/i, reason: 'Disables or flushes host firewall/antivirus protection.' },
  { id: 'ransomware_like_encrypt', re: /\bopenssl\s+enc\b.*-in\s+.*-out\b|Get-ChildItem\s+-Recurse.*\|\s*.*Encrypt/i, reason: 'Bulk-encrypts files matching a mass-encryption pattern.' }
];

// Patterns that are legitimate but still get flagged for extra scrutiny in
// the approval modal (shown, not blocked).
const CAUTION_PATTERNS = [
  { id: 'sudo_or_admin', re: /\bsudo\b|\brunas\b/i, reason: 'Requests elevated privileges.' },
  { id: 'network_tool', re: /\b(curl|wget|iwr|invoke-webrequest|ssh|scp)\b/i, reason: 'Performs network access.' },
  { id: 'package_install', re: /\b(npm|pip|choco|winget)\s+(install|add)\b/i, reason: 'Installs new software/dependencies.' },
  { id: 'git_push_force', re: /\bgit\s+push\s+.*--force/i, reason: 'Force-push can overwrite remote history.' },
  { id: 'file_upload', re: /\b(curl|wget|iwr)\b[^\n]*(-F|--upload-file|-T)\b/i, reason: 'Uploads local file contents to a remote endpoint — verify the destination is expected.' },
  { id: 'env_dump', re: /\b(printenv|env\b|Get-ChildItem\s+Env:|set\s*$)/i, reason: 'Dumps environment variables, which may contain secrets, to output.' },
  { id: 'wide_permission_chmod', re: /\bchmod\s+(-R\s+)?777\b/i, reason: 'Grants world read/write/execute permissions.' }
];

function classifyCommand(command) {
  const cmd = String(command || '');
  for (const p of BLOCK_PATTERNS) {
    if (p.re.test(cmd)) {
      return { verdict: 'blocked', ruleId: p.id, reason: p.reason };
    }
  }
  for (const p of CAUTION_PATTERNS) {
    if (p.re.test(cmd)) {
      return { verdict: 'caution', ruleId: p.id, reason: p.reason };
    }
  }
  return { verdict: 'allowed' };
}

module.exports = { classifyCommand };
