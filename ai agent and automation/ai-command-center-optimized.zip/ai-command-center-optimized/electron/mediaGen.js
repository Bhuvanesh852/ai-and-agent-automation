// Image generation — keyless, free tier only, consistent with the rest of
// electron/webResearch.js. Uses Pollinations.ai's public text-to-image
// endpoint, which requires no account and no API key.
//
// HONESTY NOTE: there is no reliable free, keyless *video* generation API
// as of this writing — every real video-gen service (Runway, Pika, Sora,
// Luma, Veo, etc.) requires a paid key. Rather than fake a "generate_video"
// tool that silently fails or produces something misleading, this module
// only implements image generation. See README for how to wire a paid
// video provider in later if the user adds a key.

const fs = require('node:fs/promises');
const path = require('node:path');

const REQUEST_TIMEOUT_MS = 45000; // image models are slow on the free tier
const MAX_PROMPT_CHARS = 800;

function withTimeout(ms) {
  const c = new AbortController();
  const t = setTimeout(() => c.abort(), ms);
  return { signal: c.signal, done: () => clearTimeout(t) };
}

function slugify(text) {
  return String(text)
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/(^-|-$)/g, '')
    .slice(0, 40) || 'image';
}

async function generateImage({ prompt, workspaceRoot, width, height }) {
  if (!prompt || !String(prompt).trim()) {
    return { ok: false, result: 'A non-empty prompt is required.' };
  }
  if (!workspaceRoot) {
    return { ok: false, result: 'No workspace folder is open. Open a project folder first (Sidebar → Files → Open Folder).' };
  }

  const safePrompt = String(prompt).slice(0, MAX_PROMPT_CHARS);
  const w = Math.min(Math.max(Number(width) || 768, 256), 1536);
  const h = Math.min(Math.max(Number(height) || 768, 256), 1536);
  // "seed" makes repeated calls with the same prompt return different
  // images instead of a cached identical one.
  const seed = Math.floor(Math.random() * 1_000_000_000);
  const url =
    `https://image.pollinations.ai/prompt/${encodeURIComponent(safePrompt)}` +
    `?width=${w}&height=${h}&seed=${seed}&nologo=true`;

  const { signal, done } = withTimeout(REQUEST_TIMEOUT_MS);
  let res;
  try {
    res = await fetch(url, { signal, headers: { 'User-Agent': 'AI-Command-Center/0.5 (local desktop app)' } });
  } catch (err) {
    done();
    return { ok: false, result: `Image generation request failed or timed out: ${err.message || err}` };
  }
  done();

  if (!res || !res.ok) {
    return { ok: false, result: `Image provider returned an error (status ${res ? res.status : 'unknown'}). Free-tier hosted models occasionally queue or rate-limit — try again in a moment.` };
  }

  const buf = Buffer.from(await res.arrayBuffer());
  if (buf.length < 500) {
    // Pollinations returns a tiny error/placeholder payload on failure
    // instead of a real HTTP error status in some cases.
    return { ok: false, result: 'Image provider returned an empty or invalid image. Try rephrasing the prompt or retrying.' };
  }

  const outDir = path.resolve(workspaceRoot, 'ai-outputs', 'images');
  await fs.mkdir(outDir, { recursive: true });
  const filename = `${Date.now()}-${slugify(safePrompt)}.jpg`;
  const outPath = path.join(outDir, filename);
  await fs.writeFile(outPath, buf);

  return {
    ok: true,
    result: {
      path: path.relative(workspaceRoot, outPath),
      width: w,
      height: h,
      prompt: safePrompt,
      bytes: buf.length,
      provider: 'Pollinations.ai (free, keyless)'
    }
  };
}

module.exports = { generateImage };
