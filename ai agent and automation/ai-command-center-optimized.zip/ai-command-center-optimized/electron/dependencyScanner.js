// Lightweight, local, offline dependency review. This does NOT check a live
// vulnerability database (no network access is made on the app's behalf here)
// — it flags common risk *patterns* (unpinned "*"/"latest" versions, pre-1.0
// packages) so findings are honest about what was and wasn't verified.
const fs = require('node:fs/promises');
const path = require('node:path');

async function readJsonSafe(file) {
  try {
    return JSON.parse(await fs.readFile(file, 'utf-8'));
  } catch {
    return null;
  }
}

function classifyVersion(spec) {
  if (!spec) return null;
  if (spec === '*' || spec === 'latest') {
    return { risk: 'Medium', reason: 'Unpinned version ("*"/"latest") — can silently pull in breaking or compromised releases.' };
  }
  const cleaned = spec.replace(/^[\^~>=<]+/, '');
  const major = parseInt(cleaned.split('.')[0], 10);
  if (!Number.isNaN(major) && major === 0) {
    return { risk: 'Low', reason: 'Pre-1.0 package — API and security posture may still be unstable.' };
  }
  return null;
}

async function scanDependencies(workspaceRoot) {
  if (!workspaceRoot) {
    return { ok: false, result: 'No workspace folder is open.' };
  }

  const findings = [];
  let manifestsFound = 0;

  const pkgPath = path.join(workspaceRoot, 'package.json');
  const pkg = await readJsonSafe(pkgPath);
  if (pkg) {
    manifestsFound++;
    for (const section of ['dependencies', 'devDependencies']) {
      const deps = pkg[section] || {};
      for (const [name, spec] of Object.entries(deps)) {
        const flagged = classifyVersion(spec);
        if (flagged) {
          findings.push({ manifest: 'package.json', section, name, spec, severity: flagged.risk, reason: flagged.reason });
        }
      }
    }
  }

  const reqPath = path.join(workspaceRoot, 'requirements.txt');
  try {
    const content = await fs.readFile(reqPath, 'utf-8');
    manifestsFound++;
    for (const line of content.split('\n')) {
      const trimmed = line.trim();
      if (!trimmed || trimmed.startsWith('#')) continue;
      if (!trimmed.includes('==') && !trimmed.includes('>=')) {
        findings.push({
          manifest: 'requirements.txt', section: 'requirements', name: trimmed, spec: '(unpinned)',
          severity: 'Medium', reason: 'No pinned version — build is not reproducible and can pull unexpected releases.'
        });
      }
    }
  } catch {
    // no requirements.txt, that's fine
  }

  return {
    ok: true,
    result: {
      manifestsFound,
      findings,
      note: manifestsFound === 0
        ? 'No package.json or requirements.txt found at the workspace root.'
        : 'Offline pattern check only — this does not query a live CVE database. Treat as a starting point, not a full audit.',
      scannedAt: Date.now()
    }
  };
}

module.exports = { scanDependencies };
