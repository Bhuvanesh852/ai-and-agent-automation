// Structured "run this snippet" execution for the coding skill, distinct
// from run_terminal (arbitrary shell string). Writes the snippet to a
// scratch file OUTSIDE the user's workspace (in the app's userData/tmp
// dir) so a generated snippet can never overwrite a real project file by
// filename collision, then executes it with the matching interpreter.
//
// Still gated the same way run_terminal is (Lockdown Mode + human
// approval, since 'execute_code' is a 'risky' tool) — this does not
// grant any capability run_terminal didn't already have, it's just a
// friendlier structured entry point for the "write + run code" skill.

const fs = require('node:fs/promises');
const path = require('node:path');
const os = require('node:os');
const { execFile } = require('node:child_process');

const EXEC_TIMEOUT_MS = 20000;
const MAX_OUTPUT_CHARS = 20000;

const RUNNERS = {
  javascript: { cmd: 'node', ext: '.js', args: (file) => [file] },
  js: { cmd: 'node', ext: '.js', args: (file) => [file] },
  python: { cmd: 'python3', ext: '.py', args: (file) => [file] },
  py: { cmd: 'python3', ext: '.py', args: (file) => [file] }
};

function runFile(file, args, cwd) {
  return new Promise((resolve) => {
    execFile(file, args, { cwd, timeout: EXEC_TIMEOUT_MS, maxBuffer: 5 * 1024 * 1024 }, (err, stdout, stderr) => {
      resolve({
        ok: !err,
        stdout: String(stdout || '').slice(0, MAX_OUTPUT_CHARS),
        stderr: String(stderr || '').slice(0, MAX_OUTPUT_CHARS),
        error: err ? String(err.message || err) : null
      });
    });
  });
}

async function executeCode({ language, code }) {
  const lang = String(language || 'javascript').toLowerCase();
  const runner = RUNNERS[lang];
  if (!runner) {
    return { ok: false, result: `Unsupported language "${language}". Supported: javascript, python.` };
  }
  if (!code || !String(code).trim()) {
    return { ok: false, result: 'No code provided.' };
  }

  const scratchDir = await fs.mkdtemp(path.join(os.tmpdir(), 'acc-run-'));
  const file = path.join(scratchDir, `snippet${runner.ext}`);
  try {
    await fs.writeFile(file, code, 'utf-8');
    const res = await runFile(runner.cmd, runner.args(file), scratchDir);
    if (!res.ok && /ENOENT/i.test(res.error || '')) {
      return {
        ok: false,
        result: `"${runner.cmd}" was not found on this machine. Install it to run ${lang} snippets (Node.js is bundled with this app already; Python is a separate install).`
      };
    }
    return {
      ok: res.ok,
      result: { stdout: res.stdout, stderr: res.stderr, error: res.error, language: lang }
    };
  } finally {
    await fs.rm(scratchDir, { recursive: true, force: true }).catch(() => {});
  }
}

module.exports = { executeCode };
