// Local-only, static-analysis cybersecurity scanner. Same shape and
// conventions as secretScanner.js / dependencyScanner.js: no network calls,
// no telemetry, everything stays on-device. This scanner looks specifically
// for the class of bugs the CVE/OWASP world calls "insecure network &
// execution patterns" — the kind of thing that turns an XSS or a
// compromised dependency into full compromise:
//   - TLS/certificate verification disabled
//   - eval()/new Function() on non-constant input
//   - shell exec (exec/execSync) built from string concatenation instead of
//     execFile/spawn with an argument array
//   - wildcard/reflected CORS (Access-Control-Allow-Origin: * or echoing
//     request Origin back unchecked)
//   - hardcoded internal/link-local IPs or plaintext http:// URLs carrying
//     what looks like a credential in the query string
//
// This is a heuristic linter, not a penetration test or a live network
// monitor — false positives/negatives are expected, same honesty stance as
// dependencyScanner.js already takes for CVEs.

const fs = require('node:fs/promises');
const path = require('node:path');

const SKIP_DIRS = new Set(['node_modules', '.git', 'dist', 'release', '.next', 'build', '.venv', '__pycache__']);
const TEXT_EXT = new Set(['.js', '.jsx', '.ts', '.tsx', '.py', '.go', '.rb', '.php', '.java']);
const MAX_FILES = 2000;
const MAX_FILE_BYTES = 2 * 1024 * 1024;

const RULES = [
  {
    id: 'tls_verify_disabled',
    label: 'TLS certificate verification disabled',
    severity: 'Critical',
    regex: /NODE_TLS_REJECT_UNAUTHORIZED\s*=\s*['"]?0['"]?|rejectUnauthorized\s*:\s*false|verify\s*=\s*False/g
  },
  {
    id: 'eval_dynamic',
    label: 'eval() / new Function() on dynamic input',
    severity: 'High',
    regex: /\beval\s*\(\s*(?!['"`])|new\s+Function\s*\(\s*(?!['"`]"use strict)/g
  },
  {
    id: 'shell_exec_concat',
    label: 'Shell command built via string concatenation (injection risk)',
    severity: 'High',
    regex: /\b(?:exec|execSync)\s*\(\s*[`'"][^`'"]*\$\{|\b(?:exec|execSync)\s*\(\s*[^,)]+\+/g
  },
  {
    id: 'cors_wildcard',
    label: 'Wildcard or reflected CORS origin',
    severity: 'Medium',
    regex: /Access-Control-Allow-Origin['"]?\s*[:,]\s*['"]\*['"]|Access-Control-Allow-Origin['"]?\s*[:,]\s*req(uest)?\.headers\[['"]origin['"]\]/gi
  },
  {
    id: 'insecure_http_with_credential',
    label: 'Plaintext http:// URL with an apparent credential/token in it',
    severity: 'Medium',
    regex: /http:\/\/[^\s'"]*[?&](?:token|key|apikey|api_key|password|secret)=[^\s'"&]+/gi
  },
  {
    id: 'disabled_csrf',
    label: 'CSRF protection explicitly disabled',
    severity: 'Medium',
    regex: /csrf\s*:\s*false|@csrf_exempt|CSRF_ENABLED\s*=\s*False/gi
  }
];

async function walk(dir, root, out, budget) {
  if (budget.count >= MAX_FILES) return;
  let entries;
  try {
    entries = await fs.readdir(dir, { withFileTypes: true });
  } catch {
    return;
  }
  for (const entry of entries) {
    if (budget.count >= MAX_FILES) return;
    if (entry.isDirectory()) {
      if (SKIP_DIRS.has(entry.name)) continue;
      await walk(path.join(dir, entry.name), root, out, budget);
    } else {
      budget.count++;
      const ext = path.extname(entry.name).toLowerCase();
      if (!TEXT_EXT.has(ext)) continue;
      const full = path.join(dir, entry.name);
      out.push({ full, rel: path.relative(root, full) });
    }
  }
}

async function scanNetwork(workspaceRoot) {
  if (!workspaceRoot) {
    return { ok: false, result: 'No workspace folder is open.' };
  }
  const files = [];
  await walk(workspaceRoot, workspaceRoot, files, { count: 0 });

  const findings = [];
  for (const f of files) {
    let content;
    try {
      const stat = await fs.stat(f.full);
      if (stat.size > MAX_FILE_BYTES) continue;
      content = await fs.readFile(f.full, 'utf-8');
    } catch {
      continue;
    }
    for (const rule of RULES) {
      rule.regex.lastIndex = 0;
      let match;
      while ((match = rule.regex.exec(content)) !== null) {
        const upToMatch = content.slice(0, match.index);
        const lineNum = upToMatch.split('\n').length;
        findings.push({ id: rule.id, label: rule.label, severity: rule.severity, file: f.rel, line: lineNum });
        if (findings.length > 500) break;
      }
      if (findings.length > 500) break;
    }
  }

  return {
    ok: true,
    result: {
      filesScanned: files.length,
      findings,
      scannedAt: Date.now()
    }
  };
}

module.exports = { scanNetwork };
