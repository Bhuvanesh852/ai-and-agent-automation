// Repository-aware indexing: symbol extraction, import/dependency graph,
// exact search (grep), and test discovery — all local, no model call.
//
// Honesty note: symbol/import extraction here is regex-based, not a real
// parser/AST (no tree-sitter or language-server dependency was added for
// this pass). It covers common JS/TS/Python patterns well but will miss
// unusual syntax (decorators-heavy metaprogramming, dynamic requires,
// re-exports via spread, etc.). That trade-off is stated here and in the
// tool descriptions rather than presented as a full language-aware index.

const fs = require('node:fs/promises');
const path = require('node:path');
const crypto = require('node:crypto');

const SKIP_DIRS = new Set(['node_modules', '.git', 'dist', 'release', 'build', '.venv', '__pycache__']);
const CODE_EXT = new Set(['.js', '.jsx', '.ts', '.tsx', '.py']);
const MAX_FILES = 1500;
const MAX_FILE_BYTES = 1.5 * 1024 * 1024;

const TEST_FILE_RE = /(^|[\\/])(test_[^\\/]+\.py|[^\\/]+_test\.py|[^\\/]+\.test\.[jt]sx?|[^\\/]+\.spec\.[jt]sx?)$/i;

function languageFor(ext) {
  if (ext === '.py') return 'python';
  if (['.ts', '.tsx'].includes(ext)) return 'typescript';
  return 'javascript';
}

// --- Symbol extraction (regex-based, per-language) ---
const JS_SYMBOL_PATTERNS = [
  { type: 'function', re: /(?:export\s+)?(?:async\s+)?function\s+([A-Za-z_$][\w$]*)\s*\(/g },
  { type: 'class', re: /(?:export\s+)?class\s+([A-Za-z_$][\w$]*)/g },
  { type: 'const-fn', re: /(?:export\s+)?const\s+([A-Za-z_$][\w$]*)\s*=\s*(?:async\s*)?\(?[^=]*\)?\s*=>/g },
  { type: 'export', re: /export\s+(?:default\s+)?(?:const|let|var)\s+([A-Za-z_$][\w$]*)/g }
];
const PY_SYMBOL_PATTERNS = [
  { type: 'function', re: /^\s*def\s+([A-Za-z_]\w*)\s*\(/gm },
  { type: 'class', re: /^\s*class\s+([A-Za-z_]\w*)/gm }
];

function extractSymbols(content, language) {
  const patterns = language === 'python' ? PY_SYMBOL_PATTERNS : JS_SYMBOL_PATTERNS;
  const symbols = [];
  for (const { type, re } of patterns) {
    re.lastIndex = 0;
    let m;
    while ((m = re.exec(content)) !== null) {
      const line = content.slice(0, m.index).split('\n').length;
      symbols.push({ name: m[1], type, line });
      if (symbols.length > 400) return symbols;
    }
  }
  return symbols;
}

// --- Import extraction (regex-based) ---
const JS_IMPORT_RE = /import\s+(?:[^'"]+from\s+)?['"]([^'"]+)['"]|require\(\s*['"]([^'"]+)['"]\s*\)/g;
const PY_IMPORT_RE = /^\s*(?:from\s+([\w.]+)\s+import|import\s+([\w.]+))/gm;

function extractImports(content, language) {
  const imports = new Set();
  if (language === 'python') {
    PY_IMPORT_RE.lastIndex = 0;
    let m;
    while ((m = PY_IMPORT_RE.exec(content)) !== null) {
      imports.add(m[1] || m[2]);
    }
  } else {
    JS_IMPORT_RE.lastIndex = 0;
    let m;
    while ((m = JS_IMPORT_RE.exec(content)) !== null) {
      imports.add(m[1] || m[2]);
    }
  }
  return [...imports];
}

// Best-effort resolution of a relative import to an actual indexed file.
// Bare/package imports (no leading '.') are left unresolved ("external").
async function resolveImport(fromFile, spec, workspaceRoot) {
  if (!spec.startsWith('.')) return { spec, resolved: null, external: true };
  const base = path.resolve(path.dirname(fromFile), spec);
  const candidates = [base, `${base}.js`, `${base}.jsx`, `${base}.ts`, `${base}.tsx`, `${base}.py`, path.join(base, 'index.js'), path.join(base, '__init__.py')];
  for (const c of candidates) {
    try {
      await fs.access(c);
      return { spec, resolved: path.relative(workspaceRoot, c), external: false };
    } catch { /* try next candidate */ }
  }
  return { spec, resolved: null, external: false };
}

async function walkCode(dir, root, out) {
  if (out.length >= MAX_FILES) return;
  let entries;
  try {
    entries = await fs.readdir(dir, { withFileTypes: true });
  } catch {
    return;
  }
  for (const entry of entries) {
    if (out.length >= MAX_FILES) return;
    if (entry.isDirectory()) {
      if (SKIP_DIRS.has(entry.name)) continue;
      await walkCode(path.join(dir, entry.name), root, out);
    } else if (CODE_EXT.has(path.extname(entry.name).toLowerCase())) {
      out.push(path.join(dir, entry.name));
    }
  }
}

function indexPathFor(app, workspaceRoot) {
  const hash = crypto.createHash('sha1').update(workspaceRoot || 'no-workspace').digest('hex').slice(0, 16);
  return path.join(app.getPath('userData'), 'repo-index', `${hash}.json`);
}

async function buildIndex({ app, workspaceRoot }) {
  if (!workspaceRoot) return { ok: false, result: 'No workspace folder is open.' };
  const files = [];
  await walkCode(workspaceRoot, workspaceRoot, files);

  const fileEntries = [];
  for (const full of files) {
    let stat, content;
    try {
      stat = await fs.stat(full);
      if (stat.size > MAX_FILE_BYTES) continue;
      content = await fs.readFile(full, 'utf-8');
    } catch {
      continue;
    }
    const rel = path.relative(workspaceRoot, full);
    const ext = path.extname(full).toLowerCase();
    const language = languageFor(ext);
    const symbols = extractSymbols(content, language);
    const rawImports = extractImports(content, language);
    const imports = [];
    for (const spec of rawImports) {
      imports.push(await resolveImport(full, spec, workspaceRoot));
    }
    fileEntries.push({
      file: rel,
      language,
      lines: content.split('\n').length,
      symbols,
      imports,
      isTest: TEST_FILE_RE.test(rel)
    });
  }

  const index = { builtAt: Date.now(), fileCount: fileEntries.length, files: fileEntries };
  const idxPath = indexPathFor(app, workspaceRoot);
  await fs.mkdir(path.dirname(idxPath), { recursive: true });
  await fs.writeFile(idxPath, JSON.stringify(index), 'utf-8');

  const totalSymbols = fileEntries.reduce((n, f) => n + f.symbols.length, 0);
  return { ok: true, result: { fileCount: fileEntries.length, totalSymbols, builtAt: index.builtAt } };
}

async function loadIndex(app, workspaceRoot) {
  try {
    return JSON.parse(await fs.readFile(indexPathFor(app, workspaceRoot), 'utf-8'));
  } catch {
    return null;
  }
}

async function findSymbols({ app, workspaceRoot, query }) {
  if (!workspaceRoot) return { ok: false, result: 'No workspace folder is open.' };
  const index = await loadIndex(app, workspaceRoot);
  if (!index) return { ok: true, result: { matches: [], note: 'No repository index yet — run repo_index first.' } };
  const q = String(query || '').toLowerCase();
  const matches = [];
  for (const f of index.files) {
    for (const s of f.symbols) {
      if (s.name.toLowerCase().includes(q)) {
        matches.push({ name: s.name, type: s.type, file: f.file, line: s.line });
        if (matches.length >= 100) break;
      }
    }
  }
  return { ok: true, result: { matches } };
}

async function dependencyGraph({ app, workspaceRoot, relPath }) {
  if (!workspaceRoot) return { ok: false, result: 'No workspace folder is open.' };
  const index = await loadIndex(app, workspaceRoot);
  if (!index) return { ok: true, result: { note: 'No repository index yet — run repo_index first.' } };

  if (relPath) {
    const entry = index.files.find(f => f.file === relPath);
    if (!entry) return { ok: false, result: `${relPath} is not in the index.` };
    const dependents = index.files
      .filter(f => f.imports.some(i => i.resolved === relPath))
      .map(f => f.file);
    return {
      ok: true,
      result: {
        file: relPath,
        dependsOn: entry.imports.map(i => i.external ? `[external] ${i.spec}` : (i.resolved || `[unresolved] ${i.spec}`)),
        dependedOnBy: dependents
      }
    };
  }

  // Whole-project summary: which files have the most incoming edges (likely
  // "core" modules) — genuinely computed, not fabricated centrality.
  const incoming = new Map();
  for (const f of index.files) {
    for (const imp of f.imports) {
      if (imp.resolved) incoming.set(imp.resolved, (incoming.get(imp.resolved) || 0) + 1);
    }
  }
  const mostDependedOn = [...incoming.entries()].sort((a, b) => b[1] - a[1]).slice(0, 15)
    .map(([file, count]) => ({ file, incomingEdges: count }));
  return { ok: true, result: { fileCount: index.fileCount, mostDependedOn } };
}

async function grepSearch({ workspaceRoot, pattern, caseSensitive }) {
  if (!workspaceRoot) return { ok: false, result: 'No workspace folder is open.' };
  if (!pattern) return { ok: false, result: 'Empty search pattern.' };

  const files = [];
  await walkCode(workspaceRoot, workspaceRoot, files);
  // Also search common text/config files, not just code, since grep is meant
  // to be a general exact-match tool.
  const EXTRA_EXT = new Set(['.md', '.txt', '.json', '.yml', '.yaml', '.html', '.css']);
  let extraCount = 0;
  async function walkExtra(dir) {
    if (extraCount >= 1000) return;
    let entries;
    try { entries = await fs.readdir(dir, { withFileTypes: true }); } catch { return; }
    for (const entry of entries) {
      if (extraCount >= 1000) return;
      if (entry.isDirectory()) {
        if (SKIP_DIRS.has(entry.name)) continue;
        await walkExtra(path.join(dir, entry.name));
      } else if (EXTRA_EXT.has(path.extname(entry.name).toLowerCase())) {
        files.push(path.join(dir, entry.name));
        extraCount++;
      }
    }
  }
  await walkExtra(workspaceRoot);

  let re;
  try {
    re = new RegExp(pattern, caseSensitive ? 'g' : 'gi');
  } catch (err) {
    return { ok: false, result: `Invalid pattern: ${String(err?.message || err)}` };
  }

  const matches = [];
  for (const full of files) {
    let content;
    try {
      const stat = await fs.stat(full);
      if (stat.size > MAX_FILE_BYTES) continue;
      content = await fs.readFile(full, 'utf-8');
    } catch {
      continue;
    }
    const lines = content.split('\n');
    lines.forEach((line, i) => {
      re.lastIndex = 0;
      if (re.test(line)) {
        matches.push({ file: path.relative(workspaceRoot, full), line: i + 1, text: line.trim().slice(0, 300) });
      }
    });
    if (matches.length > 300) break;
  }
  return { ok: true, result: { matches: matches.slice(0, 300), truncated: matches.length > 300 } };
}

async function discoverTests({ app, workspaceRoot }) {
  if (!workspaceRoot) return { ok: false, result: 'No workspace folder is open.' };
  const index = await loadIndex(app, workspaceRoot);
  if (!index) return { ok: true, result: { note: 'No repository index yet — run repo_index first.', tests: [] } };
  const tests = index.files.filter(f => f.isTest).map(f => f.file);
  return { ok: true, result: { tests, count: tests.length } };
}

module.exports = { buildIndex, findSymbols, dependencyGraph, grepSearch, discoverTests, loadIndex };
