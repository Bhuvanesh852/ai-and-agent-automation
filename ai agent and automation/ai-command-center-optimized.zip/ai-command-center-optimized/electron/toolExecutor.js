const fs = require('node:fs/promises');
const path = require('node:path');
const { exec, execFile } = require('node:child_process');
const { app } = require('electron');
const { classifyCommand } = require('./commandGuard.js');
const { scanSecrets } = require('./secretScanner.js');
const { scanDependencies } = require('./dependencyScanner.js');
const { webSearch } = require('./webSearch.js');
const webResearch = require('./webResearch.js');
const ragEngine = require('./ragEngine.js');
const repoIndexer = require('./repoIndexer.js');
const mediaGen = require('./mediaGen.js');
const codeRunner = require('./codeRunner.js');

const MAX_OUTPUT_CHARS = 20000;
const EXEC_TIMEOUT_MS = 20000;
// Tests routinely run longer than an arbitrary shell command; give run_tests
// its own, more generous ceiling instead of forcing it to share the 20s
// budget meant for quick one-off commands.
const TEST_TIMEOUT_MS = 120000;

// Walk up from `p` to the nearest ancestor that actually exists on disk.
// Needed because a file being newly created (write_file) has no realpath
// of its own yet — we still need *some* real path to check containment
// against, so we resolve as far up as the filesystem actually goes.
async function nearestExistingAncestor(p) {
  let cur = p;
  for (;;) {
    try {
      return await fs.realpath(cur);
    } catch {
      const parent = path.dirname(cur);
      if (parent === cur) return cur; // hit the filesystem root, give up
      cur = parent;
    }
  }
}

// Lexical containment (path.resolve + startsWith) only catches path
// *traversal* (../..). It does NOT catch a symlink that lives inside the
// workspace but physically points somewhere else on disk — e.g. a
// workspace file `escape -> /etc` would pass the old check and then every
// operation "inside" `escape/` would actually touch /etc. realpath()
// resolves symlinks, so we check containment against the REAL, physical
// location, not just the textual one.
async function resolveInWorkspace(workspaceRoot, relPath) {
  if (!workspaceRoot) {
    throw new Error('No workspace folder is open. Open a project folder first (Sidebar → Files → Open Folder).');
  }
  const lexicallyResolved = path.resolve(workspaceRoot, relPath || '.');
  const normalizedRoot = path.resolve(workspaceRoot);
  if (lexicallyResolved !== normalizedRoot && !lexicallyResolved.startsWith(normalizedRoot + path.sep)) {
    throw new Error('Refused: path escapes the workspace folder.');
  }

  const realRoot = await fs.realpath(normalizedRoot);
  const realTarget = await nearestExistingAncestor(lexicallyResolved);
  if (realTarget !== realRoot && !realTarget.startsWith(realRoot + path.sep)) {
    throw new Error('Refused: path escapes the workspace folder (symlink detected).');
  }
  return lexicallyResolved;
}

function runShell(command, cwd) {
  return new Promise((resolve) => {
    exec(command, { cwd, timeout: EXEC_TIMEOUT_MS, maxBuffer: 5 * 1024 * 1024 }, (err, stdout, stderr) => {
      resolve({
        ok: !err,
        stdout: String(stdout || '').slice(0, MAX_OUTPUT_CHARS),
        stderr: String(stderr || '').slice(0, MAX_OUTPUT_CHARS),
        error: err ? String(err.message || err) : null
      });
    });
  });
}

// Like runShell, but takes a command + argument array and never goes
// through a shell — so nothing in `args` (e.g. a commit message containing
// `` ` ``, `$()`, `;`, etc.) can be interpreted as shell syntax. Used for
// anything built from model- or user-supplied text (git_commit's message,
// run_tests' optional filter).
function runFile(file, args, cwd, timeoutMs = EXEC_TIMEOUT_MS) {
  return new Promise((resolve) => {
    execFile(file, args, { cwd, timeout: timeoutMs, maxBuffer: 5 * 1024 * 1024 }, (err, stdout, stderr) => {
      resolve({
        ok: !err,
        stdout: String(stdout || '').slice(0, MAX_OUTPUT_CHARS),
        stderr: String(stderr || '').slice(0, MAX_OUTPUT_CHARS),
        error: err ? String(err.message || err) : null
      });
    });
  });
}

// --- Test-runner detection for run_tests -------------------------------
// Looks for, in order: a Node package.json with a real "test" script
// (picking the package manager from whichever lockfile is present), a
// pytest project, or a Cargo (Rust) project. Returns null if none match,
// so the tool can say plainly that it couldn't find a test command instead
// of guessing at one.
async function fileExists(p) {
  try {
    await fs.access(p);
    return true;
  } catch {
    return false;
  }
}

async function detectTestCommand(cwd) {
  try {
    const pkgRaw = await fs.readFile(path.join(cwd, 'package.json'), 'utf-8');
    const pkg = JSON.parse(pkgRaw);
    const testScript = pkg?.scripts?.test;
    if (testScript && !/no test specified/i.test(testScript)) {
      let manager = 'npm';
      if (await fileExists(path.join(cwd, 'pnpm-lock.yaml'))) manager = 'pnpm';
      else if (await fileExists(path.join(cwd, 'yarn.lock'))) manager = 'yarn';
      else if (await fileExists(path.join(cwd, 'bun.lockb'))) manager = 'bun';
      // `npm test -- <filter>` (and pnpm/yarn/bun equivalents) forward
      // anything after "--" to the underlying test binary the script calls.
      return { file: manager, baseArgs: ['test'], filterArgs: (f) => ['--', f], label: `${manager} test` };
    }
  } catch {
    // No package.json, unreadable, or invalid JSON — fall through to
    // non-Node runners below.
  }

  if (await fileExists(path.join(cwd, 'pytest.ini')) || await fileExists(path.join(cwd, 'setup.cfg'))) {
    return { file: 'pytest', baseArgs: [], filterArgs: (f) => ['-k', f], label: 'pytest' };
  }
  try {
    const pyproject = await fs.readFile(path.join(cwd, 'pyproject.toml'), 'utf-8');
    if (/\bpytest\b/i.test(pyproject)) {
      return { file: 'pytest', baseArgs: [], filterArgs: (f) => ['-k', f], label: 'pytest' };
    }
  } catch { /* no pyproject.toml */ }

  if (await fileExists(path.join(cwd, 'Cargo.toml'))) {
    return { file: 'cargo', baseArgs: ['test'], filterArgs: (f) => [f], label: 'cargo test' };
  }

  return null;
}

async function executeTool(name, args, { workspaceRoot, isLockedDown }) {
  switch (name) {
    case 'list_dir': {
      const dir = await resolveInWorkspace(workspaceRoot, args.path);
      const entries = await fs.readdir(dir, { withFileTypes: true });
      return {
        ok: true,
        result: entries.map(e => ({ name: e.name, type: e.isDirectory() ? 'dir' : 'file' }))
      };
    }
    case 'read_file': {
      const file = await resolveInWorkspace(workspaceRoot, args.path);
      const content = await fs.readFile(file, 'utf-8');
      return { ok: true, result: content.slice(0, MAX_OUTPUT_CHARS) };
    }
    case 'write_file': {
      const file = await resolveInWorkspace(workspaceRoot, args.path);
      await fs.mkdir(path.dirname(file), { recursive: true });
      await fs.writeFile(file, args.content, 'utf-8');
      return { ok: true, result: `Wrote ${args.content.length} chars to ${args.path}` };
    }
    case 'run_terminal': {
      if (isLockedDown) {
        return { ok: false, result: '🔒 Blocked: Lockdown Mode is active. Turn it off in the Security Center to allow command execution again.' };
      }
      const verdict = classifyCommand(args.command);
      if (verdict.verdict === 'blocked') {
        return { ok: false, result: `🚫 Blocked by security policy (${verdict.ruleId}): ${verdict.reason}. This command is never allowed, regardless of approval.` };
      }
      const cwd = await resolveInWorkspace(workspaceRoot, '.');
      const res = await runShell(args.command, cwd);
      return { ok: res.ok, result: res.ok ? res.stdout : `${res.stderr}\n${res.error || ''}` };
    }
    case 'git_status': {
      const cwd = await resolveInWorkspace(workspaceRoot, '.');
      const res = await runShell('git status --porcelain=v1 -b', cwd);
      return { ok: res.ok, result: res.ok ? res.stdout : res.stderr };
    }
    case 'git_diff': {
      const cwd = await resolveInWorkspace(workspaceRoot, '.');
      const res = await runShell('git diff', cwd);
      return { ok: res.ok, result: res.ok ? res.stdout : res.stderr };
    }
    case 'git_commit': {
      if (isLockedDown) {
        return { ok: false, result: '🔒 Blocked: Lockdown Mode is active.' };
      }
      const cwd = await resolveInWorkspace(workspaceRoot, '.');
      const addRes = await runFile('git', ['add', '-A'], cwd);
      if (!addRes.ok) return { ok: false, result: addRes.stderr };
      // Passed as a single argv entry via execFile (no shell involved), so
      // backticks, `$()`, `;`, etc. in a model-generated commit message
      // can't be interpreted as shell syntax — unlike the previous
      // string-interpolated `exec('git commit -m "..."')`.
      const msg = String(args.message || 'Automated commit');
      const commitRes = await runFile('git', ['commit', '-m', msg], cwd);
      return { ok: commitRes.ok, result: commitRes.ok ? commitRes.stdout : commitRes.stderr };
    }
    case 'scan_secrets': {
      return await scanSecrets(workspaceRoot);
    }
    case 'scan_dependencies': {
      return await scanDependencies(workspaceRoot);
    }
    case 'security_report': {
      const [secrets, deps] = await Promise.all([scanSecrets(workspaceRoot), scanDependencies(workspaceRoot)]);
      return {
        ok: secrets.ok && deps.ok,
        result: {
          secrets: secrets.ok ? secrets.result : { error: secrets.result },
          dependencies: deps.ok ? deps.result : { error: deps.result },
          generatedAt: Date.now()
        }
      };
    }
    case 'web_search': {
      if (isLockedDown) {
        return { ok: false, result: '🔒 Blocked: Lockdown Mode is active — no external network calls are allowed.' };
      }
      return await webSearch(args.query);
    }
    // --- internet layer (see electron/webResearch.js) ---------------------
    case 'deep_research': {
      if (isLockedDown) {
        return { ok: false, result: '🔒 Blocked: Lockdown Mode is active — no external network calls are allowed.' };
      }
      return await webResearch.research(args.query, args.sources);
    }
    case 'read_url': {
      if (isLockedDown) {
        return { ok: false, result: '🔒 Blocked: Lockdown Mode is active — no external network calls are allowed.' };
      }
      return await webResearch.readUrl(args.url);
    }
    case 'http_request': {
      if (isLockedDown) {
        return { ok: false, result: '🔒 Blocked: Lockdown Mode is active — no external network calls are allowed.' };
      }
      return await webResearch.httpRequest({
        url: args.url,
        method: args.method,
        headers: args.headers,
        body: args.body
      });
    }
    case 'rag_ingest': {
      return await ragEngine.ingest({ app, workspaceRoot, relPath: args.path });
    }
    case 'rag_query': {
      return await ragEngine.query({ app, workspaceRoot, question: args.question, topK: args.topK });
    }
    case 'repo_index': {
      return await repoIndexer.buildIndex({ app, workspaceRoot });
    }
    case 'repo_symbols': {
      return await repoIndexer.findSymbols({ app, workspaceRoot, query: args.query });
    }
    case 'repo_dependencies': {
      return await repoIndexer.dependencyGraph({ app, workspaceRoot, relPath: args.path });
    }
    case 'repo_search': {
      return await repoIndexer.grepSearch({ workspaceRoot, pattern: args.pattern, caseSensitive: args.caseSensitive });
    }
    case 'test_discover': {
      return await repoIndexer.discoverTests({ app, workspaceRoot });
    }
    case 'generate_image': {
      if (isLockedDown) {
        return { ok: false, result: '🔒 Blocked: Lockdown Mode is active — no external network calls are allowed.' };
      }
      return await mediaGen.generateImage({
        prompt: args.prompt,
        workspaceRoot,
        width: args.width,
        height: args.height
      });
    }
    case 'execute_code': {
      if (isLockedDown) {
        return { ok: false, result: '🔒 Blocked: Lockdown Mode is active. Turn it off in the Security Center to allow code execution again.' };
      }
      return await codeRunner.executeCode({ language: args.language, code: args.code });
    }
    case 'run_tests': {
      if (isLockedDown) {
        return { ok: false, result: '🔒 Blocked: Lockdown Mode is active. Turn it off in the Security Center to allow running tests again.' };
      }
      const cwd = await resolveInWorkspace(workspaceRoot, '.');
      const detection = await detectTestCommand(cwd);
      if (!detection) {
        return {
          ok: false,
          result: 'No test command detected. Looked for a "test" script in package.json, a pytest project (pytest.ini/setup.cfg/pyproject.toml), and a Cargo.toml. Run test_discover to list test files, or add a test script first.'
        };
      }
      const filter = args && args.filter ? String(args.filter) : null;
      const finalArgs = filter ? [...detection.baseArgs, ...detection.filterArgs(filter)] : [...detection.baseArgs];
      const res = await runFile(detection.file, finalArgs, cwd, TEST_TIMEOUT_MS);
      return {
        ok: res.ok,
        result: {
          command: `${detection.label}${filter ? ' (filtered)' : ''}`,
          passed: res.ok,
          stdout: res.stdout,
          stderr: res.stderr,
          error: res.error
        }
      };
    }
    default:
      return { ok: false, result: `Unknown tool: ${name}` };
  }
}

module.exports = { executeTool };
