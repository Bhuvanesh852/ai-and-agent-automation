#!/usr/bin/env node
// Minimal, real MCP (Model Context Protocol) server for AI Command Center.
//
// This is a STANDALONE Node process (no Electron runtime) so any MCP client
// (Claude Desktop, another agent host, a CLI) can spawn it directly:
//   node electron/mcpServer.js
//
// Transport: JSON-RPC 2.0 framed with `Content-Length` headers over
// stdin/stdout, matching the MCP stdio transport spec (same framing as LSP).
//
// Honesty note: this reuses the SAME local, offline modules the desktop app
// uses (commandGuard, secretScanner, dependencyScanner, ragEngine,
// repoIndexer, webSearch) — it is not a reimplementation or a mock. The only
// thing standalone-ized is the `app.getPath('userData')` dependency those
// modules had (Electron-only API), which is swapped for a plain folder under
// the user's home directory so this can run outside Electron.

const fs = require('node:fs/promises');
const fsSync = require('node:fs');
const path = require('node:path');
const os = require('node:os');
const { exec } = require('node:child_process');

const { classifyCommand } = require('./commandGuard.js');
const { scanSecrets } = require('./secretScanner.js');
const { scanDependencies } = require('./dependencyScanner.js');
const webSearch = require('./webSearch.js');
const ragEngine = require('./ragEngine.js');
const repoIndexer = require('./repoIndexer.js');

const MCP_HOME = path.join(os.homedir(), '.ai-command-center');
const CONFIG_PATH = path.join(MCP_HOME, 'mcp-config.json');
const EXEC_TIMEOUT_MS = 20000;
const MAX_OUTPUT_CHARS = 20000;

// Stand-in for Electron's `app` object — the only thing ragEngine.js and
// repoIndexer.js actually use off of it is getPath('userData').
const fakeApp = { getPath: () => path.join(MCP_HOME, 'userData') };

function readConfig() {
  try {
    return JSON.parse(fsSync.readFileSync(CONFIG_PATH, 'utf8'));
  } catch {
    return { workspaceRoot: null };
  }
}

async function resolveInWorkspace(workspaceRoot, relPath) {
  if (!workspaceRoot) throw new Error('No workspace is configured. Set one from the desktop app first (Files → Open Folder), or edit ' + CONFIG_PATH);
  const abs = path.resolve(workspaceRoot, relPath || '.');
  const rootReal = await fs.realpath(workspaceRoot).catch(() => path.resolve(workspaceRoot));
  const target = path.resolve(abs);
  if (target !== rootReal && !target.startsWith(rootReal + path.sep)) {
    throw new Error('Path escapes the workspace root — refused.');
  }
  return target;
}

// ---- Tool definitions (MCP tool schema: name, description, inputSchema) ----

const TOOLS = [
  {
    name: 'list_dir',
    description: 'List files and folders at a path relative to the configured workspace.',
    inputSchema: { type: 'object', properties: { path: { type: 'string' } }, required: ['path'] },
    handler: async ({ path: p }) => {
      const cfg = readConfig();
      const target = await resolveInWorkspace(cfg.workspaceRoot, p);
      const entries = await fs.readdir(target, { withFileTypes: true });
      return entries.map(e => (e.isDirectory() ? e.name + '/' : e.name)).join('\n');
    }
  },
  {
    name: 'read_file',
    description: 'Read a text file relative to the configured workspace.',
    inputSchema: { type: 'object', properties: { path: { type: 'string' } }, required: ['path'] },
    handler: async ({ path: p }) => {
      const cfg = readConfig();
      const target = await resolveInWorkspace(cfg.workspaceRoot, p);
      const content = await fs.readFile(target, 'utf8');
      return content.slice(0, MAX_OUTPUT_CHARS);
    }
  },
  {
    name: 'write_file',
    description: 'Create or overwrite a text file relative to the configured workspace.',
    inputSchema: {
      type: 'object',
      properties: { path: { type: 'string' }, content: { type: 'string' } },
      required: ['path', 'content']
    },
    handler: async ({ path: p, content }) => {
      const cfg = readConfig();
      const target = await resolveInWorkspace(cfg.workspaceRoot, p);
      await fs.mkdir(path.dirname(target), { recursive: true });
      await fs.writeFile(target, content, 'utf8');
      return `Wrote ${Buffer.byteLength(content, 'utf8')} bytes to ${p}`;
    }
  },
  {
    name: 'run_terminal',
    description: 'Run a shell command inside the workspace. Blocked/caution patterns are enforced by commandGuard before execution.',
    inputSchema: { type: 'object', properties: { command: { type: 'string' } }, required: ['command'] },
    handler: async ({ command }) => {
      const cfg = readConfig();
      if (!cfg.workspaceRoot) throw new Error('No workspace configured.');
      const verdict = classifyCommand(command);
      if (verdict.verdict === 'blocked') {
        throw new Error(`Command blocked by commandGuard (${verdict.ruleId}): ${verdict.reason}`);
      }
      return await new Promise((resolve, reject) => {
        exec(command, { cwd: cfg.workspaceRoot, timeout: EXEC_TIMEOUT_MS, maxBuffer: 1024 * 1024 }, (err, stdout, stderr) => {
          if (err && !stdout && !stderr) return reject(err);
          const cautionNote = verdict.verdict === 'caution' ? `[caution: ${verdict.reason}]\n` : '';
          resolve((cautionNote + stdout + stderr).slice(0, MAX_OUTPUT_CHARS));
        });
      });
    }
  },
  {
    name: 'scan_secrets',
    description: 'Scan the workspace for likely leaked secrets/API keys (local, offline pattern matching).',
    inputSchema: { type: 'object', properties: {} },
    handler: async () => {
      const cfg = readConfig();
      const findings = await scanSecrets(cfg.workspaceRoot);
      return JSON.stringify(findings, null, 2);
    }
  },
  {
    name: 'scan_dependencies',
    description: 'Scan package manifests for risky version patterns (offline heuristics, not a live CVE feed).',
    inputSchema: { type: 'object', properties: {} },
    handler: async () => {
      const cfg = readConfig();
      const findings = await scanDependencies(cfg.workspaceRoot);
      return JSON.stringify(findings, null, 2);
    }
  },
  {
    name: 'web_search',
    description: 'Keyless web lookup via DuckDuckGo Instant Answer API (short abstracts, not full search results).',
    inputSchema: { type: 'object', properties: { query: { type: 'string' } }, required: ['query'] },
    handler: async ({ query }) => JSON.stringify(await webSearch.webSearch(query), null, 2)
  },
  {
    name: 'rag_query',
    description: 'Query the local TF-IDF RAG index built over ingested workspace documents.',
    inputSchema: { type: 'object', properties: { question: { type: 'string' }, topK: { type: 'number' } }, required: ['question'] },
    handler: async ({ question, topK }) => {
      const cfg = readConfig();
      const result = await ragEngine.query({ app: fakeApp, workspaceRoot: cfg.workspaceRoot, question, topK: topK || 5 });
      return JSON.stringify(result, null, 2);
    }
  },
  {
    name: 'repo_search',
    description: 'Exact-text/grep search across the workspace.',
    inputSchema: { type: 'object', properties: { pattern: { type: 'string' }, caseSensitive: { type: 'boolean' } }, required: ['pattern'] },
    handler: async ({ pattern, caseSensitive }) => {
      const cfg = readConfig();
      const result = await repoIndexer.grepSearch({ workspaceRoot: cfg.workspaceRoot, pattern, caseSensitive: !!caseSensitive });
      return JSON.stringify(result, null, 2);
    }
  }
];

const toolByName = new Map(TOOLS.map(t => [t.name, t]));

// ---- JSON-RPC 2.0 over stdio with Content-Length framing ----

let buffer = Buffer.alloc(0);

function send(message) {
  const json = JSON.stringify(message);
  const header = `Content-Length: ${Buffer.byteLength(json, 'utf8')}\r\n\r\n`;
  process.stdout.write(header + json);
}

function reply(id, result) {
  send({ jsonrpc: '2.0', id, result });
}

function replyError(id, code, message) {
  send({ jsonrpc: '2.0', id, error: { code, message } });
}

async function handleRequest(msg) {
  const { id, method, params } = msg;
  try {
    if (method === 'initialize') {
      reply(id, {
        protocolVersion: '2024-11-05',
        capabilities: { tools: {} },
        serverInfo: { name: 'ai-command-center-mcp', version: '1.0.0' }
      });
    } else if (method === 'tools/list') {
      reply(id, { tools: TOOLS.map(({ name, description, inputSchema }) => ({ name, description, inputSchema })) });
    } else if (method === 'tools/call') {
      const tool = toolByName.get(params?.name);
      if (!tool) return replyError(id, -32601, `Unknown tool: ${params?.name}`);
      try {
        const text = await tool.handler(params?.arguments || {});
        reply(id, { content: [{ type: 'text', text: String(text) }], isError: false });
      } catch (toolErr) {
        reply(id, { content: [{ type: 'text', text: `Error: ${toolErr.message}` }], isError: true });
      }
    } else if (method === 'ping') {
      reply(id, {});
    } else if (id !== undefined) {
      replyError(id, -32601, `Unknown method: ${method}`);
    }
    // notifications (no id) are silently ignored if unhandled
  } catch (err) {
    if (id !== undefined) replyError(id, -32603, err.message);
  }
}

process.stdin.on('data', chunk => {
  buffer = Buffer.concat([buffer, chunk]);
  for (;;) {
    const headerEnd = buffer.indexOf('\r\n\r\n');
    if (headerEnd === -1) return;
    const header = buffer.subarray(0, headerEnd).toString('utf8');
    const match = /Content-Length: (\d+)/i.exec(header);
    if (!match) { buffer = buffer.subarray(headerEnd + 4); continue; }
    const length = parseInt(match[1], 10);
    const bodyStart = headerEnd + 4;
    if (buffer.length < bodyStart + length) return; // wait for more data
    const body = buffer.subarray(bodyStart, bodyStart + length).toString('utf8');
    buffer = buffer.subarray(bodyStart + length);
    try {
      const msg = JSON.parse(body);
      handleRequest(msg);
    } catch {
      // malformed frame — drop it
    }
  }
});

process.stdin.resume();
fsSync.mkdirSync(MCP_HOME, { recursive: true });
process.stderr.write('AI Command Center MCP server ready (stdio). Workspace: ' + (readConfig().workspaceRoot || '(none configured yet)') + '\n');
