// MCP client — the other half of this app's MCP story. electron/mcpServer.js
// lets external MCP hosts (Claude Desktop, etc.) call INTO this app; this
// module lets THIS app call OUT to any MCP server the user configures
// (filesystem, GitHub, a company internal server, etc.), so agents here can
// use those servers' tools too.
//
// No @modelcontextprotocol/sdk dependency is added — this speaks the same
// plain JSON-RPC 2.0 + Content-Length stdio framing electron/mcpServer.js
// already implements by hand, kept consistent rather than mixing a heavier
// SDK in for one side only.
//
// Security: each configured server is a command the user explicitly typed
// in the MCP Connections panel (child_process.spawn, no shell:true, so no
// shell-injection surface from the command string). Tool calls a connected
// server exposes are still real code execution risk by nature of MCP itself
// — this app does not sandbox what a connected server's tools do, the same
// as any MCP client. Treat every server you add here like installing a
// plugin: only connect to servers you trust.

const { spawn } = require('node:child_process');

// connectionId -> { proc, buffer, pending: Map<id, {resolve,reject}>, nextId, tools, name, command, args }
const connections = new Map();

function frameSend(proc, message) {
  const json = JSON.stringify(message);
  const header = `Content-Length: ${Buffer.byteLength(json, 'utf8')}\r\n\r\n`;
  proc.stdin.write(header + json);
}

function attachFraming(conn) {
  conn.proc.stdout.on('data', chunk => {
    conn.buffer = Buffer.concat([conn.buffer, chunk]);
    for (;;) {
      const headerEnd = conn.buffer.indexOf('\r\n\r\n');
      if (headerEnd === -1) return;
      const header = conn.buffer.subarray(0, headerEnd).toString('utf8');
      const match = /Content-Length: (\d+)/i.exec(header);
      if (!match) { conn.buffer = conn.buffer.subarray(headerEnd + 4); continue; }
      const length = parseInt(match[1], 10);
      const bodyStart = headerEnd + 4;
      if (conn.buffer.length < bodyStart + length) return;
      const body = conn.buffer.subarray(bodyStart, bodyStart + length).toString('utf8');
      conn.buffer = conn.buffer.subarray(bodyStart + length);
      try {
        const msg = JSON.parse(body);
        if (msg.id !== undefined && conn.pending.has(msg.id)) {
          const { resolve, reject } = conn.pending.get(msg.id);
          conn.pending.delete(msg.id);
          if (msg.error) reject(new Error(msg.error.message || 'MCP server error'));
          else resolve(msg.result);
        }
      } catch { /* malformed frame — drop it */ }
    }
  });
}

function rpc(conn, method, params) {
  return new Promise((resolve, reject) => {
    const id = conn.nextId++;
    conn.pending.set(id, { resolve, reject });
    frameSend(conn.proc, { jsonrpc: '2.0', id, method, params });
    setTimeout(() => {
      if (conn.pending.has(id)) {
        conn.pending.delete(id);
        reject(new Error(`MCP request "${method}" timed out after 15s`));
      }
    }, 15000);
  });
}

async function connect({ id, name, command, args = [], cwd }) {
  if (connections.has(id)) await disconnect(id);
  const proc = spawn(command, args, { cwd, stdio: ['pipe', 'pipe', 'pipe'] });
  const conn = { proc, buffer: Buffer.alloc(0), pending: new Map(), nextId: 1, tools: [], name, command, args, status: 'connecting' };
  connections.set(id, conn);
  attachFraming(conn);
  proc.stderr.on('data', () => { /* server logs — not surfaced to renderer, avoids leaking server internals */ });
  proc.on('exit', () => { conn.status = 'disconnected'; });
  proc.on('error', (err) => { conn.status = 'error'; conn.lastError = err.message; });

  try {
    await rpc(conn, 'initialize', {
      protocolVersion: '2024-11-05',
      capabilities: {},
      clientInfo: { name: 'ai-command-center', version: '1.0.0' }
    });
    const listResult = await rpc(conn, 'tools/list', {});
    conn.tools = listResult?.tools || [];
    conn.status = 'connected';
    return { ok: true, tools: conn.tools };
  } catch (err) {
    conn.status = 'error';
    conn.lastError = err.message;
    return { ok: false, error: err.message };
  }
}

async function disconnect(id) {
  const conn = connections.get(id);
  if (!conn) return { ok: true };
  try { conn.proc.kill(); } catch { /* already dead */ }
  connections.delete(id);
  return { ok: true };
}

async function callTool(id, toolName, args) {
  const conn = connections.get(id);
  if (!conn || conn.status !== 'connected') return { ok: false, error: 'Not connected to that MCP server.' };
  try {
    const result = await rpc(conn, 'tools/call', { name: toolName, arguments: args || {} });
    const text = (result?.content || []).map(c => c.text).filter(Boolean).join('\n');
    return { ok: !result?.isError, content: text };
  } catch (err) {
    return { ok: false, error: err.message };
  }
}

function status() {
  return Array.from(connections.entries()).map(([id, c]) => ({
    id, name: c.name, command: c.command, args: c.args,
    status: c.status, lastError: c.lastError,
    tools: c.tools.map(t => ({ name: t.name, description: t.description }))
  }));
}

function disconnectAll() {
  for (const id of Array.from(connections.keys())) disconnect(id);
}

module.exports = { connect, disconnect, callTool, status, disconnectAll };
