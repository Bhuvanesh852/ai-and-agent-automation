// AI Council — ask several different free models the same question at once,
// then have one model synthesise a single answer that explicitly reports where
// the panel disagreed.
//
// WHAT THIS IS: a well-understood ensembling technique. Different model
// families make different mistakes, so where three independent models agree
// you have a much better signal than one model's confidence score, and where
// they diverge you have found the part of the answer that deserves checking.
// On free tiers it is also the cheapest real quality upgrade available,
// because you're spending parallel quota across providers rather than money.
//
// WHAT THIS IS NOT: a smarter model. Ensembling raises the floor and surfaces
// uncertainty. It does not exceed what the strongest panel member could do on
// its own on a task where the others are simply wrong, and a confident
// consensus of three models can still be a confident consensus of three wrong
// models. The synthesiser prompt below is written to report disagreement
// rather than smooth it over, because the honest signal is the whole point.

import { dispatchChat } from '../gateway/ModelGateway.js';
import { councilCandidates, pickModel } from '../gateway/registry.js';

const SYNTHESIS_SYSTEM = `You are the synthesiser for a panel of independent AI models that were each asked the same question without seeing each other's answers.

Your job is NOT to average them. It is to produce the most accurate single answer, and to be honest about confidence.

Rules:
- Where the panel agrees, state the answer directly and plainly.
- Where the panel disagrees, say so explicitly, name what the disagreement is about, and say which position is better supported and why. Never silently pick one and hide that there was a split.
- If a panellist states a specific fact (a number, a name, a date, an API) that no other panellist mentions, treat it as unverified and label it as such.
- If the panel is collectively unsure, say the answer is uncertain. Do not manufacture confidence.
- Do not mention "panellist 1/2/3" in your final answer unless the disagreement itself matters to the user. Write a clean answer, then a short "Where the models disagreed" section if there was a split.`;

/**
 * @param {object}   opts
 * @param {string}   opts.prompt
 * @param {string}   [opts.system]         extra system context for panellists
 * @param {number}   [opts.members]        panel size (default 3)
 * @param {object}   [opts.providerStatus] which providers have keys configured
 * @param {object}   [opts.hints]          reasoning/creativity/safety toggles
 * @param {function} [opts.onProgress]     ({ phase, model, index, total })
 */
export async function runCouncil({
  prompt,
  system = '',
  members = 3,
  providerStatus = {},
  hints = {},
  onProgress = () => {}
}) {
  const panel = councilCandidates(providerStatus, Math.max(2, Math.min(Number(members) || 3, 5)));

  if (panel.length < 2) {
    return {
      ok: false,
      error:
        'The Council needs at least two different model providers configured. Right now only one is available — ' +
        'add a second free key in Settings (Groq, Gemini, Cerebras, Mistral and GitHub Models are all free), or ' +
        'install Ollama for a fully local second opinion.',
      panel
    };
  }

  onProgress({ phase: 'polling', total: panel.length });

  const baseMessages = [
    ...(system ? [{ role: 'system', content: system }] : []),
    { role: 'user', content: prompt }
  ];

  // allSettled, not all: one provider hitting its free-tier rate limit must
  // shrink the panel, never fail the whole council run.
  const settled = await Promise.allSettled(
    panel.map((m, i) => {
      onProgress({ phase: 'polling', model: m.display_name, index: i, total: panel.length });
      return dispatchChat({
        provider: m.provider,
        modelId: m.model_id,
        messages: baseMessages,
        hints,
        requestId: `council-${i}-${Date.now()}`
      });
    })
  );

  const answers = settled.map((r, i) => ({
    model: panel[i].display_name,
    provider: panel[i].provider,
    modelId: panel[i].model_id,
    ok: r.status === 'fulfilled' && r.value?.ok,
    content: r.status === 'fulfilled' ? (r.value?.content || '') : '',
    error: r.status === 'rejected' ? String(r.reason?.message || r.reason) : (r.value?.ok ? null : r.value?.error)
  }));

  const usable = answers.filter(a => a.ok && a.content.trim());
  if (usable.length === 0) {
    return { ok: false, error: 'No panellist returned an answer. Check Settings → Test Connection.', answers, panel };
  }
  if (usable.length === 1) {
    // Honest degradation: one answer is not a council, and saying so is more
    // useful than presenting a single model's output as a consensus.
    return {
      ok: true,
      degraded: true,
      answers,
      synthesis: usable[0].content,
      note: `Only ${usable[0].model} responded, so this is a single model's answer, not a panel consensus. The other panellists failed or were rate-limited.`
    };
  }

  onProgress({ phase: 'synthesising', total: usable.length });

  const synthModel = pickModel('reasoning', providerStatus) || pickModel('general', providerStatus);
  const transcript = usable
    .map((a, i) => `--- Panellist ${i + 1} (${a.model}) ---\n${a.content}`)
    .join('\n\n');

  const synthRes = await dispatchChat({
    provider: synthModel.provider,
    modelId: synthModel.model_id,
    messages: [
      { role: 'system', content: SYNTHESIS_SYSTEM },
      { role: 'user', content: `Original question:\n${prompt}\n\nPanel answers:\n\n${transcript}` }
    ],
    hints: { ...hints, creativityMode: 'low' },
    requestId: `council-synth-${Date.now()}`
  });

  return {
    ok: true,
    answers,
    panelSize: usable.length,
    synthesiser: synthModel.display_name,
    synthesis: synthRes.ok ? synthRes.content : usable[0].content,
    synthesisFailed: !synthRes.ok,
    note: synthRes.ok
      ? null
      : `Synthesis step failed (${synthRes.error}) — showing the first panellist's raw answer instead.`
  };
}

/** Convenience wrapper used by the workflow `council` node. */
export async function councilToText(args) {
  const res = await runCouncil(args);
  if (!res.ok) throw new Error(res.error);
  return res.synthesis;
}
