// Tool registry. Each tool declares an OpenAI-style function schema (used for
// providers that support tool calling — Groq, OpenRouter) plus a risk level
// used by the approval-checkpoint system. "safe" tools run immediately;
// "risky" tools always pause for explicit human approval, per the spec's
// human-approval-checkpoint and least-privilege requirements.

export const TOOLS = [
  {
    name: 'list_dir',
    riskLevel: 'safe',
    description: 'List files and folders at a path relative to the open workspace.',
    parameters: {
      type: 'object',
      properties: {
        path: { type: 'string', description: 'Relative path within the workspace. Use "." for the root.' }
      },
      required: ['path']
    }
  },
  {
    name: 'read_file',
    riskLevel: 'safe',
    description: 'Read a text file relative to the open workspace.',
    parameters: {
      type: 'object',
      properties: {
        path: { type: 'string', description: 'Relative file path within the workspace.' }
      },
      required: ['path']
    }
  },
  {
    name: 'write_file',
    riskLevel: 'risky',
    description: 'Create or overwrite a text file relative to the open workspace. Requires human approval.',
    parameters: {
      type: 'object',
      properties: {
        path: { type: 'string', description: 'Relative file path within the workspace.' },
        content: { type: 'string', description: 'Full new content of the file.' }
      },
      required: ['path', 'content']
    }
  },
  {
    name: 'run_terminal',
    riskLevel: 'risky',
    description: 'Run a shell command inside the workspace root. Requires human approval.',
    parameters: {
      type: 'object',
      properties: {
        command: { type: 'string', description: 'The shell command to execute.' }
      },
      required: ['command']
    }
  },
  {
    name: 'git_status',
    riskLevel: 'safe',
    description: 'Show git status for the workspace.',
    parameters: { type: 'object', properties: {} }
  },
  {
    name: 'git_diff',
    riskLevel: 'safe',
    description: 'Show git diff for the workspace.',
    parameters: { type: 'object', properties: {} }
  },
  {
    name: 'git_commit',
    riskLevel: 'risky',
    description: 'Stage all changes and create a git commit. Requires human approval.',
    parameters: {
      type: 'object',
      properties: {
        message: { type: 'string', description: 'Commit message.' }
      },
      required: ['message']
    }
  },
  {
    name: 'scan_secrets',
    riskLevel: 'safe',
    description: 'Scan the workspace for accidentally exposed credentials, keys, tokens, and other secrets. Read-only, local-only — nothing is sent anywhere.',
    parameters: { type: 'object', properties: {} }
  },
  {
    name: 'scan_dependencies',
    riskLevel: 'safe',
    description: 'Inspect package manifests (package.json, requirements.txt, etc.) in the workspace for outdated or risky-looking dependency pins. Read-only.',
    parameters: { type: 'object', properties: {} }
  },
  {
    name: 'security_report',
    riskLevel: 'safe',
    description: 'Compile the current Security Center findings (secrets, dependencies, permissions, config) into a single report.',
    parameters: { type: 'object', properties: {} }
  },
  {
    name: 'web_search',
    riskLevel: 'safe',
    description: 'Look up a factual/entity query using a free, keyless instant-answer service (DuckDuckGo Instant Answer API). Returns a short abstract and related topics, NOT full search-engine results — use it for facts, definitions, and current entities, not deep research.',
    parameters: {
      type: 'object',
      properties: {
        query: { type: 'string', description: 'The search query.' }
      },
      required: ['query']
    }
  },
  {
    name: 'deep_research',
    riskLevel: 'safe',
    description:
      'Research a topic across four free, keyless public sources at once (DuckDuckGo Instant Answer, Wikipedia, ' +
      'Hacker News, arXiv) and return merged, attributed snippets. Good for facts, background, current technical ' +
      'discussion and papers. NOT a commercial search engine: weak on long-tail commercial and local-business ' +
      'queries. Follow up with read_url on a promising result before relying on any claim.',
    parameters: {
      type: 'object',
      properties: {
        query: { type: 'string', description: 'What to research.' },
        sources: {
          type: 'array',
          items: { type: 'string', enum: ['duckduckgo', 'wikipedia', 'hackernews', 'arxiv'] },
          description: 'Optional subset of sources. Defaults to all four.'
        }
      },
      required: ['query']
    }
  },
  {
    name: 'read_url',
    riskLevel: 'safe',
    description:
      'Fetch one web page and return it as readable plain text (scripts, styles and markup stripped). Use this ' +
      'after deep_research to actually read a source instead of reasoning from a snippet. Loopback, private-LAN ' +
      'and cloud-metadata hosts are refused.',
    parameters: {
      type: 'object',
      properties: { url: { type: 'string', description: 'Full http(s):// URL.' } },
      required: ['url']
    }
  },
  {
    name: 'http_request',
    riskLevel: 'risky',
    description:
      'Make an arbitrary outbound HTTP request — the general-purpose connector for any REST API, webhook or ' +
      'self-hosted service. Requires human approval every time, because this is the one tool that can send ' +
      'workspace data to a third party. Private/loopback/metadata hosts are refused.',
    parameters: {
      type: 'object',
      properties: {
        url: { type: 'string', description: 'Full http(s):// URL.' },
        method: { type: 'string', enum: ['GET', 'POST', 'PUT', 'PATCH', 'DELETE'], description: 'Default GET.' },
        headers: { type: 'object', description: 'Optional request headers.' },
        body: { type: 'string', description: 'Optional request body (JSON string for JSON APIs).' }
      },
      required: ['url']
    }
  },
  {
    name: 'rag_ingest',
    riskLevel: 'safe',
    description: 'Index workspace documents for retrieval. Omit "path" (or use ".") to (re)index every supported text file in the workspace; pass a relative path to index just one file. Uses local TF-IDF, not neural embeddings.',
    parameters: {
      type: 'object',
      properties: {
        path: { type: 'string', description: 'Relative file path to ingest, or "." for the whole workspace.' }
      }
    }
  },
  {
    name: 'rag_query',
    riskLevel: 'safe',
    description: 'Retrieve the most relevant indexed document chunks for a question, with file/chunk citations. This is lexical (TF-IDF) retrieval, not semantic search — matches depend on shared keywords with the source text, not just meaning.',
    parameters: {
      type: 'object',
      properties: {
        question: { type: 'string', description: 'The question to retrieve context for.' },
        topK: { type: 'number', description: 'How many chunks to return (default 5).' }
      },
      required: ['question']
    }
  },
  {
    name: 'repo_index',
    riskLevel: 'safe',
    description: 'Build or refresh the repository index (symbols, import graph, test files) for the open workspace. Regex-based extraction for JS/TS/Python — not a full AST parser, so unusual syntax may be missed.',
    parameters: { type: 'object', properties: {} }
  },
  {
    name: 'repo_symbols',
    riskLevel: 'safe',
    description: 'Search indexed function/class names by substring across the whole repository. Run repo_index first if nothing comes back.',
    parameters: {
      type: 'object',
      properties: { query: { type: 'string', description: 'Substring to match against symbol names.' } },
      required: ['query']
    }
  },
  {
    name: 'repo_dependencies',
    riskLevel: 'safe',
    description: 'Show what a file imports and what imports it (best-effort resolution of relative imports only — bare package imports are reported as external, not resolved). Omit "path" for a whole-project summary of the most-depended-on files.',
    parameters: {
      type: 'object',
      properties: { path: { type: 'string', description: 'Workspace-relative file path. Omit for a project-wide summary.' } }
    }
  },
  {
    name: 'repo_search',
    riskLevel: 'safe',
    description: 'Exact/regex text search (grep) across the workspace\'s code and text files, with file/line results. Use this for precise string matches — use rag_query instead for conceptual/fuzzy questions.',
    parameters: {
      type: 'object',
      properties: {
        pattern: { type: 'string', description: 'Regex pattern to search for.' },
        caseSensitive: { type: 'boolean', description: 'Default false (case-insensitive).' }
      },
      required: ['pattern']
    }
  },
  {
    name: 'generate_image',
    riskLevel: 'safe',
    description:
      'Generate an image from a text prompt using a free, keyless text-to-image model (Pollinations.ai) and save it ' +
      'into the workspace under ai-outputs/images/. No API key or account needed. Quality and speed are free-tier-typical ' +
      '(a shared public model, occasional queueing) — not a paid image generator\'s output.',
    parameters: {
      type: 'object',
      properties: {
        prompt: { type: 'string', description: 'Description of the image to generate.' },
        width: { type: 'number', description: 'Image width in pixels (256-1536). Default 768.' },
        height: { type: 'number', description: 'Image height in pixels (256-1536). Default 768.' }
      },
      required: ['prompt']
    }
  },
  {
    name: 'execute_code',
    riskLevel: 'risky',
    description:
      'Write a short code snippet to a scratch file (outside the workspace) and run it, returning stdout/stderr. ' +
      'Supports javascript (Node.js, always available since this app bundles Node) and python (requires a system ' +
      'Python 3 install). Requires human approval, like run_terminal — use this instead of run_terminal when you ' +
      'just want to execute a snippet rather than a shell command.',
    parameters: {
      type: 'object',
      properties: {
        language: { type: 'string', enum: ['javascript', 'python'], description: 'Which interpreter to run the code with.' },
        code: { type: 'string', description: 'The full source code to execute.' }
      },
      required: ['language', 'code']
    }
  },
  {
    name: 'test_discover',
    riskLevel: 'safe',
    description: 'List test files found in the repository index (common naming patterns: *.test.js, *.spec.js, test_*.py, *_test.py). Run repo_index first if nothing comes back.',
    parameters: { type: 'object', properties: {} }
  },
  {
    name: 'run_tests',
    riskLevel: 'risky',
    description:
      'Detect and run the project\'s test command (npm/pnpm/yarn/bun "test" script, pytest, or cargo test) inside the workspace. ' +
      'Requires human approval, like run_terminal — the underlying script is whatever the project defines and can do anything a ' +
      'shell command can. Output is truncated and the run is time-limited.',
    parameters: {
      type: 'object',
      properties: {
        filter: {
          type: 'string',
          description: 'Optional test name/file filter to run a subset, passed through to the detected runner (e.g. a spec path for npm test, a -k expression for pytest, a test name for cargo test).'
        }
      }
    }
  }
];

// Maps the coarse permission tags used in agents.js to concrete tool names.
//
// SECURITY FIX: 'git' used to map to git_status + git_diff + git_commit as
// one bundle, so any agent tagged 'git' silently got commit (write) access
// even if its permissionProfile.gitOperations said 'read-only'. CyberShield
// is a case in point: it's declared read-only-by-design in agents.js, but
// picked up git_commit anyway. Split into 'git-read' and 'git-write' so an
// agent's tool tags can actually match its stated permission profile.
//
// Also: 'test-runner' used to map to an empty array, so the QA agent
// declared this permission but had no tool that did anything — it could
// discover tests (via 'repo') but never actually run them. Wired to the new
// run_tests tool below.
const PERMISSION_TO_TOOLS = {
  'file-read': ['list_dir', 'read_file'],
  'file-write': ['write_file'],
  'terminal': ['run_terminal'],
  'git-read': ['git_status', 'git_diff'],
  'git-write': ['git_commit'],
  'deployment': [],
  'test-runner': ['run_tests'],
  'web-search': ['web_search', 'deep_research', 'read_url'],
  'http': ['http_request'],
  'security-scan': ['scan_secrets', 'scan_dependencies', 'security_report'],
  'rag': ['rag_ingest', 'rag_query'],
  'repo': ['repo_index', 'repo_symbols', 'repo_dependencies', 'repo_search', 'test_discover'],
  'media': ['generate_image'],
  'code-exec': ['execute_code']
};

export function toolsForAgent(agent) {
  const allowedNames = new Set(agent.tools.flatMap(tag => PERMISSION_TO_TOOLS[tag] || []));
  return TOOLS.filter(t => allowedNames.has(t.name));
}

export function toolByName(name) {
  return TOOLS.find(t => t.name === name);
}

export function toOpenAIToolSchema(tools) {
  return tools.map(t => ({
    type: 'function',
    function: { name: t.name, description: t.description, parameters: t.parameters }
  }));
}
