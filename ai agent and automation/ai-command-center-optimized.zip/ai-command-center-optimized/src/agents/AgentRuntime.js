import { toolsForAgent, toolByName, toOpenAIToolSchema } from './tools.js';
import { callGroq } from '../gateway/adapters/groq.js';
import { callOpenRouter } from '../gateway/adapters/openrouter.js';
import { callOllama } from '../gateway/adapters/ollama.js';
import { callLocalNative } from '../gateway/adapters/localNative.js';

// Providers with OpenAI-compatible native function calling.
const NATIVE_TOOL_ADAPTERS = {
  groq: callGroq,
  openrouter: callOpenRouter
};

// Plain-chat-only backends get tools via a text-based protocol instead of
// native function calling — this is what lets fully local, no-API-key
// models (Ollama OR self-owned GGUF via node-llama-cpp) still use tools.
// Gemini/Demo still gracefully degrade to plain chat (no tool loop at all)
// since wiring a third, different tool-call format isn't worth the
// complexity for this app's scope.
const TEXT_PROTOCOL_ADAPTERS = {
  ollama: callOllama,
  'local-native': callLocalNative
};

const MAX_TOOL_ITERATIONS = 6;
const TOOL_CALL_RE = /```tool_call\s*([\s\S]*?)```/i;

export function providerSupportsTools(provider) {
  return !!NATIVE_TOOL_ADAPTERS[provider] || !!TEXT_PROTOCOL_ADAPTERS[provider];
}

export function agentHasTools(agent) {
  return toolsForAgent(agent).length > 0;
}

async function checkStopped(onEvent, shouldCancel) {
  if (shouldCancel && shouldCancel()) {
    onEvent?.({ type: 'cancelled' });
    return 'cancelled';
  }
  if (window.bridge?.security) {
    const stopped = await window.bridge.security.getStopAll();
    if (stopped) {
      onEvent?.({ type: 'stopped' });
      return 'stopped';
    }
  }
  return null;
}

// Bridge is only present inside the Electron desktop shell (contextBridge
// runs from preload.js). If this page is opened as a plain browser tab
// (e.g. `vite` dev server hit directly at localhost:5173 without the
// Electron wrapper), window.bridge is undefined and every tool call would
// throw. Surface that clearly instead of leaving the UI hung.
function requireBridge() {
  if (!window.bridge) {
    throw new Error(
      'Not running inside the desktop app — tool calls (files, terminal, git, web search) require ' +
      'the Electron shell. Launch the app itself rather than opening this page directly in a browser tab.'
    );
  }
}

// Shared by both tool-calling paths: runs the approval gate (for risky
// tools) and then the actual sandboxed execution via the main process.
// Never throws — any failure (missing bridge, IPC error, tool exception)
// comes back as a normal { ok: false, result } so callers can always
// finish the turn instead of leaving it hung.
async function executeToolCall({ name, args }, requestApproval, onEvent) {
  const toolDef = toolByName(name);
  onEvent?.({ type: 'tool_call_proposed', tool: name, args });

  let approved = true;
  try {
    if (!toolDef || toolDef.riskLevel === 'risky') {
      approved = await requestApproval({ name, args, riskLevel: toolDef?.riskLevel || 'risky' });
    }
  } catch (err) {
    onEvent?.({ type: 'tool_call_denied', tool: name });
    return { ok: false, result: `Approval step failed: ${String(err?.message || err)}` };
  }

  if (!approved) {
    onEvent?.({ type: 'tool_call_denied', tool: name });
    return { ok: false, result: 'User denied this tool call.' };
  }

  onEvent?.({ type: 'tool_call_approved', tool: name });
  try {
    requireBridge();
    const toolResult = await window.bridge.tools.execute(name, args || {});
    onEvent?.({ type: 'tool_result', tool: name, ok: toolResult.ok, result: toolResult.result });
    return toolResult;
  } catch (err) {
    const result = { ok: false, result: String(err?.message || err) };
    onEvent?.({ type: 'tool_result', tool: name, ok: false, result: result.result });
    return result;
  }
}

async function runNativeToolLoop({ agent, provider, modelId, messages, requestApproval, onEvent, shouldCancel, requestId }) {
  const adapter = NATIVE_TOOL_ADAPTERS[provider];
  const toolSchema = toOpenAIToolSchema(toolsForAgent(agent));
  let workingMessages = [...messages];

  for (let i = 0; i < MAX_TOOL_ITERATIONS; i++) {
    const stopReason = await checkStopped(onEvent, shouldCancel);
    if (stopReason) {
      return stopReason === 'cancelled'
        ? { ok: false, cancelled: true, error: '⏹ Cancelled.' }
        : { ok: false, error: '🛑 Stopped by STOP ALL AGENTS. Resume from the Security Center to continue.' };
    }

    let res;
    try {
      requireBridge();
      res = await adapter({ modelId, messages: workingMessages, tools: toolSchema, requestId });
    } catch (err) {
      if (err?.name === 'AbortError') return { ok: false, cancelled: true, error: '⏹ Cancelled.' };
      return { ok: false, error: String(err?.message || err) };
    }
    if (!res.ok) return { ok: false, error: res.error };

    if (!res.toolCalls || res.toolCalls.length === 0) {
      return { ok: true, content: res.content, providerUsed: provider, modelUsed: modelId };
    }

    workingMessages.push({
      role: 'assistant',
      content: res.content || null,
      tool_calls: res.toolCalls.map(tc => ({
        id: tc.id,
        type: 'function',
        function: { name: tc.name, arguments: JSON.stringify(tc.arguments || {}) }
      }))
    });

    for (const call of res.toolCalls) {
      const toolResult = await executeToolCall({ name: call.name, args: call.arguments }, requestApproval, onEvent);
      workingMessages.push({
        role: 'tool',
        tool_call_id: call.id,
        content: typeof toolResult.result === 'string' ? toolResult.result : JSON.stringify(toolResult.result)
      });
    }
  }
  return { ok: false, error: 'Tool loop exceeded max iterations without a final answer. Try a narrower request.' };
}

function buildTextProtocolPreamble(tools) {
  const toolList = tools.map(t => `- ${t.name}: ${t.description} Arguments (JSON): ${JSON.stringify(t.parameters)}`).join('\n');
  return (
    'You have access to local tools. To use one, respond with ONLY a fenced block in exactly this form ' +
    'and nothing else in that turn:\n' +
    '```tool_call\n{"name": "<tool_name>", "args": { ... }}\n```\n' +
    'After a tool result is given back to you, either call another tool the same way or give your final ' +
    `answer as plain text (no fenced block). Available tools:\n${toolList}\n` +
    'Only call a tool when it is actually needed to answer accurately — for ordinary questions just answer directly.'
  );
}

async function runTextProtocolToolLoop({ agent, provider, modelId, messages, requestApproval, onEvent, shouldCancel, requestId }) {
  const adapter = TEXT_PROTOCOL_ADAPTERS[provider];
  const tools = toolsForAgent(agent);
  const preamble = buildTextProtocolPreamble(tools);
  // Inject the protocol instructions right after the agent's own system prompt.
  let workingMessages = [
    messages[0],
    { role: 'system', content: preamble },
    ...messages.slice(1)
  ];

  for (let i = 0; i < MAX_TOOL_ITERATIONS; i++) {
    const stopReason = await checkStopped(onEvent, shouldCancel);
    if (stopReason) {
      return stopReason === 'cancelled'
        ? { ok: false, cancelled: true, error: '⏹ Cancelled.' }
        : { ok: false, error: '🛑 Stopped by STOP ALL AGENTS. Resume from the Security Center to continue.' };
    }

    let res;
    try {
      requireBridge();
      res = await adapter({ modelId, messages: workingMessages, requestId });
    } catch (err) {
      if (err?.name === 'AbortError') return { ok: false, cancelled: true, error: '⏹ Cancelled.' };
      return { ok: false, error: String(err?.message || err) };
    }
    if (!res.ok) return { ok: false, error: res.error };

    const match = res.content.match(TOOL_CALL_RE);
    if (!match) {
      // Plain final answer — done.
      return { ok: true, content: res.content, providerUsed: provider, modelUsed: modelId };
    }

    let parsed;
    try {
      parsed = JSON.parse(match[1].trim());
    } catch {
      // Model produced a malformed tool_call block — tell it so and retry,
      // rather than silently failing the whole turn.
      workingMessages.push({ role: 'assistant', content: res.content });
      workingMessages.push({ role: 'user', content: 'That tool_call block was not valid JSON. Please retry with valid JSON, or answer directly without a tool.' });
      continue;
    }

    workingMessages.push({ role: 'assistant', content: res.content });
    const toolResult = await executeToolCall({ name: parsed.name, args: parsed.args || {} }, requestApproval, onEvent);
    const resultText = typeof toolResult.result === 'string' ? toolResult.result : JSON.stringify(toolResult.result);
    workingMessages.push({ role: 'user', content: `Tool result for ${parsed.name}:\n${resultText}` });
  }
  return { ok: false, error: 'Tool loop exceeded max iterations without a final answer. Try a narrower request.' };
}

/**
 * Runs one user turn through an agentic tool-calling loop, using native
 * function calling where the provider supports it (Groq, OpenRouter) and a
 * text-based tool protocol for fully local, key-free Ollama models.
 *
 * requestApproval(toolCall) -> Promise<boolean>   required for risky tools.
 * onEvent(event) -> void                          lifecycle events for the UI/timeline.
 */
export async function runAgentTurn({ agent, provider, modelId, messages, requestApproval, onEvent, shouldCancel, requestId }) {
  const availableTools = toolsForAgent(agent);
  if (availableTools.length === 0) return { unsupported: true };

  if (NATIVE_TOOL_ADAPTERS[provider]) {
    return runNativeToolLoop({ agent, provider, modelId, messages, requestApproval, onEvent, shouldCancel, requestId });
  }
  if (TEXT_PROTOCOL_ADAPTERS[provider]) {
    return runTextProtocolToolLoop({ agent, provider, modelId, messages, requestApproval, onEvent, shouldCancel, requestId });
  }
  return { unsupported: true };
}
