import { describe, it, expect } from 'vitest';
import { toolsForAgent } from './tools.js';
import { AGENTS, getAgent } from './agents.js';

describe('toolsForAgent permission mapping', () => {
  it('never gives CyberShield write access to git, matching its read-only permission profile', () => {
    const cybershield = getAgent('cybershield');
    const names = toolsForAgent(cybershield).map(t => t.name);
    expect(names).toContain('git_status');
    expect(names).toContain('git_diff');
    expect(names).not.toContain('git_commit');
  });

  it('gives every agent declaring gitOperations: read-write both read and write git tools', () => {
    const readWriteAgents = AGENTS.filter(a => a.permissionProfile.gitOperations === 'read-write');
    expect(readWriteAgents.length).toBeGreaterThan(0);
    for (const agent of readWriteAgents) {
      const names = toolsForAgent(agent).map(t => t.name);
      expect(names).toContain('git_status');
      expect(names).toContain('git_diff');
      expect(names).toContain('git_commit');
    }
  });

  it('gives the QA agent an actual runnable test tool, not just discovery', () => {
    const qa = getAgent('qa-tester');
    const names = toolsForAgent(qa).map(t => t.name);
    expect(names).toContain('test_discover'); // can find tests (via "repo")
    expect(names).toContain('run_tests');      // and can now actually run them
  });

  it('marks run_tests as risky so it always requires human approval, like run_terminal', () => {
    const qa = getAgent('qa-tester');
    const runTests = toolsForAgent(qa).find(t => t.name === 'run_tests');
    expect(runTests.riskLevel).toBe('risky');
  });

  it('gives the Motion/3D Designer real image generation, matching its declared networkAccess', () => {
    const designer = getAgent('motion-3d-designer');
    const names = toolsForAgent(designer).map(t => t.name);
    expect(names).toContain('generate_image');
    expect(designer.permissionProfile.networkAccess).toBe(true);
  });

  it('marks execute_code as risky like run_terminal, and generate_image as safe', () => {
    const genai = getAgent('genai-engineer');
    const tools = toolsForAgent(genai);
    const exec = tools.find(t => t.name === 'execute_code');
    expect(exec.riskLevel).toBe('risky');

    const designer = getAgent('motion-3d-designer');
    const img = toolsForAgent(designer).find(t => t.name === 'generate_image');
    expect(img.riskLevel).toBe('safe');
  });
});
