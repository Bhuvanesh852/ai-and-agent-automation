// Groq adapter. OpenAI-compatible /chat/completions schema.
// The actual HTTP call is proxied through the main process (window.bridge.provider.call)
// so the raw API key never has to touch renderer JS.

export async function callGroq({ modelId, messages, temperature = 0.7, tools, requestId }) {
  if (!window.bridge) throw new Error('Not running inside the desktop app — provider calls require the Electron shell.');
  // The URL, auth header name, and key prefix are no longer sent from here —
  // main.js owns all of that per providerId now, so a compromised renderer
  // can't redirect this call (or the saved key) anywhere else.
  const res = await window.bridge.provider.call({
    providerId: 'groq',
    requestId,
    body: JSON.stringify({
      model: modelId,
      messages,
      temperature,
      ...(tools && tools.length ? { tools, tool_choice: 'auto' } : {})
    })
  });

  if (!res.ok) {
    return { ok: false, error: parseError(res) };
  }
  const data = JSON.parse(res.body);
  const choice = data.choices?.[0]?.message;
  return {
    ok: true,
    content: choice?.content || '',
    toolCalls: (choice?.tool_calls || []).map(tc => ({
      id: tc.id,
      name: tc.function?.name,
      arguments: safeParseJSON(tc.function?.arguments)
    }))
  };
}

function safeParseJSON(s) {
  try { return JSON.parse(s || '{}'); } catch { return {}; }
}

function parseError(res) {
  if (res.error === 'LOCKDOWN_ACTIVE') return '🔒 Lockdown Mode is active — external network calls are disabled. Turn it off in the Security Center.';
  if (res.error === 'NO_CREDENTIAL') return 'No Groq API key configured.';
  try {
    const parsed = JSON.parse(res.body || '{}');
    return parsed.error?.message || `Request failed (status ${res.status}).`;
  } catch {
    return `Request failed (status ${res.status}).`;
  }
}
