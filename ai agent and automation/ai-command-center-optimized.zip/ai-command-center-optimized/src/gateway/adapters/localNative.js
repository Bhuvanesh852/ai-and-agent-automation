// Adapter for fully local, self-owned inference via node-llama-cpp — NOT
// Ollama. The "model id" for this provider is the absolute path to a .gguf
// file on disk (there's no registry name to look up; models are whatever
// the user has actually placed in their models folder).

export async function callLocalNative({ modelId, messages, requestId }) {
  if (!window.bridge) throw new Error('Not running inside the desktop app — local model calls require the Electron shell.');
  const res = await window.bridge.localModel.chat(modelId, messages.map(m => ({ role: m.role, content: m.content })), requestId);
  if (!res.ok) {
    return { ok: false, error: res.error || 'Local model inference failed.' };
  }
  return { ok: true, content: res.content };
}

export async function listLocalModels() {
  const res = await window.bridge.localModel.list();
  return res.ok ? res : { ok: false, models: [], modelsDir: null };
}
