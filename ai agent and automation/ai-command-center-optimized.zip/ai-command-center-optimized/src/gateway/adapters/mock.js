// Demo/Mock adapter. Fully functional with zero external calls and zero keys.
// Output is always clearly labeled as simulated - never dressed up to look
// like a real model executed something.

const SAMPLES = [
  "This is a DEMO response — no API key is configured, so nothing left your machine. Configure a provider in Settings to get real model output.",
  "[DEMO MODE] Here's a simulated reply so you can explore the interface: agent handoffs, streaming, and tool-call logging all behave like the real thing, just with canned text.",
  "[DEMO MODE] I'd normally call out to a model here. Since no provider is configured, here's placeholder text standing in for that response."
];

export async function* mockStream(messages) {
  const last = messages[messages.length - 1]?.content || '';
  const base = SAMPLES[Math.floor(Math.random() * SAMPLES.length)];
  const text = `${base}\n\nYou said: "${String(last).slice(0, 160)}"`;
  const words = text.split(' ');
  for (const w of words) {
    await new Promise(r => setTimeout(r, 12));
    yield w + ' ';
  }
}
