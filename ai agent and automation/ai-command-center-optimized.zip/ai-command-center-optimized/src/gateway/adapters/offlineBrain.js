// Offline Brain adapter — a REAL, fully-local assistant that requires no API
// key, no downloaded model file, and no network access. It is the default
// provider so the app is genuinely useful the moment it's installed.
//
// Honesty note (same policy as ragEngine.js and mock.js in this codebase):
// this is NOT a large language model. It cannot do open-domain reasoning or
// free-form writing the way a real LLM can. What it DOES do for real,
// on-device, right now:
//   - arithmetic / unit-free numeric expressions
//   - date & time questions
//   - word/character counts, case conversion, simple extractive summarization
//     of pasted text
//   - workspace-aware answers via the existing local TF-IDF RAG engine
//     (electron/ragEngine.js) when a workspace + index exist
//   - deterministic help text for anything it can't actually do, with a
//     clear pointer to Local GGUF Model (also no API key, real LLM quality,
//     one-time model download) or a free-tier cloud provider
//
// This keeps the "works with zero setup" promise honest instead of dressing
// up canned text as if it understood the question.

function tryArithmetic(text) {
  const cleaned = text.trim();
  // Only allow a tight numeric/operator character set — never eval() raw
  // user text. This is a deliberate, narrow calculator, not a code runner.
  if (!/^[\d\s+\-*/().%^]+$/.test(cleaned)) return null;
  if (!/[\d]/.test(cleaned) || !/[+\-*/^%]/.test(cleaned)) return null;
  try {
    const safe = cleaned.replace(/\^/g, '**');
    // eslint-disable-next-line no-new-func
    const value = Function(`"use strict"; return (${safe});`)();
    if (typeof value === 'number' && Number.isFinite(value)) {
      return `${cleaned.trim()} = ${value}`;
    }
  } catch { /* not a valid expression — fall through */ }
  return null;
}

function tryDateTime(text) {
  if (!/\b(what('| i)?s the (date|time)|current time|today'?s date|what day is it)\b/i.test(text)) return null;
  const now = new Date();
  return `Local system time: ${now.toLocaleString()} (${Intl.DateTimeFormat().resolvedOptions().timeZone}).`;
}

function extractQuoted(text) {
  const m = text.match(/summarize[:\s]+["“]?([\s\S]+?)["”]?$/i);
  return m ? m[1] : null;
}

function trySummarize(text) {
  const body = extractQuoted(text) || (/^summarize/i.test(text.trim()) ? text.replace(/^summarize[:\s]*/i, '') : null);
  if (!body || body.split(/\s+/).length < 25) return null;

  const sentences = body.match(/[^.!?]+[.!?]+/g) || [body];
  const freq = {};
  const words = body.toLowerCase().match(/[a-z0-9']+/g) || [];
  const stop = new Set(['the', 'a', 'an', 'and', 'or', 'but', 'is', 'are', 'was', 'were', 'to', 'of', 'in', 'on', 'for', 'it', 'this', 'that', 'with', 'as', 'be', 'by', 'at', 'from']);
  for (const w of words) {
    if (stop.has(w) || w.length < 3) continue;
    freq[w] = (freq[w] || 0) + 1;
  }
  const scored = sentences.map(s => {
    const sw = s.toLowerCase().match(/[a-z0-9']+/g) || [];
    const score = sw.reduce((acc, w) => acc + (freq[w] || 0), 0) / Math.max(1, sw.length);
    return { s: s.trim(), score };
  });
  const top = scored.sort((a, b) => b.score - a.score).slice(0, Math.min(3, Math.max(1, Math.round(sentences.length * 0.3))));
  const ordered = sentences.map(s => s.trim()).filter(s => top.some(t => t.s === s));
  return `[Offline extractive summary — top ${ordered.length} of ${sentences.length} sentences by keyword weight, not an LLM rewrite]\n\n${ordered.join(' ')}`;
}

function tryTextTools(text) {
  const wc = text.match(/^(word count|count words)[:\s]+([\s\S]+)/i);
  if (wc) {
    const body = wc[2];
    return `Words: ${(body.match(/\S+/g) || []).length}. Characters: ${body.length}.`;
  }
  const upper = text.match(/^uppercase[:\s]+([\s\S]+)/i);
  if (upper) return upper[1].toUpperCase();
  const lower = text.match(/^lowercase[:\s]+([\s\S]+)/i);
  if (lower) return lower[1].toLowerCase();
  return null;
}

async function tryWorkspaceRag(text) {
  if (!window.bridge?.rag) return null;
  try {
    const status = await window.bridge.rag.status();
    if (!status?.ok || !status.result?.chunkCount) return null;
  } catch {
    return null;
  }
  const res = await window.bridge.rag.query(text, 5);
  if (!res?.ok || !res.result?.matches?.length) return null;
  const top = res.result.matches.slice(0, 3);
  const cited = top.map((m, i) => `[${i + 1}] ${m.source || m.file || 'workspace'}: ${String(m.text || m.chunk || '').slice(0, 300)}`).join('\n\n');
  return `Found this in your open workspace (local TF-IDF retrieval — no cloud call):\n\n${cited}`;
}

const FALLBACK = (text) => [
  "I'm Offline Brain — I run fully on your machine with no API key and no internet call, so I'm honest about my limits: I handle math, date/time, text utilities (summarize/word count/case), and searching your open workspace.",
  "",
  `I don't have a built-in answer for "${String(text).slice(0, 140)}" — that needs real open-domain reasoning.`,
  "",
  "Two other zero-cost, no-API-key options that WILL answer that:",
  "• Models → Local GGUF Model: point it at a downloaded .gguf file for a real local LLM (node-llama-cpp, already wired in).",
  "• Models → Ollama: if you have Ollama running locally with a model pulled.",
  "Or add a free-tier cloud key (Groq/Gemini/OpenRouter) in Settings for the fastest quality answers."
].join('\n');

export async function callOfflineBrain({ messages }) {
  const last = messages[messages.length - 1]?.content || '';
  try {
    const hit = tryArithmetic(last) || tryDateTime(last) || trySummarize(last) || tryTextTools(last) || await tryWorkspaceRag(last);
    if (hit) return { ok: true, content: hit };
    return { ok: true, content: FALLBACK(last) };
  } catch (err) {
    return { ok: false, error: `Offline Brain error: ${String(err?.message || err)}` };
  }
}

export async function* offlineBrainStream(messages) {
  const result = await callOfflineBrain({ messages });
  const text = result.ok ? result.content : `⚠️ ${result.error}`;
  const words = text.split(' ');
  for (const w of words) {
    await new Promise(r => setTimeout(r, 6));
    yield w + ' ';
  }
}
