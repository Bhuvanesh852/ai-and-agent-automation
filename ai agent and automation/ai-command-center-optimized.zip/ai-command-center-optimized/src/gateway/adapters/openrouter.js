// OpenRouter adapter. OpenAI-compatible schema; ":free" suffixed model ids
// route to OpenRouter's free pool. Proxied through main process.

export async function callOpenRouter({ modelId, messages, temperature = 0.7, tools, requestId }) {
  if (!window.bridge) throw new Error('Not running inside the desktop app — provider calls require the Electron shell.');
  // URL, auth header, and the OpenRouter-specific extra headers are now
  // owned entirely by main.js's provider allowlist — nothing about the
  // destination is sent from the renderer anymore.
  const res = await window.bridge.provider.call({
    providerId: 'openrouter',
    requestId,
    body: JSON.stringify({
      model: modelId,
      messages,
      temperature,
      ...(tools && tools.length ? { tools, tool_choice: 'auto' } : {})
    })
  });

  if (!res.ok) {
    return { ok: false, error: parseError(res) };
  }
  const data = JSON.parse(res.body);
  const choice = data.choices?.[0]?.message;
  return {
    ok: true,
    content: choice?.content || '',
    toolCalls: (choice?.tool_calls || []).map(tc => ({
      id: tc.id,
      name: tc.function?.name,
      arguments: safeParseJSON(tc.function?.arguments)
    }))
  };
}

function safeParseJSON(s) {
  try { return JSON.parse(s || '{}'); } catch { return {}; }
}

function parseError(res) {
  if (res.error === 'LOCKDOWN_ACTIVE') return '🔒 Lockdown Mode is active — external network calls are disabled. Turn it off in the Security Center.';
  if (res.error === 'NO_CREDENTIAL') return 'No OpenRouter API key configured.';
  try {
    const parsed = JSON.parse(res.body || '{}');
    return parsed.error?.message || `Request failed (status ${res.status}).`;
  } catch {
    return `Request failed (status ${res.status}).`;
  }
}
