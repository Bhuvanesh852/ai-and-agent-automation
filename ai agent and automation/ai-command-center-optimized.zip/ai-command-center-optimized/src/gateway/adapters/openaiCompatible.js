// Generic adapter for any provider that speaks the OpenAI /chat/completions
// schema. Groq, Cerebras, Mistral, OpenRouter and GitHub Models all do, so
// adding one of them is now a registry entry + a main-process URL entry, not
// a whole new adapter file.
//
// Same security posture as the existing per-provider adapters: the actual
// HTTP request is proxied through the main process (window.bridge.provider.call)
// which alone owns the destination host, auth header name, and key prefix.
// The renderer can only name a providerId that main already knows about.

const PROVIDER_LABELS = {
  groq: 'Groq',
  cerebras: 'Cerebras',
  mistral: 'Mistral',
  openrouter: 'OpenRouter',
  'github-models': 'GitHub Models'
};

/**
 * @param {object}   opts
 * @param {string}   opts.providerId   must match a key in main.js PROVIDER_CONFIGS
 * @param {string}   opts.modelId
 * @param {object[]} opts.messages
 * @param {number}   [opts.temperature]
 * @param {object[]} [opts.tools]      OpenAI tool schemas; omitted if empty
 * @param {string}   [opts.requestId]  for cancellation
 */
export async function callOpenAICompatible({ providerId, modelId, messages, temperature = 0.7, tools, requestId }) {
  if (!window.bridge) {
    throw new Error('Not running inside the desktop app — provider calls require the Electron shell.');
  }

  const res = await window.bridge.provider.call({
    providerId,
    modelId,
    requestId,
    body: JSON.stringify({
      model: modelId,
      messages,
      temperature,
      ...(tools && tools.length ? { tools, tool_choice: 'auto' } : {})
    })
  });

  if (!res.ok) return { ok: false, error: parseError(res, providerId) };

  let data;
  try {
    data = JSON.parse(res.body);
  } catch {
    return { ok: false, error: `${label(providerId)} returned a non-JSON response.` };
  }

  const choice = data.choices?.[0]?.message;
  return {
    ok: true,
    content: choice?.content || '',
    toolCalls: (choice?.tool_calls || []).map(tc => ({
      id: tc.id,
      name: tc.function?.name,
      arguments: safeParseJSON(tc.function?.arguments)
    }))
  };
}

/** Curried helper so the gateway's ADAPTERS map stays a plain name -> fn table. */
export function makeAdapter(providerId) {
  return (args) => callOpenAICompatible({ ...args, providerId });
}

function label(providerId) {
  return PROVIDER_LABELS[providerId] || providerId;
}

function safeParseJSON(s) {
  try { return JSON.parse(s || '{}'); } catch { return {}; }
}

function parseError(res, providerId) {
  if (res.error === 'LOCKDOWN_ACTIVE') {
    return '🔒 Lockdown Mode is active — external network calls are disabled. Turn it off in the Security Center.';
  }
  if (res.error === 'NO_CREDENTIAL') {
    return `No ${label(providerId)} API key configured. Add one in Settings — it is free to obtain.`;
  }
  if (res.status === 429) {
    return `${label(providerId)} free-tier rate limit hit. The gateway will fall back to the next model in the chain.`;
  }
  try {
    const parsed = JSON.parse(res.body || '{}');
    return parsed.error?.message || parsed.message || `Request failed (status ${res.status}).`;
  } catch {
    return `Request failed (status ${res.status}).`;
  }
}
