// Local Ollama adapter. Runs entirely on-device via http://127.0.0.1:11434,
// no API key involved. Requires the user to have Ollama installed and the
// model pulled (e.g. `ollama pull llama3.2:3b`).

export async function callOllama({ modelId, messages, requestId }) {
  if (!window.bridge) throw new Error('Not running inside the desktop app — Ollama calls require the Electron shell.');
  const res = await window.bridge.ollama.chat(modelId, messages.map(m => ({ role: m.role, content: m.content })), requestId);
  if (!res.ok) {
    return { ok: false, error: res.error || 'Ollama request failed. Is Ollama running?' };
  }
  return { ok: true, content: res.content };
}

export async function listOllamaModels() {
  const res = await window.bridge.ollama.list();
  return res.ok ? res.models : [];
}
