// Google Gemini adapter (AI Studio free tier). Uses generateContent.
// Proxied through main process so the key stays out of renderer JS.

export async function callGemini({ modelId, messages, requestId }) {
  if (!window.bridge) throw new Error('Not running inside the desktop app — provider calls require the Electron shell.');
  const contents = messages
    .filter(m => m.role !== 'system')
    .map(m => ({
      role: m.role === 'assistant' ? 'model' : 'user',
      parts: [{ text: m.content }]
    }));

  const systemMsg = messages.find(m => m.role === 'system');

  // main.js builds the actual URL from a whitelisted template, using only
  // modelId (URL-encoded into a single path segment) — the renderer can no
  // longer supply an arbitrary URL or header name for this call.
  const res = await window.bridge.provider.call({
    providerId: 'gemini',
    modelId,
    requestId,
    body: JSON.stringify({
      contents,
      ...(systemMsg ? { systemInstruction: { parts: [{ text: systemMsg.content }] } } : {})
    })
  });

  if (!res.ok) {
    return { ok: false, error: parseError(res) };
  }
  const data = JSON.parse(res.body);
  const text = data.candidates?.[0]?.content?.parts?.map(p => p.text).join('') || '';
  return { ok: true, content: text };
}

function parseError(res) {
  if (res.error === 'LOCKDOWN_ACTIVE') return '🔒 Lockdown Mode is active — external network calls are disabled. Turn it off in the Security Center.';
  if (res.error === 'NO_CREDENTIAL') return 'No Gemini API key configured.';
  try {
    const parsed = JSON.parse(res.body || '{}');
    return parsed.error?.message || `Request failed (status ${res.status}).`;
  } catch {
    return `Request failed (status ${res.status}).`;
  }
}
