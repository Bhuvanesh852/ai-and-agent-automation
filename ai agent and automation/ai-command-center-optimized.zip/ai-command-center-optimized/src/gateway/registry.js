// Model registry. Every entry mirrors the adapter fields required by the spec:
// provider, model_id, display_name, capability_tags, context_window,
// supports_streaming, supports_tools, supports_vision, supports_json,
// latency_class, cost_class, enabled.
//
// HONESTY NOTE (this matters — the app's rule is "no fake capabilities"):
// every cloud entry below is a real model on a provider that offers a real
// free tier. None of them is a paid-only model dressed up as free. But free
// tiers are the provider's to change: model IDs get retired, quotas get cut,
// regions get restricted. Nothing here is a guarantee, which is why Settings
// has a per-provider "Test Connection" button and the gateway always has a
// local fallback chain underneath. If an ID 404s, fix it here — it is one
// line, and shared/cloudModels.json + this file are the only two places a
// cloud model is named.
//
// The { provider, model_id } pairs come from shared/cloudModels.json, the
// single source of truth also read by electron/apiServer.js (the local
// OpenAI-compatible API). Richer metadata that only the renderer cares about
// (display name, context window, capability tags) stays here.
import cloudModels from '../../shared/cloudModels.json';

function cloudModel(key, extra) {
  const base = cloudModels.find(m => m.key === key);
  if (!base) throw new Error(`shared/cloudModels.json is missing an entry with key "${key}"`);
  return { provider: base.provider, model_id: base.model_id, ...extra };
}

export const REGISTRY = [
  // ---------------------------------------------------------------- local
  {
    provider: 'offline',
    model_id: 'offline-assistant',
    display_name: 'Offline Brain (no key, no download, works everywhere)',
    capability_tags: ['text', 'offline', 'local', 'utility', 'rag'],
    context_window: 8000,
    supports_streaming: true,
    supports_tools: false,
    supports_vision: false,
    supports_json: false,
    latency_class: 'fast',
    cost_class: 'free',
    strength: 'speed',
    enabled: true
  },
  {
    provider: 'demo',
    model_id: 'demo-echo',
    display_name: 'Demo Model (no key needed)',
    capability_tags: ['text', 'demo'],
    context_window: 8000,
    supports_streaming: true,
    supports_tools: false,
    supports_vision: false,
    supports_json: true,
    latency_class: 'fast',
    cost_class: 'free',
    enabled: true
  },
  {
    provider: 'ollama',
    model_id: 'llama3.2:3b',
    display_name: 'Llama 3.2 3B (local, via Ollama)',
    capability_tags: ['text', 'local', 'low-resource'],
    context_window: 128000,
    supports_streaming: true,
    supports_tools: false,
    supports_vision: false,
    supports_json: false,
    latency_class: 'medium',
    cost_class: 'free',
    strength: 'speed',
    enabled: true
  },
  {
    provider: 'ollama',
    model_id: 'qwen2.5:7b',
    display_name: 'Qwen 2.5 7B (local, via Ollama)',
    capability_tags: ['text', 'code', 'local'],
    context_window: 32000,
    supports_streaming: true,
    supports_tools: false,
    supports_vision: false,
    supports_json: false,
    latency_class: 'medium',
    cost_class: 'free',
    strength: 'code',
    enabled: true
  },

  // ------------------------------------------------------- free-tier cloud
  cloudModel('groq-70b', {
    display_name: 'Llama 3.3 70B — Groq (fast, tool-calling)',
    capability_tags: ['text', 'reasoning', 'code', 'fast', 'tools'],
    context_window: 128000,
    supports_streaming: true,
    supports_tools: true,
    supports_vision: false,
    supports_json: true,
    latency_class: 'fast',
    cost_class: 'free-tier',
    strength: 'general',
    enabled: true
  }),
  cloudModel('groq-8b', {
    display_name: 'Llama 3.1 8B Instant — Groq (cheapest hop, drafts)',
    capability_tags: ['text', 'fast', 'tools', 'draft'],
    context_window: 128000,
    supports_streaming: true,
    supports_tools: true,
    supports_vision: false,
    supports_json: true,
    latency_class: 'fast',
    cost_class: 'free-tier',
    strength: 'speed',
    enabled: true
  }),
  cloudModel('gemini-flash', {
    display_name: 'Gemini 2.0 Flash — Google AI Studio (vision, 1M context)',
    capability_tags: ['text', 'vision', 'long-context', 'fast'],
    context_window: 1000000,
    supports_streaming: true,
    supports_tools: true,
    supports_vision: true,
    supports_json: true,
    latency_class: 'fast',
    cost_class: 'free-tier',
    strength: 'long-context',
    enabled: true
  }),
  cloudModel('gemini-lite', {
    display_name: 'Gemini 2.0 Flash Lite — Google AI Studio (high quota)',
    capability_tags: ['text', 'fast', 'long-context'],
    context_window: 1000000,
    supports_streaming: true,
    supports_tools: false,
    supports_vision: false,
    supports_json: true,
    latency_class: 'fast',
    cost_class: 'free-tier',
    enabled: true
  }),
  cloudModel('or-deepseek', {
    display_name: 'DeepSeek R1 — OpenRouter free pool (deep reasoning)',
    capability_tags: ['text', 'reasoning', 'math', 'code'],
    context_window: 64000,
    supports_streaming: true,
    supports_tools: false,
    supports_vision: false,
    supports_json: false,
    latency_class: 'slow',
    cost_class: 'free-tier',
    strength: 'reasoning',
    enabled: true
  }),
  cloudModel('or-qwen', {
    display_name: 'Qwen 2.5 72B — OpenRouter free pool (multilingual, code)',
    capability_tags: ['text', 'code', 'multilingual'],
    context_window: 32000,
    supports_streaming: true,
    supports_tools: false,
    supports_vision: false,
    supports_json: false,
    latency_class: 'medium',
    cost_class: 'free-tier',
    strength: 'code',
    enabled: true
  }),
  cloudModel('or-llama', {
    display_name: 'Llama 3.1 8B — OpenRouter free pool',
    capability_tags: ['text'],
    context_window: 128000,
    supports_streaming: true,
    supports_tools: false,
    supports_vision: false,
    supports_json: false,
    latency_class: 'medium',
    cost_class: 'free-tier',
    enabled: true
  }),
  cloudModel('cerebras-70b', {
    display_name: 'Llama 3.3 70B — Cerebras (very high tokens/sec)',
    capability_tags: ['text', 'reasoning', 'fast'],
    context_window: 8000,
    supports_streaming: true,
    supports_tools: true,
    supports_vision: false,
    supports_json: true,
    latency_class: 'fast',
    cost_class: 'free-tier',
    enabled: true
  }),
  cloudModel('mistral-small', {
    display_name: 'Mistral Small — Mistral free tier (structured output)',
    capability_tags: ['text', 'code', 'json', 'multilingual'],
    context_window: 32000,
    supports_streaming: true,
    supports_tools: true,
    supports_vision: false,
    supports_json: true,
    latency_class: 'fast',
    cost_class: 'free-tier',
    strength: 'structured',
    enabled: true
  }),
  cloudModel('gh-4o-mini', {
    display_name: 'GPT-4o mini — GitHub Models (free with a GitHub token)',
    capability_tags: ['text', 'code', 'tools', 'vision'],
    context_window: 128000,
    supports_streaming: true,
    supports_tools: true,
    supports_vision: true,
    supports_json: true,
    latency_class: 'fast',
    cost_class: 'free-tier',
    enabled: true
  })
];

export const PROVIDERS = [
  { id: 'offline', name: 'Offline Brain (default, no key)', requiresKey: false, docsUrl: null },
  { id: 'demo', name: 'Demo / Mock', requiresKey: false, docsUrl: null },
  {
    id: 'local-native',
    name: 'Local GGUF Model (self-owned, no Ollama)',
    requiresKey: false,
    docsUrl: 'https://node-llama-cpp.withcat.ai/'
  },
  { id: 'ollama', name: 'Ollama (local)', requiresKey: false, docsUrl: 'https://ollama.com/download' },
  {
    id: 'groq',
    name: 'Groq',
    requiresKey: true,
    freeNote: 'Free tier, no card. Fastest tool-calling option here.',
    docsUrl: 'https://console.groq.com/keys'
  },
  {
    id: 'gemini',
    name: 'Google Gemini (AI Studio)',
    requiresKey: true,
    freeNote: 'Free tier, no card. Vision + 1M-token context.',
    docsUrl: 'https://aistudio.google.com/app/apikey'
  },
  {
    id: 'openrouter',
    name: 'OpenRouter',
    requiresKey: true,
    freeNote: 'Free key. Only models suffixed ":free" are registered here, so this stays $0.',
    docsUrl: 'https://openrouter.ai/keys'
  },
  {
    id: 'cerebras',
    name: 'Cerebras',
    requiresKey: true,
    freeNote: 'Free tier, no card. Extremely high tokens/sec.',
    docsUrl: 'https://cloud.cerebras.ai/'
  },
  {
    id: 'mistral',
    name: 'Mistral (La Plateforme)',
    requiresKey: true,
    freeNote: 'Free experiment tier. Good JSON / structured output.',
    docsUrl: 'https://console.mistral.ai/api-keys/'
  },
  {
    id: 'github-models',
    name: 'GitHub Models',
    requiresKey: true,
    freeNote: 'Free with any GitHub personal access token — no extra signup.',
    docsUrl: 'https://github.com/settings/tokens'
  }
];

/** Provider IDs that speak the OpenAI /chat/completions schema. */
export const OPENAI_COMPATIBLE_PROVIDERS = ['groq', 'openrouter', 'cerebras', 'mistral', 'github-models'];

export function modelsForProvider(providerId) {
  return REGISTRY.filter(m => m.provider === providerId && m.enabled);
}

export function findModel(provider, modelId) {
  return REGISTRY.find(m => m.provider === provider && m.model_id === modelId);
}

/**
 * Pick the best registered model for a job, restricted to providers the user
 * actually has configured. Used by the Council and by workflow LLM nodes set
 * to "auto", so a workflow author doesn't have to hardcode a model that may
 * not be set up on this particular machine.
 *
 * @param {string} strength        'general' | 'reasoning' | 'code' | 'speed' | 'long-context' | 'structured'
 * @param {object} providerStatus  { groq: true, gemini: false, ... } from the store
 */
export function pickModel(strength, providerStatus = {}, { requireTools = false } = {}) {
  const available = REGISTRY.filter(m => {
    if (!m.enabled) return false;
    if (m.provider === 'demo') return false;
    if (requireTools && !m.supports_tools) return false;
    if (m.provider === 'offline' || m.provider === 'ollama') return true;
    return providerStatus[m.provider] === true;
  });
  return (
    available.find(m => m.strength === strength) ||
    available.find(m => m.strength === 'general') ||
    available.find(m => m.cost_class === 'free-tier') ||
    REGISTRY.find(m => m.provider === 'offline')
  );
}

/**
 * Distinct free models to poll in Council mode — one per provider so a single
 * provider's rate limit can't take out the whole panel, and so the opinions
 * come from genuinely different model families rather than the same weights
 * twice.
 */
export function councilCandidates(providerStatus = {}, max = 4) {
  const seenProvider = new Set();
  const out = [];
  for (const m of REGISTRY) {
    if (!m.enabled || m.provider === 'demo') continue;
    const usable = m.provider === 'offline' || m.provider === 'ollama' || providerStatus[m.provider] === true;
    if (!usable || seenProvider.has(m.provider)) continue;
    seenProvider.add(m.provider);
    out.push(m);
    if (out.length >= max) break;
  }
  return out;
}
