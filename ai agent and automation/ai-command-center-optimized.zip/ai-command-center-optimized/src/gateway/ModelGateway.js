import { REGISTRY, findModel as registryFindModel, OPENAI_COMPATIBLE_PROVIDERS } from './registry.js';
import { callGroq } from './adapters/groq.js';
import { callGemini } from './adapters/gemini.js';
import { callOpenRouter } from './adapters/openrouter.js';
import { callOllama } from './adapters/ollama.js';
import { callLocalNative } from './adapters/localNative.js';
import { mockStream } from './adapters/mock.js';
import { offlineBrainStream } from './adapters/offlineBrain.js';
import { makeAdapter } from './adapters/openaiCompatible.js';

// Section 5 "Advanced Toggles" -> real generation hints. creativityMode maps
// to sampling temperature (adapters already accept `temperature`); reasoningMode
// and safetyFilterOn prepend real system-prompt instructions instead of being
// decorative. debugMode is read by the caller (useAppStore), not here.
const CREATIVITY_TEMPERATURE = { low: 0.2, medium: 0.7, high: 1.1 };
const REASONING_PREAMBLE = {
  fast: null,
  balanced: null,
  deep: 'Think through this step by step internally before giving your final answer. Show your key reasoning steps briefly, then conclude with a clear final answer.'
};
const SAFETY_PREAMBLE = 'Follow standard content-safety practice: refuse or safely redirect requests for malicious code, weapons, or other clearly harmful content, even if asked to roleplay past it.';

export function applyHints(messages, hints = {}) {
  const extra = [];
  if (hints.safetyFilterOn) extra.push({ role: 'system', content: SAFETY_PREAMBLE });
  const reasoningMsg = REASONING_PREAMBLE[hints.reasoningMode];
  if (reasoningMsg) extra.push({ role: 'system', content: reasoningMsg });
  if (extra.length === 0) return messages;
  // Insert right after the first system message (the agent's persona) so the
  // agent's own instructions still take priority in the prompt ordering.
  const out = [...messages];
  const insertAt = out[0]?.role === 'system' ? 1 : 0;
  out.splice(insertAt, 0, ...extra);
  return out;
}

export function temperatureForHints(hints = {}) {
  return CREATIVITY_TEMPERATURE[hints.creativityMode] ?? 0.7;
}

const ADAPTERS = {
  // Hand-written adapters kept for the two providers with provider-specific
  // quirks (Groq predates the generic one; Gemini is not OpenAI-shaped).
  groq: callGroq,
  gemini: callGemini,
  openrouter: callOpenRouter,
  ollama: callOllama,
  'local-native': callLocalNative,
  // Everything else that speaks OpenAI /chat/completions is generated from
  // one generic adapter, so adding a new free provider is a registry entry
  // plus a main-process URL entry — no new adapter file.
  ...Object.fromEntries(
    OPENAI_COMPATIBLE_PROVIDERS
      .filter(id => !['groq', 'openrouter'].includes(id))
      .map(id => [id, makeAdapter(id)])
  )
};

const findModel = registryFindModel;

/**
 * Dispatch a chat request to a specific provider/model. Returns
 * { ok, content, providerUsed, modelUsed, fellBackFrom? }.
 *
 * fallbackChain: ordered list of { provider, model_id } to try if the
 * primary fails. Never includes a "paid" tier unless the user explicitly
 * put it in the chain themselves (no silent upgrade to a paid model).
 */
export async function dispatchChat({ provider, modelId, messages, fallbackChain = [], onStreamToken, requestId, hints = {} }) {
  const chain = [{ provider, model_id: modelId }, ...fallbackChain];
  const hinted = applyHints(messages, hints);
  const temperature = temperatureForHints(hints);

  for (let i = 0; i < chain.length; i++) {
    const { provider: p, model_id: m } = chain[i];

    if (p === 'demo') {
      let full = '';
      for await (const token of mockStream(hinted)) {
        full += token;
        onStreamToken && onStreamToken(token);
      }
      return { ok: true, content: full, providerUsed: 'demo', modelUsed: m, fellBackFrom: i > 0 ? chain[0] : undefined };
    }

    if (p === 'offline') {
      let full = '';
      for await (const token of offlineBrainStream(hinted)) {
        full += token;
        onStreamToken && onStreamToken(token);
      }
      return { ok: true, content: full, providerUsed: 'offline', modelUsed: m, fellBackFrom: i > 0 ? chain[0] : undefined };
    }

    const meta = findModel(p, m);
    // local-native models are dynamic (whatever .gguf files the user has on
    // disk) so they never appear in the static REGISTRY — skip the lookup
    // for that provider instead of treating "not found" as "not configured".
    if (p !== 'local-native' && (!meta || !meta.enabled)) continue;

    const adapter = ADAPTERS[p];
    if (!adapter) continue;

    try {
      const result = await adapter({ modelId: m, messages: hinted, temperature, requestId });
      if (result.ok) {
        return {
          ok: true,
          content: result.content,
          providerUsed: p,
          modelUsed: m,
          fellBackFrom: i > 0 ? chain[0] : undefined
        };
      }
      // fall through to next in chain on failure
      if (i === chain.length - 1) {
        return { ok: false, error: result.error, providerUsed: p, modelUsed: m };
      }
    } catch (err) {
      if (i === chain.length - 1) {
        return { ok: false, error: String(err?.message || err), providerUsed: p, modelUsed: m };
      }
    }
  }

  // Nothing in the chain worked or was configured -> deterministic local fallback.
  let full = '';
  for await (const token of mockStream(messages)) {
    full += token;
    onStreamToken && onStreamToken(token);
  }
  return { ok: true, content: full, providerUsed: 'demo', modelUsed: 'demo-echo', fellBackFrom: chain[0] };
}

export function buildDefaultFallbackChain(preferredProvider) {
  // premium/cloud -> local Ollama -> real offline assistant -> deterministic
  // demo text, per the spec's example. offline comes before demo now that
  // it can give a genuinely useful (if narrower) answer instead of canned text.
  const chain = [];
  if (preferredProvider !== 'ollama') chain.push({ provider: 'ollama', model_id: 'llama3.2:3b' });
  if (preferredProvider !== 'offline') chain.push({ provider: 'offline', model_id: 'offline-assistant' });
  chain.push({ provider: 'demo', model_id: 'demo-echo' });
  return chain;
}

// Model Merge = "hybrid" (Section 5 toggle): fan the same prompt out to two
// providers concurrently and return both results so the UI can show them
// side by side, instead of silently picking one. Only used for the
// no-tool-calling chat path — tool-using agent turns stay single-model
// (running two independent tool loops against the same workspace at once is
// unsafe/confusing, so hybrid is scoped to plain chat comparison).
export async function dispatchHybrid({ primary, secondary, messages, hints = {}, requestId }) {
  const [a, b] = await Promise.all([
    dispatchChat({ provider: primary.provider, modelId: primary.model_id, messages, hints, requestId: requestId + '-a' }),
    dispatchChat({ provider: secondary.provider, modelId: secondary.model_id, messages, hints, requestId: requestId + '-b' })
  ]);
  return { a, b };
}
