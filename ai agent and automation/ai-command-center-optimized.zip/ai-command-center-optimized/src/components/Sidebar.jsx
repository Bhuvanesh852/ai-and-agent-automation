import React from 'react';

const NAV = [
  { section: 'Workspace', items: [
    { id: 'chat', label: 'Chat', icon: '💬' },
    { id: 'projects', label: 'Projects', icon: '📁' },
    { id: 'files', label: 'Files', icon: '🗂️' },
    { id: 'repo', label: 'Repository', icon: '🧭' },
    { id: 'rag', label: 'RAG Knowledge', icon: '📚' }
  ]},
  { section: 'System', items: [
    { id: 'models', label: 'Models', icon: '🧩' },
    { id: 'agents', label: 'Agents', icon: '🤖' },
    { id: 'automations', label: 'Automations', icon: '⚡' },
    { id: 'council', label: 'AI Council', icon: '⚖️' },
    { id: 'tests', label: 'Tests', icon: '✅' },
    { id: 'localapi', label: 'Local API', icon: '🔌' },
    { id: 'mcp', label: 'MCP Connections', icon: '🧷' },
    { id: 'security', label: 'Security Center', icon: '🛡️' }
  ]},
  { section: 'Admin', items: [
    { id: 'settings', label: 'Settings', icon: '⚙️' },
    { id: 'logs', label: 'Logs', icon: '📜' }
  ]}
];

export default function Sidebar({ activeView, onSelect }) {
  return (
    <div className="sidebar">
      <div className="brand">⌘ AI Command Center</div>
      {NAV.map(group => (
        <div key={group.section}>
          <div className="nav-section-title">{group.section}</div>
          {group.items.map(item => (
            <div
              key={item.id}
              className={`nav-item ${activeView === item.id ? 'active' : ''}`}
              onClick={() => onSelect(item.id)}
            >
              <span>{item.icon}</span>
              <span>{item.label}</span>
            </div>
          ))}
        </div>
      ))}
    </div>
  );
}
