import React, { useEffect, useState } from 'react';
import { useAutomationStore } from '../store/useAutomationStore.js';
import { NODE_TYPES, nodeDef, typesByCategory, NODE_CATEGORIES } from '../automation/nodes.js';
import { validateWorkflow } from '../automation/WorkflowEngine.js';
import { TOOLS } from '../agents/tools.js';
import { AGENTS } from '../agents/agents.js';

export default function AutomationsPanel() {
  const auto = useAutomationStore();
  const [selectedNodeId, setSelectedNodeId] = useState(null);
  const [triggerInput, setTriggerInput] = useState('');
  const [addAfter, setAddAfter] = useState(null);
  const [importOpen, setImportOpen] = useState(false);
  const [importText, setImportText] = useState('');
  const [importMsg, setImportMsg] = useState(null);

  useEffect(() => {
    if (!auto.loaded) auto.load();
  }, [auto.loaded]);

  const wf = auto.activeWorkflow();
  const running = auto.runningWorkflowId === wf?.id;
  const validation = wf ? validateWorkflow(wf) : { ok: true, problems: [] };
  const selectedNode = wf?.nodes.find(n => n.id === selectedNodeId) || null;

  const handleImport = () => {
    const res = auto.importWorkflow(importText);
    if (res.ok) {
      setImportMsg({ tone: 'ok', text: res.problems?.length ? `Imported with warnings: ${res.problems.join(' ')}` : 'Imported.' });
      setImportText('');
    } else {
      setImportMsg({ tone: 'err', text: res.error });
    }
  };

  return (
    <div className="settings-panel automations">
      <div className="panel-head">
        <div>
          <h2 style={{ margin: 0 }}>⚡ Automations</h2>
          <p className="hint" style={{ margin: '4px 0 0' }}>
            Visual workflows in the n8n style — trigger, then a chain of AI, data, logic and integration nodes.
            Everything runs on free tiers and the local machine.
          </p>
        </div>
        <div className="panel-actions">
          <button onClick={() => auto.createWorkflow()}>+ New</button>
          <button onClick={() => setImportOpen(o => !o)}>Import</button>
          <button onClick={() => auto.restoreTemplates()}>Add templates</button>
        </div>
      </div>

      {importOpen && (
        <div className="import-box">
          <textarea
            rows={5}
            value={importText}
            onChange={e => setImportText(e.target.value)}
            placeholder="Paste an exported workflow JSON here"
          />
          <p className="hint warn">
            ⚠ Read an imported workflow before running it. Transform and If/Else nodes execute JavaScript with the
            app's own privileges, and HTTP nodes can send your data anywhere. Treat a shared workflow like a shared
            shell script.
          </p>
          <div className="row-actions">
            <button onClick={handleImport} disabled={!importText.trim()}>Import workflow</button>
            {importMsg && <span className={importMsg.tone === 'ok' ? 'ok-text' : 'err-text'}>{importMsg.text}</span>}
          </div>
        </div>
      )}

      <div className="automations-grid">
        {/* ------------------------------------------------ workflow list */}
        <aside className="wf-list">
          {auto.workflows.length === 0 && <p className="hint">No workflows yet.</p>}
          {auto.workflows.map(w => (
            <div
              key={w.id}
              className={`wf-card ${w.id === auto.activeWorkflowId ? 'active' : ''}`}
              onClick={() => { auto.setActiveWorkflow(w.id); setSelectedNodeId(null); }}
            >
              <div className="wf-card-title">{w.name}</div>
              <div className="wf-card-meta">
                {w.nodes.length} nodes
                {w.scheduleEnabled && <span className="badge sched">scheduled</span>}
                {(w.tags || []).map(t => <span key={t} className="badge">{t}</span>)}
              </div>
            </div>
          ))}
        </aside>

        {/* ------------------------------------------------------ builder */}
        <section className="wf-builder">
          {!wf && <p className="hint">Select or create a workflow.</p>}

          {wf && (
            <>
              <div className="wf-header">
                <input
                  className="wf-name"
                  value={wf.name}
                  onChange={e => auto.updateWorkflow(wf.id, { name: e.target.value })}
                />
                <div className="row-actions">
                  <button
                    className="primary"
                    disabled={running || !validation.ok}
                    onClick={() => auto.run(wf.id, triggerInput || undefined)}
                  >
                    {running ? 'Running…' : '▶ Run'}
                  </button>
                  {running && <button onClick={auto.cancelRun}>⏹ Stop</button>}
                  <button onClick={() => auto.duplicateWorkflow(wf.id)}>Duplicate</button>
                  <button onClick={() => navigator.clipboard?.writeText(auto.exportWorkflow(wf.id))}>Export</button>
                  <button className="danger" onClick={() => auto.deleteWorkflow(wf.id)}>Delete</button>
                </div>
              </div>

              <input
                className="wf-desc"
                value={wf.description || ''}
                placeholder="What does this workflow do?"
                onChange={e => auto.updateWorkflow(wf.id, { description: e.target.value })}
              />

              {wf.nodes.some(n => n.type === 'trigger.schedule') && (
                <label className="sched-row">
                  <input type="checkbox" checked={!!wf.scheduleEnabled} onChange={() => auto.toggleSchedule(wf.id)} />
                  Enable schedule
                  <span className="hint inline">
                    Timers only run while this app is open — a desktop app can't fire a schedule when it isn't running.
                  </span>
                </label>
              )}

              {wf.nodes.some(n => n.type === 'trigger.webhook') && (
                <label className="sched-row">
                  <input type="checkbox" checked={!!wf.webhookEnabled} onChange={() => auto.toggleWebhook(wf.id)} />
                  Enable webhook
                  <span className="hint inline">
                    Start the Local API server (Sidebar → Local API), then POST to
                    {' '}<code>/webhook/{wf.nodes.find(n => n.type === 'trigger.webhook')?.config?.path || '<path>'}</code>
                    {' '}with your API bearer token. The request body becomes the trigger input.
                  </span>
                </label>
              )}

              <input
                className="wf-input"
                value={triggerInput}
                placeholder="Run input (overrides the trigger's default)"
                onChange={e => setTriggerInput(e.target.value)}
              />

              {!validation.ok && (
                <div className="validation-box">
                  {validation.problems.map((p, i) => <div key={i} className="err-text">⚠ {p}</div>)}
                </div>
              )}

              {/* node chain */}
              <div className="node-chain">
                {wf.nodes.map(node => {
                  const def = nodeDef(node.type);
                  const live = auto.liveSteps.find(s => s.nodeId === node.id);
                  return (
                    <div key={node.id}>
                      <div
                        className={`node-card ${selectedNodeId === node.id ? 'selected' : ''} ${live ? `step-${live.status}` : ''}`}
                        onClick={() => setSelectedNodeId(node.id === selectedNodeId ? null : node.id)}
                      >
                        <span className="node-icon">{def?.icon || '▫️'}</span>
                        <div className="node-body">
                          <div className="node-title">
                            {node.name || def?.label || node.type}
                            <span className="node-type">{def?.label || node.type}</span>
                          </div>
                          <div className="node-sub">{def?.description}</div>
                          {live?.status === 'error' && <div className="err-text">✕ {live.error}</div>}
                          {live?.status === 'ok' && <div className="ok-text">✓ {live.durationMs}ms</div>}
                        </div>
                      </div>

                      {selectedNodeId === node.id && (
                        <NodeEditor
                          node={node}
                          workflowId={wf.id}
                          onChange={patch => auto.updateNode(wf.id, node.id, patch)}
                          onRemove={() => { auto.removeNode(wf.id, node.id); setSelectedNodeId(null); }}
                        />
                      )}

                      <div className="add-row">
                        <button className="ghost" onClick={() => setAddAfter(addAfter === node.id ? null : node.id)}>
                          + add node below
                        </button>
                      </div>

                      {addAfter === node.id && (
                        <NodePicker
                          onPick={type => { auto.addNode(wf.id, type, node.id); setAddAfter(null); }}
                          onClose={() => setAddAfter(null)}
                        />
                      )}
                    </div>
                  );
                })}
              </div>
            </>
          )}
        </section>

        {/* ---------------------------------------------------- run panel */}
        <aside className="wf-runs">
          <h4>Recent runs</h4>
          {auto.runs.length === 0 && <p className="hint">No runs yet.</p>}
          {auto.runs.slice(0, 12).map(r => (
            <div key={r.runId} className={`run-card ${r.ok ? 'ok' : 'err'}`}>
              <div className="run-title">
                {r.ok ? '✓' : '✕'} {r.workflowName}
                <span className="run-meta">{r.source} · {Math.round((r.durationMs || 0) / 100) / 10}s</span>
              </div>
              {!r.ok && <div className="err-text small">{r.error}</div>}
              {r.ok && <pre className="run-output">{preview(r.output)}</pre>}
            </div>
          ))}
          {auto.runs.length > 0 && <button className="ghost" onClick={auto.clearRuns}>Clear run history</button>}
        </aside>
      </div>
    </div>
  );
}

function preview(v) {
  const s = typeof v === 'string' ? v : JSON.stringify(v, null, 2);
  return String(s || '').slice(0, 600);
}

function NodePicker({ onPick, onClose }) {
  const grouped = typesByCategory();
  return (
    <div className="node-picker">
      {NODE_CATEGORIES.map(cat => (
        <div key={cat} className="picker-group">
          <div className="picker-cat">{cat}</div>
          {(grouped[cat] || []).map(t => (
            <button key={t.type} className="picker-item" onClick={() => onPick(t.type)} title={t.description}>
              {t.icon} {t.label}
            </button>
          ))}
        </div>
      ))}
      <button className="ghost" onClick={onClose}>cancel</button>
    </div>
  );
}

function NodeEditor({ node, onChange, onRemove }) {
  const def = nodeDef(node.type);
  if (!def) return null;

  const setConfig = (key, value) => onChange({ config: { ...node.config, [key]: value } });

  return (
    <div className="node-editor">
      <label className="field">
        <span>Node name (referenced as {'{{node.Name}}'} downstream)</span>
        <input value={node.name || ''} onChange={e => onChange({ name: e.target.value })} placeholder={def.label} />
      </label>

      {(def.fields || []).map(f => (
        <label key={f.key} className="field">
          <span>{f.label}</span>
          {f.type === 'textarea' && (
            <textarea rows={4} value={node.config?.[f.key] ?? ''} placeholder={f.placeholder} onChange={e => setConfig(f.key, e.target.value)} />
          )}
          {f.type === 'text' && (
            <input value={node.config?.[f.key] ?? ''} placeholder={f.placeholder} onChange={e => setConfig(f.key, e.target.value)} />
          )}
          {f.type === 'number' && (
            <input type="number" value={node.config?.[f.key] ?? ''} onChange={e => setConfig(f.key, Number(e.target.value))} />
          )}
          {f.type === 'select' && (
            <select value={node.config?.[f.key] ?? f.default} onChange={e => setConfig(f.key, e.target.value)}>
              {f.options.map(o => <option key={o} value={o}>{o}</option>)}
            </select>
          )}
          {f.type === 'multiselect' && (
            <div className="checkbox-row">
              {f.options.map(o => {
                const current = node.config?.[f.key] || [];
                return (
                  <label key={o} className="inline-check">
                    <input
                      type="checkbox"
                      checked={current.includes(o)}
                      onChange={() =>
                        setConfig(f.key, current.includes(o) ? current.filter(x => x !== o) : [...current, o])
                      }
                    />
                    {o}
                  </label>
                );
              })}
            </div>
          )}
          {f.type === 'tool-select' && (
            <select value={node.config?.[f.key] ?? ''} onChange={e => setConfig(f.key, e.target.value)}>
              <option value="">— choose a tool —</option>
              {TOOLS.map(t => (
                <option key={t.name} value={t.name}>
                  {t.name}{t.riskLevel === 'risky' ? ' (needs approval)' : ''}
                </option>
              ))}
            </select>
          )}
          {f.type === 'agent-select' && (
            <select value={node.config?.[f.key] ?? ''} onChange={e => setConfig(f.key, e.target.value)}>
              <option value="">— choose an agent —</option>
              {AGENTS.map(a => <option key={a.id} value={a.id}>{a.icon} {a.name}</option>)}
            </select>
          )}
          {f.hint && <span className="hint small">{f.hint}</span>}
        </label>
      ))}

      {node.type === 'condition' && (
        <p className="hint small">
          This node has two outgoing edges. Edit them in the exported JSON (<code>trueNext</code> / <code>falseNext</code>)
          — the visual branch editor is the next thing to build here.
        </p>
      )}

      <button className="danger ghost" onClick={onRemove}>Remove node</button>
    </div>
  );
}

export { NODE_TYPES };
