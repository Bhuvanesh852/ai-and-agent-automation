import React, { useEffect, useState } from 'react';
import { useAutomationStore } from '../store/useAutomationStore.js';

// Replaces the "scaffolded" placeholder. Three log streams already existed in
// the app but had nowhere to be read: the in-memory activity feed, the
// persisted security audit trail, and workflow run history.
const TABS = [
  { id: 'activity', label: 'Activity' },
  { id: 'audit', label: 'Security audit' },
  { id: 'runs', label: 'Workflow runs' }
];

export default function LogsPanel({ store }) {
  const [tab, setTab] = useState('activity');
  const [filter, setFilter] = useState('');
  const auto = useAutomationStore();

  useEffect(() => {
    store.loadSecurityState();
    if (!auto.loaded) auto.load();
  }, []);

  const match = (s) => !filter || String(s).toLowerCase().includes(filter.toLowerCase());

  const exportJson = () => {
    const payload = { activity: store.activity, audit: store.auditLog, runs: auto.runs, exportedAt: new Date().toISOString() };
    const blob = new Blob([JSON.stringify(payload, null, 2)], { type: 'application/json' });
    const a = document.createElement('a');
    a.href = URL.createObjectURL(blob);
    a.download = `ai-command-center-logs-${Date.now()}.json`;
    a.click();
    URL.revokeObjectURL(a.href);
  };

  return (
    <div className="settings-panel logs-panel">
      <div className="panel-head">
        <h2 style={{ margin: 0 }}>📜 Logs</h2>
        <div className="panel-actions">
          <input value={filter} placeholder="Filter…" onChange={e => setFilter(e.target.value)} />
          <button onClick={exportJson}>Export all</button>
        </div>
      </div>

      <div className="tab-row">
        {TABS.map(t => (
          <button key={t.id} className={`tab ${tab === t.id ? 'active' : ''}`} onClick={() => setTab(t.id)}>
            {t.label}
          </button>
        ))}
      </div>

      {tab === 'activity' && (
        <div className="log-stream">
          {(store.activity || []).filter(a => match(a.text)).length === 0 && <p className="hint">Nothing logged yet.</p>}
          {(store.activity || []).filter(a => match(a.text)).map((a, i) => (
            <div key={i} className="log-line">
              <span className="badge">{a.category || 'general'}</span>
              <span>{a.text}</span>
              {a.ts && <span className="log-time">{new Date(a.ts).toLocaleTimeString()}</span>}
            </div>
          ))}
        </div>
      )}

      {tab === 'audit' && (
        <div className="log-stream">
          <p className="hint">
            Persisted security trail — tool approvals, denials, lockdown toggles. This survives restarts.
          </p>
          {(store.auditLog || []).filter(e => match(JSON.stringify(e))).length === 0 && <p className="hint">No audit entries yet.</p>}
          {(store.auditLog || []).filter(e => match(JSON.stringify(e))).map((e, i) => (
            <div key={i} className="log-line">
              <span className={`badge ${e.decision === 'denied' ? 'risky' : ''}`}>{e.decision || e.type || 'event'}</span>
              <span>{e.tool || e.message || JSON.stringify(e).slice(0, 200)}</span>
              {e.ts && <span className="log-time">{new Date(e.ts).toLocaleString()}</span>}
            </div>
          ))}
        </div>
      )}

      {tab === 'runs' && (
        <div className="log-stream">
          {auto.runs.filter(r => match(r.workflowName)).length === 0 && <p className="hint">No workflow runs yet.</p>}
          {auto.runs.filter(r => match(r.workflowName)).map(r => (
            <details key={r.runId} className={`run-detail ${r.ok ? 'ok' : 'err'}`}>
              <summary>
                {r.ok ? '✓' : '✕'} {r.workflowName}
                <span className="log-time">
                  {r.source} · {r.steps?.length || 0} steps · {Math.round((r.durationMs || 0) / 100) / 10}s ·{' '}
                  {r.finishedAt ? new Date(r.finishedAt).toLocaleString() : ''}
                </span>
              </summary>
              {!r.ok && <div className="err-text">{r.error}</div>}
              {(r.steps || []).map((s, i) => (
                <div key={i} className={`step-line ${s.status}`}>
                  <b>{s.nodeName}</b> <span className="hint inline">{s.type} · {s.durationMs}ms</span>
                  <pre>{s.status === 'error' ? s.error : truncate(s.output)}</pre>
                </div>
              ))}
            </details>
          ))}
        </div>
      )}
    </div>
  );
}

function truncate(v) {
  const s = typeof v === 'string' ? v : JSON.stringify(v, null, 2);
  const str = String(s || '');
  return str.length > 800 ? `${str.slice(0, 800)}\n… (${str.length - 800} more chars)` : str;
}
