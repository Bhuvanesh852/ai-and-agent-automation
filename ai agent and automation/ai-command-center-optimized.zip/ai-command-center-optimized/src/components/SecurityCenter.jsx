import React, { useEffect, useState } from 'react';
import { computeAgentPermissionRisks, computeScore } from '../security/scoring.js';

function ScoreRing({ score }) {
  const color = score >= 85 ? 'var(--success)' : score >= 60 ? 'var(--warn)' : 'var(--danger)';
  return (
    <div style={{ display: 'flex', alignItems: 'center', gap: 16 }}>
      <div style={{
        width: 84, height: 84, borderRadius: '50%',
        border: `6px solid ${color}`, display: 'flex', alignItems: 'center', justifyContent: 'center',
        fontSize: 22, fontWeight: 700
      }}>
        {score}
      </div>
      <div>
        <div style={{ fontSize: 13, color: 'var(--text-dim)' }}>Security Score</div>
        <div className="hint">Never treat this as "100% secure" — it reflects only what's been scanned so far.</div>
      </div>
    </div>
  );
}

function FindingRow({ severity, count }) {
  const color = { Critical: 'var(--danger)', High: 'var(--warn)', Medium: 'var(--accent)', Low: 'var(--text-dim)' }[severity];
  return (
    <div className="row" style={{ padding: '6px 0' }}>
      <span style={{ color }}>{severity}</span>
      <strong>{count}</strong>
    </div>
  );
}

export default function SecurityCenter({ store }) {
  const [scanning, setScanning] = useState(false);

  useEffect(() => {
    store.loadSecurityState();
  }, []);

  const runScan = async (scope) => {
    setScanning(true);
    await store.runSecurityScan(scope);
    setScanning(false);
  };

  const secrets = store.securityFindings.secrets;
  const deps = store.securityFindings.dependencies;
  const network = store.securityFindings.network;
  const secretFindings = secrets && !secrets.error ? secrets.findings : [];
  const depFindings = deps && !deps.error ? deps.findings : [];
  const networkFindings = network && !network.error ? network.findings : [];
  const permissionRisks = computeAgentPermissionRisks();
  const { score, counts } = computeScore({ secretFindings, dependencyFindings: depFindings, networkFindings, permissionRisks });

  return (
    <div className="settings-panel" style={{ maxWidth: 760 }}>
      <h2 style={{ marginTop: 0 }}>Security Center</h2>
      <p className="hint">
        CyberShield performs defensive scanning of this workspace only. Nothing here is sent to any
        AI model or external service — findings stay on your machine.
      </p>

      <div className="provider-card">
        <ScoreRing score={score} />
      </div>

      <div className="provider-card">
        <div className="row">
          <strong>🛑 Emergency controls</strong>
        </div>
        <div className="row" style={{ marginTop: 10, gap: 8 }}>
          <button
            className={store.stopAllActive ? 'primary' : 'ghost'}
            onClick={() => store.setStopAll(!store.stopAllActive)}
            style={store.stopAllActive ? { background: 'var(--danger)', color: '#fff' } : {}}
          >
            {store.stopAllActive ? '▶ Resume Agents' : '🛑 STOP ALL AGENTS'}
          </button>
          <button
            className={store.lockdownMode ? 'primary' : 'ghost'}
            onClick={() => store.toggleLockdown()}
            style={store.lockdownMode ? { background: 'var(--warn)', color: '#0b0d12' } : {}}
          >
            {store.lockdownMode ? '🔒 Lockdown ON — click to disable' : '🔓 Enable Lockdown Mode'}
          </button>
        </div>
        <div className="hint">
          STOP ALL AGENTS immediately halts any in-progress and new agent turns. Lockdown Mode disables
          all external network calls (cloud models, provider APIs) and blocks terminal/git-commit tools —
          local Ollama chat still works since it never leaves your machine.
        </div>
      </div>

      <div className="provider-card">
        <div className="row">
          <strong>Run a scan</strong>
          <span className="hint">
            {store.securityFindings.lastScanAt ? `Last scan: ${new Date(store.securityFindings.lastScanAt).toLocaleTimeString()}` : 'Never scanned'}
          </span>
        </div>
        <div className="row" style={{ marginTop: 10, gap: 8 }}>
          <button className="ghost" disabled={scanning} onClick={() => runScan('quick')}>Quick Scan</button>
          <button className="ghost" disabled={scanning} onClick={() => runScan('standard')}>Standard Scan</button>
          <button className="ghost" disabled={scanning} onClick={() => runScan('deep')}>Deep Security Audit</button>
        </div>
        <div className="hint">
          Quick: secrets only. Standard: secrets + dependencies + network/cyber patterns + agent permissions. Deep: same checks, run
          against the full workspace tree (heavier scans are intentionally opt-in on 8GB-class hardware).
        </div>
      </div>

      <h4>Findings by severity</h4>
      <div className="provider-card">
        {['Critical', 'High', 'Medium', 'Low'].map(s => <FindingRow key={s} severity={s} count={counts[s]} />)}
      </div>

      <h4>Cybersecurity: Network &amp; Execution Patterns {networkFindings.length > 0 && `(${networkFindings.length})`}</h4>
      <div className="provider-card">
        {!network && <div className="hint">Run a Standard or Deep scan to check for risky network/exec patterns (disabled TLS verification, eval on dynamic input, shell-injection-prone exec calls, wildcard CORS, credentials in plaintext URLs).</div>}
        {network?.error && <div className="hint">⚠️ {network.error}</div>}
        {network && !network.error && networkFindings.length === 0 && (
          <div className="hint">✅ No risky network/execution patterns found in {network.filesScanned} file(s) scanned.</div>
        )}
        {networkFindings.slice(0, 20).map((f, i) => (
          <div key={i} className="activity-item">
            <strong style={{ color: 'var(--danger)' }}>{f.severity}</strong> — {f.label} in <code>{f.file}:{f.line}</code>
          </div>
        ))}
        {networkFindings.length > 20 && <div className="hint">…and {networkFindings.length - 20} more.</div>}
      </div>

      <h4>Secrets Detected {secretFindings.length > 0 && `(${secretFindings.length})`}</h4>
      <div className="provider-card">
        {!secrets && <div className="hint">Run a scan to check for exposed credentials.</div>}
        {secrets?.error && <div className="hint">⚠️ {secrets.error}</div>}
        {secrets && !secrets.error && secretFindings.length === 0 && (
          <div className="hint">✅ No obvious secrets found in {secrets.filesScanned} file(s) scanned.</div>
        )}
        {secretFindings.slice(0, 20).map((f, i) => (
          <div key={i} className="activity-item">
            <strong style={{ color: 'var(--danger)' }}>{f.severity}</strong> — {f.label} in <code>{f.file}:{f.line}</code>
            {' '}(masked: {f.preview}){f.isEnvFile ? ' — .env file, double-check it is gitignored' : ''}
          </div>
        ))}
        {secretFindings.length > 20 && <div className="hint">…and {secretFindings.length - 20} more.</div>}
      </div>

      <h4>Dependency Risks {depFindings.length > 0 && `(${depFindings.length})`}</h4>
      <div className="provider-card">
        {!deps && <div className="hint">Run a Standard or Deep scan to check dependency manifests.</div>}
        {deps?.error && <div className="hint">⚠️ {deps.error}</div>}
        {deps && !deps.error && (
          <>
            <div className="hint">{deps.note}</div>
            {depFindings.slice(0, 20).map((f, i) => (
              <div key={i} className="activity-item">
                <strong>{f.severity}</strong> — {f.name}@{f.spec} ({f.manifest}) — {f.reason}
              </div>
            ))}
          </>
        )}
      </div>

      <h4>Agent Permission Risks {permissionRisks.length > 0 && `(${permissionRisks.length})`}</h4>
      <div className="provider-card">
        {permissionRisks.length === 0 && (
          <div className="hint">✅ Every configured agent has an explicit, approval-gated permission profile.</div>
        )}
        {permissionRisks.map((r, i) => (
          <div key={i} className="activity-item"><strong>{r.severity}</strong> — {r.agent}: {r.reason}</div>
        ))}
      </div>

      <h4>Authentication, API, and Windows Configuration Risks</h4>
      <div className="provider-card">
        <div className="hint">
          Not scanned in this build — this app has no login/auth system or exposed API surface of its own
          yet, and Windows OS-level checks (firewall, startup persistence, exposed services) aren't wired up.
          These categories are reserved so they can report real findings once that surface exists, rather
          than showing a fabricated "all clear."
        </div>
      </div>

      <h4>Audit Log</h4>
      <div className="provider-card">
        {store.auditLog.length === 0 && <div className="hint">No audit entries yet.</div>}
        {[...store.auditLog].reverse().slice(0, 30).map((entry, i) => (
          <div key={i} className="activity-item">
            <span style={{ color: 'var(--text-dim)' }}>[{entry.category}]</span> {entry.message}
          </div>
        ))}
      </div>
    </div>
  );
}
