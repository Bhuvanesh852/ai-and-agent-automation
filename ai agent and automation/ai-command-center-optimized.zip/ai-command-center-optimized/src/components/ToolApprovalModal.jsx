import React from 'react';

export default function ToolApprovalModal({ store }) {
  const p = store.pendingApproval;
  if (!p) return null;

  return (
    <div className="command-palette-overlay">
      <div className="command-palette" style={{ width: 460 }}>
        <div style={{ padding: '16px 18px' }}>
          <div style={{ fontSize: 12, textTransform: 'uppercase', letterSpacing: '0.06em', color: 'var(--warn)', marginBottom: 8 }}>
            ⚠️ Approval required — risky action
          </div>
          <div style={{ fontSize: 14, marginBottom: 10 }}>
            The active agent wants to run <strong>{p.name}</strong>
          </div>
          <pre style={{
            background: 'var(--bg-elev-2)', padding: '10px 12px', borderRadius: 8,
            fontSize: 12, overflowX: 'auto', maxHeight: 160, whiteSpace: 'pre-wrap'
          }}>{JSON.stringify(p.args, null, 2)}</pre>
          <div className="hint" style={{ marginBottom: 14 }}>
            {p.name === 'execute_code'
              ? 'This runs the snippet in a temporary scratch folder outside your workspace, then discards it — it cannot touch your project files directly.'
              : 'This will execute inside your open workspace folder only. Nothing runs outside it.'}
          </div>
          <div style={{ display: 'flex', gap: 8, justifyContent: 'flex-end' }}>
            <button className="ghost" onClick={() => store.resolveApproval(false)}>Deny</button>
            <button className="primary" onClick={() => store.resolveApproval(true)}>Approve &amp; Run</button>
          </div>
        </div>
      </div>
    </div>
  );
}
