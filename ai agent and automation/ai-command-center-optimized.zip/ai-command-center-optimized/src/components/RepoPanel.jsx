import React, { useState } from 'react';

export default function RepoPanel({ store }) {
  const [indexing, setIndexing] = useState(false);
  const [indexInfo, setIndexInfo] = useState(null);
  const [symbolQuery, setSymbolQuery] = useState('');
  const [symbolResults, setSymbolResults] = useState(null);
  const [grepPattern, setGrepPattern] = useState('');
  const [grepResults, setGrepResults] = useState(null);
  const [depPath, setDepPath] = useState('');
  const [depResult, setDepResult] = useState(null);
  const [tests, setTests] = useState(null);
  const [busy, setBusy] = useState('');

  const runIndex = async () => {
    setIndexing(true);
    const res = await window.bridge.repo.index();
    setIndexing(false);
    if (res.ok) {
      setIndexInfo(res.result);
      store.pushActivity(`Repository indexed: ${res.result.fileCount} file(s), ${res.result.totalSymbols} symbol(s).`, 'security');
    } else {
      store.pushActivity(`Repository indexing failed: ${res.result}`, 'security');
    }
  };

  const runSymbolSearch = async () => {
    if (!symbolQuery.trim()) return;
    setBusy('symbols');
    const res = await window.bridge.repo.symbols(symbolQuery);
    setBusy('');
    setSymbolResults(res.ok ? res.result.matches : []);
  };

  const runGrep = async () => {
    if (!grepPattern.trim()) return;
    setBusy('grep');
    const res = await window.bridge.repo.search(grepPattern, false);
    setBusy('');
    setGrepResults(res.ok ? res.result : { matches: [], error: res.result });
  };

  const runDeps = async () => {
    setBusy('deps');
    const res = await window.bridge.repo.dependencies(depPath.trim() || undefined);
    setBusy('');
    setDepResult(res.ok ? res.result : { error: res.result });
  };

  const runTests = async () => {
    setBusy('tests');
    const res = await window.bridge.repo.tests();
    setBusy('');
    setTests(res.ok ? res.result : { tests: [], error: res.result });
  };

  const inputStyle = { flex: 1, background: 'var(--bg-elev-2)', border: '1px solid var(--border)', borderRadius: 8, padding: '7px 10px', color: 'var(--text)' };

  return (
    <div className="settings-panel" style={{ maxWidth: 800 }}>
      <h2 style={{ marginTop: 0 }}>Repository</h2>
      <p className="hint">
        Symbol search, import/dependency graph, exact search, and test discovery — all
        local. Symbol/import extraction is regex-based (JS/TS/Python), not a full AST
        parser, so unusual syntax may be missed; treat it as a fast, honest approximation.
      </p>

      <div className="provider-card">
        <div className="row">
          <strong>Repository index</strong>
          <button className="ghost" disabled={indexing || !store.workspaceRoot} onClick={runIndex}>
            {indexing ? 'Indexing…' : 'Build / Refresh Index'}
          </button>
        </div>
        {!store.workspaceRoot && <div className="hint">Open a workspace folder first (Files tab).</div>}
        {indexInfo && (
          <div className="hint">{indexInfo.fileCount} file(s), {indexInfo.totalSymbols} symbol(s) indexed.</div>
        )}
      </div>

      <div className="provider-card">
        <div className="row"><strong>Symbol search</strong></div>
        <div className="row" style={{ marginTop: 10, gap: 8 }}>
          <input style={inputStyle} placeholder="e.g. handleSubmit" value={symbolQuery}
            onChange={e => setSymbolQuery(e.target.value)} onKeyDown={e => e.key === 'Enter' && runSymbolSearch()} />
          <button className="ghost" disabled={busy === 'symbols'} onClick={runSymbolSearch}>Search</button>
        </div>
        {symbolResults && symbolResults.length === 0 && <div className="hint">No matches.</div>}
        {symbolResults && symbolResults.map((m, i) => (
          <div key={i} className="activity-item"><strong>{m.name}</strong> ({m.type}) — {m.file}:{m.line}</div>
        ))}
      </div>

      <div className="provider-card">
        <div className="row"><strong>Exact search (grep)</strong></div>
        <div className="row" style={{ marginTop: 10, gap: 8 }}>
          <input style={inputStyle} placeholder="regex pattern, e.g. TODO|FIXME" value={grepPattern}
            onChange={e => setGrepPattern(e.target.value)} onKeyDown={e => e.key === 'Enter' && runGrep()} />
          <button className="ghost" disabled={busy === 'grep'} onClick={runGrep}>Search</button>
        </div>
        {grepResults?.error && <div className="hint">⚠️ {grepResults.error}</div>}
        {grepResults?.matches?.length === 0 && <div className="hint">No matches.</div>}
        {grepResults?.matches?.slice(0, 30).map((m, i) => (
          <div key={i} className="activity-item">{m.file}:{m.line} — <code>{m.text}</code></div>
        ))}
        {grepResults?.truncated && <div className="hint">Results truncated at 300 matches.</div>}
      </div>

      <div className="provider-card">
        <div className="row"><strong>Dependency graph</strong></div>
        <div className="row" style={{ marginTop: 10, gap: 8 }}>
          <input style={inputStyle} placeholder="Leave empty for project-wide summary, or e.g. src/App.jsx" value={depPath}
            onChange={e => setDepPath(e.target.value)} onKeyDown={e => e.key === 'Enter' && runDeps()} />
          <button className="ghost" disabled={busy === 'deps'} onClick={runDeps}>Show</button>
        </div>
        {depResult?.error && <div className="hint">⚠️ {depResult.error}</div>}
        {depResult?.note && <div className="hint">{depResult.note}</div>}
        {depResult?.dependsOn && (
          <>
            <div className="hint" style={{ marginTop: 8 }}><strong>Depends on:</strong></div>
            {depResult.dependsOn.map((d, i) => <div key={i} className="activity-item">{d}</div>)}
            <div className="hint" style={{ marginTop: 8 }}><strong>Depended on by:</strong></div>
            {depResult.dependedOnBy.length === 0 && <div className="hint">Nothing in the index imports this file.</div>}
            {depResult.dependedOnBy.map((d, i) => <div key={i} className="activity-item">{d}</div>)}
          </>
        )}
        {depResult?.mostDependedOn && (
          <>
            <div className="hint" style={{ marginTop: 8 }}>Most depended-on files (project-wide):</div>
            {depResult.mostDependedOn.map((d, i) => (
              <div key={i} className="activity-item">{d.file} — {d.incomingEdges} incoming import(s)</div>
            ))}
          </>
        )}
      </div>

      <div className="provider-card">
        <div className="row">
          <strong>Test discovery</strong>
          <button className="ghost" disabled={busy === 'tests'} onClick={runTests}>Find Tests</button>
        </div>
        {tests?.error && <div className="hint">⚠️ {tests.error}</div>}
        {tests?.note && <div className="hint">{tests.note}</div>}
        {tests?.tests?.length === 0 && !tests?.note && <div className="hint">No test files matched common naming patterns.</div>}
        {tests?.tests?.map((t, i) => <div key={i} className="activity-item">{t}</div>)}
      </div>

      <p className="hint">
        Agents with the "repo" permission tag (Full Stack Developer, QA Tester) can call
        these automatically as tools in chat, with the same results shown here.
      </p>
    </div>
  );
}
