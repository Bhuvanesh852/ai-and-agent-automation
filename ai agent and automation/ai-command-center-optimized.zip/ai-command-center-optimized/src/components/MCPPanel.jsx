import React, { useEffect, useState } from 'react';

const PRESETS = [
  { name: 'Filesystem (npx)', command: 'npx', args: ['-y', '@modelcontextprotocol/server-filesystem', '.'] },
  { name: 'This app, as its own MCP server', command: 'node', args: ['electron/mcpServer.js'] }
];

export default function MCPPanel({ store }) {
  const [servers, setServers] = useState([]);
  const [form, setForm] = useState({ name: '', command: '', args: '' });
  const [testTool, setTestTool] = useState({}); // connId -> { toolName, args, result }
  const [busy, setBusy] = useState(false);

  const refresh = async () => {
    if (!window.bridge?.mcp) return;
    const status = await window.bridge.mcp.status();
    setServers(status || []);
  };

  useEffect(() => { refresh(); }, []);

  const connect = async (preset) => {
    if (!window.bridge?.mcp) return;
    setBusy(true);
    const id = crypto.randomUUID();
    const cfg = preset || { name: form.name || form.command, command: form.command, args: form.args.split(' ').filter(Boolean) };
    const res = await window.bridge.mcp.connect({ id, name: cfg.name, command: cfg.command, args: cfg.args });
    store.pushActivity(
      res.ok ? `MCP: connected to "${cfg.name}" (${res.tools.length} tools)` : `MCP: failed to connect to "${cfg.name}" — ${res.error}`,
      'general'
    );
    setForm({ name: '', command: '', args: '' });
    setBusy(false);
    await refresh();
  };

  const disconnect = async (id) => {
    await window.bridge.mcp.disconnect(id);
    await refresh();
  };

  const runTool = async (connId, toolName) => {
    const args = testTool[connId]?.argsJson || '{}';
    let parsed = {};
    try { parsed = JSON.parse(args); } catch { /* leave empty on bad JSON */ }
    const res = await window.bridge.mcp.callTool(connId, toolName, parsed);
    setTestTool(t => ({ ...t, [connId]: { ...t[connId], result: res.ok ? res.content : `⚠️ ${res.error}` } }));
  };

  return (
    <div className="settings-panel">
      <h2 style={{ marginTop: 0 }}>MCP Connections</h2>
      <p className="hint">
        Connect this app to external MCP (Model Context Protocol) servers as a client, so agents here can use their tools.
        This app also runs as its own MCP server (<code>node electron/mcpServer.js</code>) — point Claude Desktop or another
        MCP host at it to use this app's tools from outside. Every connection here spawns a real local process over
        stdio — only connect to servers you trust, the same as installing a plugin.
      </p>

      <div className="row" style={{ gap: 8, marginBottom: 8, flexWrap: 'wrap' }}>
        {PRESETS.map(p => (
          <button key={p.name} className="ghost" disabled={busy} onClick={() => connect(p)}>+ {p.name}</button>
        ))}
      </div>

      <div className="row" style={{ gap: 8, marginBottom: 20, flexWrap: 'wrap' }}>
        <input placeholder="Name" value={form.name} onChange={e => setForm(f => ({ ...f, name: e.target.value }))} />
        <input placeholder="Command (e.g. npx, node, python)" value={form.command} onChange={e => setForm(f => ({ ...f, command: e.target.value }))} />
        <input placeholder="Args (space-separated)" value={form.args} onChange={e => setForm(f => ({ ...f, args: e.target.value }))} style={{ minWidth: 260 }} />
        <button className="primary" disabled={busy || !form.command} onClick={() => connect(null)}>Connect</button>
      </div>

      {servers.length === 0 && <p className="hint">No MCP servers connected yet.</p>}

      {servers.map(s => (
        <div key={s.id} className="project-card" style={{ marginBottom: 12 }}>
          <div className="row" style={{ justifyContent: 'space-between' }}>
            <h3 style={{ margin: 0 }}>{s.name} <span className="hint">({s.status})</span></h3>
            <button className="ghost danger" onClick={() => disconnect(s.id)}>Disconnect</button>
          </div>
          <div className="hint">{s.command} {(s.args || []).join(' ')}</div>
          {s.lastError && <div style={{ color: 'var(--danger)' }}>⚠️ {s.lastError}</div>}
          {s.tools?.length > 0 && (
            <div style={{ marginTop: 10 }}>
              <strong>Tools:</strong>
              <ul>
                {s.tools.map(t => (
                  <li key={t.name} style={{ marginBottom: 8 }}>
                    <code>{t.name}</code> — <span className="hint">{t.description}</span>
                    <div className="row" style={{ gap: 6, marginTop: 4 }}>
                      <input
                        placeholder='args as JSON, e.g. {"path":"."}'
                        style={{ flex: 1 }}
                        value={testTool[s.id]?.argsJson || ''}
                        onChange={e => setTestTool(prev => ({ ...prev, [s.id]: { ...prev[s.id], argsJson: e.target.value } }))}
                      />
                      <button className="ghost" onClick={() => runTool(s.id, t.name)}>Run</button>
                    </div>
                  </li>
                ))}
              </ul>
              {testTool[s.id]?.result && (
                <pre style={{ whiteSpace: 'pre-wrap', maxHeight: 200, overflow: 'auto' }}>{testTool[s.id].result}</pre>
              )}
            </div>
          )}
        </div>
      ))}
    </div>
  );
}
