import React, { useEffect, useState } from 'react';

export default function LocalApiPanel({ store }) {
  const [status, setStatus] = useState({ running: false, port: null });
  const [token, setToken] = useState('');
  const [showToken, setShowToken] = useState(false);
  const [port, setPort] = useState(8788);
  const [lan, setLan] = useState(false);
  const [busy, setBusy] = useState(false);

  const refresh = async () => {
    if (!window.bridge?.localApi) return;
    const [s, t] = await Promise.all([window.bridge.localApi.status(), window.bridge.localApi.getToken()]);
    setStatus(s);
    setToken(t);
    if (s.port) setPort(s.port);
  };

  useEffect(() => { refresh(); }, []);

  const toggle = async () => {
    setBusy(true);
    if (status.running) {
      await window.bridge.localApi.stop();
      store.pushActivity('Local API server stopped.', 'security');
    } else {
      const res = await window.bridge.localApi.start(Number(port), lan);
      if (!res.ok) {
        store.pushActivity(`Local API server failed to start: ${res.error}`, 'security');
      } else {
        store.pushActivity(`Local API server started on 127.0.0.1:${res.port}.`, 'security');
      }
    }
    setBusy(false);
    refresh();
  };

  const regenerate = async () => {
    const t = await window.bridge.localApi.regenerateToken();
    setToken(t);
    store.pushActivity('Local API token regenerated — update any client using the old one.', 'security');
  };

  const curlExample = `curl http://127.0.0.1:${status.port || port}/v1/chat/completions \\
  -H "Authorization: Bearer ${showToken ? token : '••••••••'}" \\
  -H "Content-Type: application/json" \\
  -d '{"model": "ollama:llama3.2:3b", "messages": [{"role":"user","content":"Hello"}]}'`;

  return (
    <div className="settings-panel" style={{ maxWidth: 760 }}>
      <h2 style={{ marginTop: 0 }}>Local API</h2>
      <p className="hint">
        An OpenAI-compatible <code>/v1/chat/completions</code> endpoint for local tools
        (curl, editor extensions, scripts) on this machine — not a public server.
      </p>

      <div className="provider-card">
        <div className="row">
          <strong>{status.running ? `Running on 127.0.0.1:${status.port}` : 'Stopped'}</strong>
          <span className={`status-chip ${status.running ? 'configured' : 'missing'}`}>
            {status.running ? 'ON' : 'OFF'}
          </span>
        </div>
        <div className="row" style={{ marginTop: 10, gap: 8 }}>
          <input
            type="number"
            disabled={status.running}
            value={port}
            onChange={e => setPort(e.target.value)}
            style={{ width: 100, background: 'var(--bg-elev-2)', border: '1px solid var(--border)', borderRadius: 8, padding: '7px 10px', color: 'var(--text)' }}
          />
          <button className={status.running ? 'ghost' : 'primary'} disabled={busy} onClick={toggle}>
            {busy ? 'Working…' : status.running ? 'Stop Server' : 'Start Server'}
          </button>
        </div>
        <div className="row" style={{ marginTop: 10, gap: 8 }}>
          <label className="hint" style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
            <input type="checkbox" disabled={status.running} checked={lan} onChange={e => setLan(e.target.checked)} />
            Allow LAN access (advanced)
          </label>
        </div>
        {lan && (
          <div className="hint" style={{ color: 'var(--warn)' }}>
            ⚠️ Binds to 0.0.0.0 — other devices on your network can reach this endpoint.
            The bearer token is still required, but only enable this on a network you trust.
          </div>
        )}
        <div className="hint">
          Off: binds to <code>127.0.0.1</code> only, unreachable from your network regardless
          of firewall settings.
        </div>
      </div>

      <div className="provider-card">
        <div className="row"><strong>Streaming</strong></div>
        <div className="hint">
          Groq/OpenRouter: real upstream SSE piped straight through. Ollama and local GGUF:
          real token-by-token streaming via their native APIs. Gemini: not natively
          streamed by this server — <code>stream: true</code> still returns its answer as
          one chunk for that provider only.
        </div>
      </div>

      <div className="provider-card">
        <div className="row">
          <strong>Bearer token</strong>
          <button className="ghost" onClick={() => setShowToken(s => !s)}>{showToken ? 'Hide' : 'Show'}</button>
        </div>
        <div className="hint" style={{ fontFamily: 'monospace', wordBreak: 'break-all' }}>
          {showToken ? token : '•'.repeat(48)}
        </div>
        <div className="row" style={{ marginTop: 10 }}>
          <button className="ghost" onClick={regenerate}>Regenerate Token</button>
        </div>
        <div className="hint">
          Every request needs this as <code>Authorization: Bearer &lt;token&gt;</code> — without it,
          any other process on your machine could otherwise call into your configured provider keys
          through this server.
        </div>
      </div>

      <div className="provider-card">
        <div className="row"><strong>Try it</strong></div>
        <pre style={{ whiteSpace: 'pre-wrap', fontSize: 12, background: 'var(--bg-elev-2)', padding: 10, borderRadius: 8, marginTop: 8 }}>{curlExample}</pre>
        <div className="hint">
          Model IDs: <code>groq:llama-3.3-70b-versatile</code>, <code>gemini:gemini-2.0-flash</code>,{' '}
          <code>openrouter:meta-llama/llama-3.1-8b-instruct:free</code>, <code>ollama:&lt;model name&gt;</code>,{' '}
          <code>local:&lt;absolute .gguf path&gt;</code> (see Models tab for exact paths). Cloud models
          still need their key configured in Settings; Lockdown Mode blocks them here too.
        </div>
      </div>

      <div className="provider-card">
        <div className="row"><strong>Honest limitations</strong></div>
        <div className="hint">
          This endpoint returns plain chat completions only — it does not expose the agent
          tool-calling loop (file/terminal/git/RAG), so responses here never touch your
          filesystem or run commands.
        </div>
      </div>
    </div>
  );
}
