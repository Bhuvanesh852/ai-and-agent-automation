import React, { useEffect, useState } from 'react';

export default function RagPanel({ store }) {
  const [status, setStatus] = useState(null);
  const [ingesting, setIngesting] = useState(false);
  const [question, setQuestion] = useState('');
  const [matches, setMatches] = useState(null);
  const [note, setNote] = useState('');
  const [querying, setQuerying] = useState(false);

  const refreshStatus = async () => {
    if (!window.bridge?.rag) return;
    const res = await window.bridge.rag.status();
    if (res.ok) setStatus(res.result);
  };

  useEffect(() => { refreshStatus(); }, [store.workspaceRoot]);

  const ingestAll = async () => {
    setIngesting(true);
    const res = await window.bridge.rag.ingest('.');
    setIngesting(false);
    if (res.ok) {
      store.pushActivity(`RAG: indexed ${res.result.filesIndexed} file(s), ${res.result.chunksAdded} chunk(s).`, 'security');
      refreshStatus();
    } else {
      store.pushActivity(`RAG ingest failed: ${res.result}`, 'security');
    }
  };

  const clearIndex = async () => {
    await window.bridge.rag.clear();
    store.pushActivity('RAG: index cleared for this workspace.', 'security');
    refreshStatus();
  };

  const runQuery = async () => {
    if (!question.trim()) return;
    setQuerying(true);
    const res = await window.bridge.rag.query(question, 5);
    setQuerying(false);
    if (res.ok) {
      setMatches(res.result.matches);
      setNote(res.result.note || '');
    } else {
      setMatches([]);
      setNote(String(res.result));
    }
  };

  return (
    <div className="settings-panel" style={{ maxWidth: 760 }}>
      <h2 style={{ marginTop: 0 }}>RAG Knowledge</h2>
      <p className="hint">
        Local retrieval over your workspace's own text files — no cloud embeddings API.
        This uses TF-IDF keyword-weighted matching, not neural embeddings: great for
        finding chunks that share vocabulary with your question, but it won't catch a
        pure paraphrase with no shared words. That trade-off is intentional — it's fully
        local and needs no extra model.
      </p>

      <div className="provider-card">
        <div className="row">
          <strong>Index status</strong>
          <button className="ghost" onClick={refreshStatus}>Refresh</button>
        </div>
        {!store.workspaceRoot && <div className="hint">Open a workspace folder first (Files tab).</div>}
        {status && (
          <div className="hint">
            {status.totalChunks} chunk(s) indexed across {status.files.length} file(s).
          </div>
        )}
        <div className="row" style={{ marginTop: 10, gap: 8 }}>
          <button className="ghost" disabled={ingesting || !store.workspaceRoot} onClick={ingestAll}>
            {ingesting ? 'Indexing…' : 'Index Workspace'}
          </button>
          <button className="ghost" disabled={!store.workspaceRoot} onClick={clearIndex}>Clear Index</button>
        </div>
        <div className="hint">
          Indexes text-based files (.md, .txt, .js, .py, .json, etc.) up to 1.5MB each,
          skipping node_modules/.git/dist. Re-indexing a file replaces its old chunks.
        </div>
      </div>

      <div className="provider-card">
        <div className="row"><strong>Ask a question</strong></div>
        <div className="row" style={{ marginTop: 10, gap: 8 }}>
          <input
            type="text"
            style={{ flex: 1, background: 'var(--bg-elev-2)', border: '1px solid var(--border)', borderRadius: 8, padding: '7px 10px', color: 'var(--text)' }}
            placeholder="What does this project's README say about setup?"
            value={question}
            onChange={e => setQuestion(e.target.value)}
            onKeyDown={e => e.key === 'Enter' && runQuery()}
          />
          <button className="ghost" disabled={querying} onClick={runQuery}>{querying ? 'Searching…' : 'Search'}</button>
        </div>
        {note && <div className="hint" style={{ marginTop: 8 }}>{note}</div>}
      </div>

      {matches && matches.length > 0 && (
        <div className="provider-card">
          <div className="row"><strong>Matches</strong></div>
          {matches.map((m, i) => (
            <div key={i} className="activity-item">
              <strong>{m.file}</strong> (chunk {m.chunkIndex}, score {m.score})
              <div style={{ marginTop: 4, whiteSpace: 'pre-wrap' }}>{m.text}</div>
            </div>
          ))}
        </div>
      )}

      <p className="hint">
        Agents with the "rag" permission tag (currently the Generative AI Engineer) can
        call this automatically as <code>rag_ingest</code> / <code>rag_query</code> tools
        in chat, with the same citations shown here.
      </p>
    </div>
  );
}
