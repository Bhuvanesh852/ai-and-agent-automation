import React from 'react';

export default function ContextPanel({ store }) {
  return (
    <div className="side-panel">
      <h4>Workspace</h4>
      <div className="hint">
        {store.workspaceRoot
          ? store.workspaceRoot
          : 'No folder open — agents can chat but can\'t read/write files or run commands. Open one from the Files tab or ⌘K.'}
      </div>

      <h4>Hardware Profile</h4>
      {store.hardwareProfile ? (
        <div className="hint">
          {store.hardwareProfile.platform} · {store.hardwareProfile.cpuCores} cores<br />
          {store.hardwareProfile.totalRamGB} GB RAM total<br />
          Mode: {store.hardwareProfile.recommendedMode}
        </div>
      ) : <div className="hint">Detecting…</div>}

      <h4>Activity Timeline</h4>
      {store.activity.length === 0 && <div className="hint">No activity yet.</div>}
      {[...store.activity].reverse().map(a => (
        <div key={a.id} className="activity-item">{a.text}</div>
      ))}
    </div>
  );
}
