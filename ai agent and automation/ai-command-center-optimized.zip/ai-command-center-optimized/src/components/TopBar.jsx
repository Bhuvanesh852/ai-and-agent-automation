import React from 'react';
import { getAgent } from '../agents/agents.js';
import { agentHasTools, providerSupportsTools } from '../agents/AgentRuntime.js';

export default function TopBar({ store, onOpenPalette }) {
  const agent = getAgent(store.activeAgentId);
  const secured = Object.keys(store.providerStatus || {}).length > 0 || store.activeProvider === 'demo' || store.activeProvider === 'ollama';
  const toolsLive = providerSupportsTools(store.activeProvider) && agentHasTools(agent);
  const toolsWanted = agentHasTools(agent);

  return (
    <div className="topbar">
      <span className="badge">
        <span className={`dot ${secured ? 'ok' : 'warn'}`} />
        {store.activeProvider === 'demo' ? 'Demo mode' : 'Live'}
      </span>
      <span className="badge">{agent.icon} {agent.name}</span>
      <span className="badge">🧩 {store.activeProvider}/{store.activeProvider === 'local-native' ? store.activeModelId.split(/[\\/]/).pop() : store.activeModelId}</span>
      {toolsWanted && (
        <span className="badge" title={toolsLive ? 'Agent can call tools (file/terminal/web) with approval for risky actions.' : 'Pick a tool-capable model (Groq, OpenRouter, or Ollama) to enable tools for this agent.'}>
          <span className={`dot ${toolsLive ? 'ok' : 'warn'}`} />
          {toolsLive ? 'Tools live' : 'Tools inactive'}
        </span>
      )}
      {store.workspaceRoot && (
        <span className="badge" title={store.workspaceRoot}>📁 {store.workspaceRoot.split(/[\\/]/).pop()}</span>
      )}
      {store.lowResourceMode && <span className="badge">🐢 Low-resource mode</span>}
      {store.lockdownMode && (
        <span className="badge" style={{ color: 'var(--warn)', borderColor: 'var(--warn)' }}>🔒 Lockdown</span>
      )}
      {store.stopAllActive && (
        <span className="badge" style={{ color: 'var(--danger)', borderColor: 'var(--danger)' }}>🛑 Stopped</span>
      )}
      <span style={{ marginLeft: 'auto' }} />
      <button className="ghost" onClick={onOpenPalette}>⌘K Command Palette</button>
    </div>
  );
}
