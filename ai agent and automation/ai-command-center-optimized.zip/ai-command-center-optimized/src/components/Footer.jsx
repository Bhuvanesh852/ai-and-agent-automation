import React from 'react';
import pkg from '../../package.json';

// Section 9 of the UI spec. Hidden on mobile via CSS (.app-footer media
// query in global.css), matching Section 10's "Footer hidden on mobile".
export default function Footer() {
  return (
    <footer className="app-footer">
      <nav className="app-footer-links">
        <a href="#" onClick={e => e.preventDefault()}>About</a>
        <a href="#" onClick={e => e.preventDefault()}>Privacy Policy</a>
        <a href="#" onClick={e => e.preventDefault()}>Terms of Service</a>
        <a href="#" onClick={e => e.preventDefault()}>Contact</a>
      </nav>
      <div className="app-footer-social" aria-label="Social links">
        <span title="Twitter">𝕏</span>
        <span title="LinkedIn">in</span>
        <span title="GitHub">⌥</span>
      </div>
      <div className="app-footer-version">v{pkg.version}</div>
    </footer>
  );
}
