import React from 'react';

// Section 5 of the UI spec: "Advanced Toggles". Every control here reads
// from and writes to real store state consumed by the gateway/agent runtime
// (see useAppStore.js) — none of these are cosmetic-only switches.
export default function AdvancedTogglesRow({ store }) {
  return (
    <div className="toggles-row" role="group" aria-label="Advanced generation settings">
      <label className="toggle-select" title="Fast = short single pass. Balanced = default. Deep = the agent is asked to reason step by step before answering.">
        <span>Reasoning</span>
        <select
          aria-label="Reasoning mode"
          value={store.reasoningMode}
          onChange={e => store.setReasoningMode(e.target.value)}
        >
          <option value="fast">Fast</option>
          <option value="balanced">Balanced</option>
          <option value="deep">Deep</option>
        </select>
      </label>

      <label className="toggle-select" title="Maps to sampling temperature sent to the active model.">
        <span>Creativity</span>
        <select
          aria-label="Creativity mode"
          value={store.creativityMode}
          onChange={e => store.setCreativityMode(e.target.value)}
        >
          <option value="low">Low</option>
          <option value="medium">Medium</option>
          <option value="high">High</option>
        </select>
      </label>

      <button
        type="button"
        className={`switch-pill ${store.safetyFilterOn ? 'on' : ''}`}
        role="switch"
        aria-checked={store.safetyFilterOn}
        title="When on, the agent's system prompt includes an explicit content-safety preamble."
        onClick={store.toggleSafetyFilter}
      >
        🛡️ Safety Filter: {store.safetyFilterOn ? 'On' : 'Off'}
      </button>

      <button
        type="button"
        className={`switch-pill ${store.debugMode ? 'on' : ''}`}
        role="switch"
        aria-checked={store.debugMode}
        title="Shows raw provider/tool payloads in the Activity log for troubleshooting."
        onClick={store.toggleDebugMode}
      >
        🐞 Debug: {store.debugMode ? 'On' : 'Off'}
      </button>

      <label className="toggle-select" title="Hybrid fans your message out to two enabled models and shows both replies side by side.">
        <span>Model Merge</span>
        <select
          aria-label="Model merge mode"
          value={store.modelMerge}
          onChange={e => store.setModelMerge(e.target.value)}
        >
          <option value="single">Single</option>
          <option value="hybrid">Hybrid</option>
        </select>
      </label>
    </div>
  );
}
