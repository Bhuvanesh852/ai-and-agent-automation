import React, { useEffect, useState } from 'react';

export default function FilesPanel({ store }) {
  const [entries, setEntries] = useState(null);
  const [error, setError] = useState(null);

  const refresh = async () => {
    if (!store.workspaceRoot) { setEntries(null); return; }
    const res = await window.bridge.tools.execute('list_dir', { path: '.' });
    if (res.ok) { setEntries(res.result); setError(null); }
    else { setError(res.result); setEntries(null); }
  };

  useEffect(() => { refresh(); }, [store.workspaceRoot]);

  const openFolder = async () => {
    await store.selectWorkspace();
  };

  return (
    <div className="settings-panel">
      <h2 style={{ marginTop: 0 }}>Files</h2>
      <p className="hint">
        This is the sandbox root agents can read from and (with your approval) write to or run
        commands in. Nothing outside this folder is ever touched.
      </p>

      <div className="provider-card">
        <div className="row">
          <strong>{store.workspaceRoot ? 'Open workspace' : 'No workspace open'}</strong>
          <button className="ghost" onClick={openFolder}>
            {store.workspaceRoot ? 'Change Folder…' : 'Open Folder…'}
          </button>
        </div>
        {store.workspaceRoot && <div className="hint">{store.workspaceRoot}</div>}
      </div>

      {store.workspaceRoot && (
        <div className="provider-card">
          <div className="row"><strong>Contents</strong><button className="ghost" onClick={refresh}>Refresh</button></div>
          {error && <div className="hint">⚠️ {error}</div>}
          {entries && entries.length === 0 && <div className="hint">Empty folder.</div>}
          {entries && entries.map(e => (
            <div key={e.name} className="activity-item">{e.type === 'dir' ? '📁' : '📄'} {e.name}</div>
          ))}
        </div>
      )}
    </div>
  );
}
