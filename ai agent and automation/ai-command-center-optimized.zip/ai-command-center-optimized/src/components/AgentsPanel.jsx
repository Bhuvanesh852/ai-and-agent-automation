import React, { useState } from 'react';
import { AGENTS } from '../agents/agents.js';
import { toolsForAgent } from '../agents/tools.js';
import { providerSupportsTools } from '../agents/AgentRuntime.js';
import { REGISTRY } from '../gateway/registry.js';

// Replaces the old "this module is scaffolded" placeholder. The useful thing
// an agents screen can do is make each agent's REAL capabilities legible:
// what it can touch, what its declared permission profile claims, and whether
// those two agree. A mismatch there is exactly the class of bug the repo's
// own comments record having found twice before.
export default function AgentsPanel({ store }) {
  const [openId, setOpenId] = useState(AGENTS[0]?.id || null);

  return (
    <div className="settings-panel agents-panel">
      <h2 style={{ marginTop: 0 }}>🤖 Agents</h2>
      <p className="hint">
        Each agent is a persona plus a least-privilege tool set. Selecting one here switches the chat to it and to
        its preferred model.
      </p>

      {AGENTS.map(agent => {
        const tools = toolsForAgent(agent);
        const open = openId === agent.id;
        const active = store.activeAgentId === agent.id;
        const model = REGISTRY.find(
          m => m.provider === agent.defaultModelPreference.provider && m.model_id === agent.defaultModelPreference.model_id
        );
        const providerReady =
          ['offline', 'ollama', 'local-native', 'demo'].includes(agent.defaultModelPreference.provider) ||
          store.providerStatus?.[agent.defaultModelPreference.provider] === true;
        const toolsWork = providerSupportsTools(agent.defaultModelPreference.provider);
        const audit = auditAgent(agent, tools);

        return (
          <div key={agent.id} className={`agent-card ${active ? 'active' : ''}`}>
            <div className="agent-head" onClick={() => setOpenId(open ? null : agent.id)}>
              <span className="agent-icon">{agent.icon}</span>
              <div>
                <div className="agent-name">
                  {agent.name}
                  {active && <span className="badge sched">active</span>}
                </div>
                <div className="hint small">
                  {tools.length} tools · prefers {model?.display_name || agent.defaultModelPreference.model_id}
                  {!providerReady && <span className="warn-text"> · provider not configured</span>}
                  {providerReady && !toolsWork && <span className="warn-text"> · this provider can't call tools</span>}
                </div>
              </div>
              <button
                className="ghost"
                onClick={e => { e.stopPropagation(); store.setActiveAgent(agent.id); }}
              >
                Use
              </button>
            </div>

            {open && (
              <div className="agent-detail">
                <h4>System prompt</h4>
                <pre className="agent-prompt">{agent.systemPrompt}</pre>

                <h4>Tools it can actually call</h4>
                <div className="tool-chips">
                  {tools.length === 0 && <span className="hint">None — this agent is chat-only.</span>}
                  {tools.map(t => (
                    <span key={t.name} className={`chip ${t.riskLevel === 'risky' ? 'risky' : ''}`} title={t.description}>
                      {t.name}{t.riskLevel === 'risky' ? ' ⚠' : ''}
                    </span>
                  ))}
                </div>

                <h4>Declared permissions</h4>
                <div className="perm-grid">
                  {Object.entries(agent.permissionProfile).map(([k, v]) => (
                    <div key={k} className={`perm ${v === true ? 'yes' : v === false ? 'no' : 'gated'}`}>
                      <span>{k}</span>
                      <b>{v === true ? 'allowed' : v === false ? 'denied' : String(v)}</b>
                    </div>
                  ))}
                </div>

                <h4>Capability audit</h4>
                {audit.length === 0 ? (
                  <p className="ok-text">✓ Declared permissions and actual tool access agree.</p>
                ) : (
                  audit.map((a, i) => <p key={i} className="err-text">⚠ {a}</p>)
                )}
              </div>
            )}
          </div>
        );
      })}

      <p className="hint" style={{ marginTop: 24 }}>
        Custom agents aren't editable from this screen yet — add one to <code>src/agents/agents.js</code> and it
        appears here, in the chat picker, and in the Automations agent node automatically.
      </p>
    </div>
  );
}

/**
 * Cross-check what an agent's permissionProfile claims against the tools it
 * actually resolves to. This is the check that would have caught CyberShield
 * silently holding git_commit while declaring itself read-only.
 */
function auditAgent(agent, tools) {
  const names = new Set(tools.map(t => t.name));
  const problems = [];
  const p = agent.permissionProfile;

  if (p.writeFiles === false && names.has('write_file')) problems.push('Declares writeFiles: false but has write_file.');
  if (p.executeCommands === false && (names.has('run_terminal') || names.has('run_tests') || names.has('execute_code'))) {
    problems.push('Declares executeCommands: false but has a command/code-executing tool.');
  }
  if (p.gitOperations === 'read-only' && names.has('git_commit')) problems.push('Declares git read-only but has git_commit.');
  if (p.gitOperations === false && (names.has('git_status') || names.has('git_commit'))) {
    problems.push('Declares no git access but has a git tool.');
  }
  if (p.networkAccess === false && (names.has('web_search') || names.has('deep_research') || names.has('read_url') || names.has('http_request') || names.has('generate_image'))) {
    problems.push('Declares networkAccess: false but has a network tool.');
  }
  if (p.networkAccess === true && names.has('http_request') && p.credentialManagement === false) {
    // Not a contradiction, but worth surfacing: http_request is the one tool
    // that can post workspace contents to a third party.
    problems.push('Has http_request — it can send workspace data to arbitrary hosts (approval-gated, but review its use).');
  }
  return problems;
}
