import React, { useState } from 'react';
import { runCouncil } from '../ensemble/council.js';
import { councilCandidates } from '../gateway/registry.js';

export default function CouncilPanel({ store }) {
  const [question, setQuestion] = useState('');
  const [members, setMembers] = useState(3);
  const [busy, setBusy] = useState(false);
  const [phase, setPhase] = useState(null);
  const [result, setResult] = useState(null);
  const [showPanel, setShowPanel] = useState(false);

  const available = councilCandidates(store.providerStatus, members);

  const ask = async () => {
    if (!question.trim() || busy) return;
    setBusy(true);
    setResult(null);
    setPhase('Polling the panel…');
    try {
      const res = await runCouncil({
        prompt: question,
        members,
        providerStatus: store.providerStatus,
        hints: {
          reasoningMode: store.reasoningMode,
          creativityMode: store.creativityMode,
          safetyFilterOn: store.safetyFilterOn
        },
        onProgress: p => setPhase(p.phase === 'synthesising' ? 'Synthesising the answers…' : 'Polling the panel…')
      });
      setResult(res);
      store.pushActivity(`Council run: ${res.ok ? `${res.panelSize || 1} models` : 'failed'}`, 'council');
    } catch (err) {
      setResult({ ok: false, error: String(err?.message || err) });
    } finally {
      setBusy(false);
      setPhase(null);
    }
  };

  return (
    <div className="settings-panel council">
      <h2 style={{ marginTop: 0 }}>⚖️ AI Council</h2>
      <p className="hint">
        Asks several different free models the same question in parallel, then has one of them write a single answer
        that says where the panel disagreed. Different model families fail differently, so agreement is a real signal
        and disagreement tells you which part of the answer to check.
      </p>
      <p className="hint warn">
        This raises the floor and surfaces uncertainty. It is not a smarter model — three models can agree and still
        be wrong together, so the synthesis is written to report splits rather than hide them.
      </p>

      <div className="council-config">
        <label className="field">
          <span>Panel size</span>
          <select value={members} onChange={e => setMembers(Number(e.target.value))}>
            {[2, 3, 4, 5].map(n => <option key={n} value={n}>{n} models</option>)}
          </select>
        </label>
        <div className="panel-preview">
          <span className="hint">Panel for this run:</span>
          {available.length < 2 ? (
            <span className="err-text">
              Only {available.length} provider available. Add a second free key in Settings, or install Ollama.
            </span>
          ) : (
            available.map(m => <span key={m.provider + m.model_id} className="badge">{m.display_name}</span>)
          )}
        </div>
      </div>

      <textarea
        rows={4}
        value={question}
        placeholder="Ask something where being wrong would actually cost you — an architecture call, a tricky bug, a factual claim."
        onChange={e => setQuestion(e.target.value)}
      />
      <div className="row-actions">
        <button className="primary" disabled={busy || !question.trim() || available.length < 2} onClick={ask}>
          {busy ? phase : 'Convene the council'}
        </button>
      </div>

      {result && !result.ok && <div className="err-text" style={{ marginTop: 16 }}>{result.error}</div>}

      {result?.ok && (
        <div className="council-result">
          {result.degraded && <div className="hint warn">{result.note}</div>}
          {result.note && !result.degraded && <div className="hint warn">{result.note}</div>}

          <h3>Synthesis {result.synthesiser && <span className="hint inline">via {result.synthesiser}</span>}</h3>
          <div className="council-synthesis">{result.synthesis}</div>

          <button className="ghost" onClick={() => setShowPanel(s => !s)}>
            {showPanel ? 'Hide' : 'Show'} individual answers ({result.answers.length})
          </button>

          {showPanel && (
            <div className="council-answers">
              {result.answers.map((a, i) => (
                <div key={i} className={`answer-card ${a.ok ? '' : 'err'}`}>
                  <div className="answer-head">{a.ok ? '✓' : '✕'} {a.model}</div>
                  <pre>{a.ok ? a.content : a.error}</pre>
                </div>
              ))}
            </div>
          )}
        </div>
      )}
    </div>
  );
}
