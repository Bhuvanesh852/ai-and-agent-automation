import React, { useEffect, useMemo, useState } from 'react';

const CATEGORIES = ['AI Prompts', 'Data Analysis', 'Research Notes'];

function ProjectModal({ initial, onClose, onSave }) {
  const [title, setTitle] = useState(initial?.title || '');
  const [description, setDescription] = useState(initial?.description || '');
  const [category, setCategory] = useState(initial?.category || CATEGORIES[0]);

  return (
    <div className="modal-backdrop" onClick={onClose}>
      <div className="modal" onClick={e => e.stopPropagation()}>
        <h3>{initial ? 'Edit Project' : 'New Project'}</h3>
        <label className="field">
          <span>Title</span>
          <input value={title} onChange={e => setTitle(e.target.value)} autoFocus />
        </label>
        <label className="field">
          <span>Description</span>
          <textarea value={description} onChange={e => setDescription(e.target.value)} />
        </label>
        <label className="field">
          <span>Category</span>
          <select value={category} onChange={e => setCategory(e.target.value)}>
            {CATEGORIES.map(c => <option key={c} value={c}>{c}</option>)}
          </select>
        </label>
        <div className="row" style={{ justifyContent: 'flex-end', gap: 8 }}>
          <button className="ghost" onClick={onClose}>Cancel</button>
          <button
            className="primary"
            disabled={!title.trim()}
            onClick={() => onSave({ title: title.trim(), description, category })}
          >
            Save
          </button>
        </div>
      </div>
    </div>
  );
}

export default function ProjectsPanel({ store, onOpenProject }) {
  const [query, setQuery] = useState('');
  const [sortBy, setSortBy] = useState('date');
  const [modal, setModal] = useState(null); // null | { mode: 'new' } | { mode: 'edit', project }

  useEffect(() => { store.loadProjects(); }, []);

  const filtered = useMemo(() => {
    let list = store.projects.filter(p =>
      !query.trim() || p.title.toLowerCase().includes(query.toLowerCase()) || (p.description || '').toLowerCase().includes(query.toLowerCase())
    );
    if (sortBy === 'date') list = [...list].sort((a, b) => b.updatedAt - a.updatedAt);
    if (sortBy === 'name') list = [...list].sort((a, b) => a.title.localeCompare(b.title));
    if (sortBy === 'type') list = [...list].sort((a, b) => (a.category || '').localeCompare(b.category || ''));
    return list;
  }, [store.projects, query, sortBy]);

  return (
    <div className="settings-panel">
      <div className="row" style={{ justifyContent: 'space-between', alignItems: 'center', marginBottom: 16 }}>
        <h2 style={{ margin: 0 }}>Projects</h2>
        <button className="primary" onClick={() => setModal({ mode: 'new' })}>+ New Project</button>
      </div>

      <div className="row" style={{ gap: 10, marginBottom: 16 }}>
        <input
          className="search-input"
          placeholder="Search projects…"
          value={query}
          onChange={e => setQuery(e.target.value)}
        />
        <select value={sortBy} onChange={e => setSortBy(e.target.value)}>
          <option value="date">Sort: Last Updated</option>
          <option value="name">Sort: Name</option>
          <option value="type">Sort: Category</option>
        </select>
      </div>

      {filtered.length === 0 && (
        <p className="hint">No projects yet. Create one to keep prompts, datasets, or research notes organized.</p>
      )}

      <div className="projects-grid">
        {filtered.map(p => (
          <div key={p.id} className="project-card">
            <div className="project-card-category">{p.category}</div>
            <h3>{p.title}</h3>
            <p className="hint">{p.description || 'No description.'}</p>
            <div className="project-card-meta">Updated {new Date(p.updatedAt).toLocaleDateString()}</div>
            <div className="row" style={{ gap: 6, marginTop: 10 }}>
              <button className="ghost" onClick={() => onOpenProject?.(p)}>Open</button>
              <button className="ghost" onClick={() => setModal({ mode: 'edit', project: p })}>Edit</button>
              <button className="ghost danger" onClick={() => store.deleteProject(p.id)}>Delete</button>
            </div>
          </div>
        ))}
      </div>

      {modal && (
        <ProjectModal
          initial={modal.mode === 'edit' ? modal.project : null}
          onClose={() => setModal(null)}
          onSave={async (data) => {
            if (modal.mode === 'edit') await store.updateProject(modal.project.id, data);
            else await store.createProject(data);
            setModal(null);
          }}
        />
      )}
    </div>
  );
}
