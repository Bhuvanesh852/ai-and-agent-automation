import React, { useRef, useState, useEffect } from 'react';
import AgentModelSelector from './AgentModelSelector.jsx';
import AdvancedTogglesRow from './AdvancedTogglesRow.jsx';
import FeatureBar from './FeatureBar.jsx';

export default function ChatArea({ store }) {
  const [input, setInput] = useState('');
  const [planMode, setPlanMode] = useState(false);
  const scrollRef = useRef(null);

  useEffect(() => {
    scrollRef.current?.scrollTo({ top: scrollRef.current.scrollHeight, behavior: 'smooth' });
  }, [store.messages]);

  const busy = store.isGenerating || store.isPlanRunning;

  const send = () => {
    const text = input.trim();
    if (!text || busy) return;
    setInput('');
    planMode ? store.runPlan(text) : store.sendMessage(text);
  };

  const onKeyDown = (e) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      send();
    }
  };

  return (
    <div className="chat-column">
      <AgentModelSelector store={store} />
      <AdvancedTogglesRow store={store} />

      <div className="messages" ref={scrollRef}>
        {store.messages.length === 0 && (
          <div className="empty-state">
            Pick an agent and a model above, then start typing. No API key configured yet? That's fine — Demo mode works out of the box.
          </div>
        )}
        {store.messages.map(m => (
          <div key={m.id} className={`msg ${m.role}`}>
            {m.content || (m.streaming ? '…' : '')}
            {m.role === 'assistant' && !m.streaming && m.content && (
              <span style={{ display: 'inline-flex', gap: 6, marginTop: 6 }}>
                <button
                  className="ghost"
                  style={{ fontSize: 11, padding: '2px 8px' }}
                  onClick={() => navigator.clipboard.writeText(m.content)}
                >
                  Copy
                </button>
                <button
                  className={`ghost ${m.rating === 1 ? 'on' : ''}`}
                  style={{ fontSize: 11, padding: '2px 8px' }}
                  onClick={() => store.rateMessage(m.id, 1)}
                  title="Good response"
                >
                  👍
                </button>
                <button
                  className={`ghost ${m.rating === -1 ? 'on' : ''}`}
                  style={{ fontSize: 11, padding: '2px 8px' }}
                  onClick={() => store.rateMessage(m.id, -1)}
                  title="Bad response"
                >
                  👎
                </button>
              </span>
            )}
            {m.role === 'assistant' && (m.providerUsed || m.streaming) && (
              <span className="meta">
                {m.streaming ? 'streaming…' : `${m.providerUsed}/${m.providerUsed === 'local-native' ? String(m.modelUsed).split(/[\\/]/).pop() : m.modelUsed}${m.fellBack ? ' (fallback)' : ''}`}
              </span>
            )}
          </div>
        ))}
      </div>

      <div className="composer">
        <button
          className={planMode ? 'primary' : 'ghost'}
          onClick={() => setPlanMode(p => !p)}
          title="Plan Mode: breaks the request into steps, executes each, then verifies (tests if available) and attempts one repair pass on failure."
        >
          🗺️ Plan
        </button>
        <textarea
          placeholder={planMode ? 'Describe a goal — it will be planned, executed step by step, then verified…' : 'Message the active agent… (Enter to send, Shift+Enter for newline)'}
          value={input}
          onChange={e => setInput(e.target.value)}
          onKeyDown={onKeyDown}
        />
        <button
          className="primary"
          onClick={store.isGenerating ? store.cancelGeneration : send}
          disabled={store.isPlanRunning && !store.isGenerating}
        >
          {store.isGenerating ? '⏹ Stop' : (store.isPlanRunning ? '🗺️ Plan running…' : 'Send')}
        </button>
      </div>

      <FeatureBar store={store} onEditPrompt={(text) => setInput(text || '')} />
    </div>
  );
}
