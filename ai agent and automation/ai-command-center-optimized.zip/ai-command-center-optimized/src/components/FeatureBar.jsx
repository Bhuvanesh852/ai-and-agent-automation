import React, { useState } from 'react';

function downloadBlob(filename, content, mime) {
  const blob = new Blob([content], { type: mime });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  a.remove();
  URL.revokeObjectURL(url);
}

// Section 4 of the UI spec: "Feature Buttons Panel". Every button calls a
// real store action (exportChat, clearChat, submitFeedback, etc. — see
// useAppStore.js) rather than being a placeholder.
export default function FeatureBar({ store, onEditPrompt }) {
  const [exportOpen, setExportOpen] = useState(false);
  const [shareOpen, setShareOpen] = useState(false);
  const [historyOpen, setHistoryOpen] = useState(false);
  const [feedbackOpen, setFeedbackOpen] = useState(false);
  const [confirmClear, setConfirmClear] = useState(false);
  const [copied, setCopied] = useState(false);
  const [stars, setStars] = useState(5);
  const [comment, setComment] = useState('');

  const download = (format) => {
    const content = store.exportChat(format);
    const ext = { json: 'json', markdown: 'md', csv: 'csv' }[format];
    const mime = { json: 'application/json', markdown: 'text/markdown', csv: 'text/csv' }[format];
    downloadBlob(`chat-export.${ext}`, content, mime);
    setExportOpen(false);
  };

  const copyAll = async () => {
    await navigator.clipboard.writeText(store.exportChat('markdown'));
    setCopied(true);
    setTimeout(() => setCopied(false), 1500);
  };

  const shareVia = (method) => {
    const text = store.exportChat('markdown');
    if (method === 'email') {
      window.open(`mailto:?subject=${encodeURIComponent('AI Command Center chat')}&body=${encodeURIComponent(text.slice(0, 1800))}`);
    } else if (method === 'link') {
      navigator.clipboard.writeText(text);
      setCopied(true);
      setTimeout(() => setCopied(false), 1500);
    } else if (method === 'social') {
      window.open(`https://twitter.com/intent/tweet?text=${encodeURIComponent(text.slice(0, 240))}`);
    }
    setShareOpen(false);
  };

  const submitFeedback = () => {
    store.submitFeedback({ stars, comment });
    setComment('');
    setFeedbackOpen(false);
  };

  const userMessages = store.messages.filter(m => m.role === 'user');

  return (
    <div className="feature-bar" role="toolbar" aria-label="Chat actions">
      <div className="feature-bar-group">
        <button className="ghost" onClick={() => setExportOpen(o => !o)}>⬇️ Download</button>
        {exportOpen && (
          <div className="popover">
            <button onClick={() => download('json')}>JSON</button>
            <button onClick={() => download('markdown')}>Markdown</button>
            <button onClick={() => download('csv')}>CSV</button>
          </div>
        )}
      </div>

      <button className="ghost" onClick={copyAll}>{copied ? '✅ Copied!' : '📋 Copy to Clipboard'}</button>

      <div className="feature-bar-group">
        <button className="ghost" onClick={() => setShareOpen(o => !o)}>🔗 Share</button>
        {shareOpen && (
          <div className="popover">
            <button onClick={() => shareVia('email')}>Email</button>
            <button onClick={() => shareVia('social')}>Social Media</button>
            <button onClick={() => shareVia('link')}>Copy Link/Text</button>
          </div>
        )}
      </div>

      <button
        className="ghost"
        onClick={() => onEditPrompt?.(store.lastUserMessage())}
        disabled={!store.lastUserMessage()}
      >
        ✏️ Edit Prompt
      </button>

      <button className="ghost" onClick={() => setConfirmClear(true)} disabled={store.messages.length === 0}>
        🗑️ Clear Chat
      </button>
      {confirmClear && (
        <div className="modal-backdrop" onClick={() => setConfirmClear(false)}>
          <div className="modal" onClick={e => e.stopPropagation()}>
            <h3>Clear this chat?</h3>
            <p className="hint">This removes every message in the current conversation. It can't be undone.</p>
            <div className="row" style={{ justifyContent: 'flex-end', gap: 8 }}>
              <button className="ghost" onClick={() => setConfirmClear(false)}>Cancel</button>
              <button className="primary" onClick={() => { store.clearChat(); setConfirmClear(false); }}>Clear</button>
            </div>
          </div>
        </div>
      )}

      <div className="feature-bar-group">
        <button className="ghost" onClick={() => setHistoryOpen(o => !o)}>🕘 History</button>
        {historyOpen && (
          <div className="popover popover-wide">
            {userMessages.length === 0 && <div className="hint">No messages yet this session.</div>}
            {userMessages.slice(-10).reverse().map(m => (
              <button key={m.id} className="history-item" onClick={() => { onEditPrompt?.(m.content); setHistoryOpen(false); }}>
                {m.content.slice(0, 60)}{m.content.length > 60 ? '…' : ''}
              </button>
            ))}
          </div>
        )}
      </div>

      <button className="ghost" onClick={() => setFeedbackOpen(true)}>⭐ Feedback</button>
      {feedbackOpen && (
        <div className="modal-backdrop" onClick={() => setFeedbackOpen(false)}>
          <div className="modal" onClick={e => e.stopPropagation()}>
            <h3>Rate this session</h3>
            <div className="star-row">
              {[1, 2, 3, 4, 5].map(n => (
                <span key={n} className={`star ${n <= stars ? 'on' : ''}`} onClick={() => setStars(n)}>★</span>
              ))}
            </div>
            <textarea placeholder="Optional comment…" value={comment} onChange={e => setComment(e.target.value)} />
            <div className="row" style={{ justifyContent: 'flex-end', gap: 8 }}>
              <button className="ghost" onClick={() => setFeedbackOpen(false)}>Cancel</button>
              <button className="primary" onClick={submitFeedback}>Submit</button>
            </div>
          </div>
        </div>
      )}

      <div className="feature-bar-group">
        <button className="ghost" onClick={() => setExportOpen(o => !o)}>📤 Export Formats</button>
      </div>
    </div>
  );
}
