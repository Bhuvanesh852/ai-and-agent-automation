import React, { useEffect, useMemo, useState } from 'react';
import { AGENTS } from '../agents/agents.js';

export default function CommandPalette({ store, onClose, onNavigate }) {
  const [query, setQuery] = useState('');
  const [selected, setSelected] = useState(0);

  const commands = useMemo(() => {
    const base = [
      { id: 'new-chat', label: 'New Chat', run: () => store.clearChat() },
      { id: 'go-settings', label: 'Open Settings', run: () => onNavigate('settings') },
      { id: 'go-chat', label: 'Open Chat', run: () => onNavigate('chat') },
      { id: 'go-logs', label: 'Open Logs', run: () => onNavigate('logs') },
      { id: 'go-files', label: 'Open Workspace Folder…', run: () => { onNavigate('files'); store.selectWorkspace(); } },
      { id: 'go-security', label: 'Open Security Center', run: () => onNavigate('security') },
      { id: 'stop-all', label: '🛑 STOP ALL AGENTS', run: () => store.setStopAll(true) },
      { id: 'toggle-lockdown', label: store.lockdownMode ? 'Disable Lockdown Mode' : 'Enable Lockdown Mode', run: () => store.toggleLockdown() },
      ...AGENTS.map(a => ({
        id: `agent-${a.id}`,
        label: `Switch to agent: ${a.name}`,
        run: () => store.setActiveAgent(a.id)
      }))
    ];
    if (!query) return base;
    return base.filter(c => c.label.toLowerCase().includes(query.toLowerCase()));
  }, [query, store]);

  useEffect(() => {
    const handler = (e) => {
      if (e.key === 'Escape') onClose();
      if (e.key === 'ArrowDown') setSelected(s => Math.min(s + 1, commands.length - 1));
      if (e.key === 'ArrowUp') setSelected(s => Math.max(s - 1, 0));
      if (e.key === 'Enter' && commands[selected]) {
        commands[selected].run();
        onClose();
      }
    };
    window.addEventListener('keydown', handler);
    return () => window.removeEventListener('keydown', handler);
  }, [commands, selected, onClose]);

  return (
    <div className="command-palette-overlay" onClick={onClose}>
      <div className="command-palette" onClick={e => e.stopPropagation()}>
        <input
          autoFocus
          placeholder="Type a command…"
          value={query}
          onChange={e => { setQuery(e.target.value); setSelected(0); }}
        />
        <ul>
          {commands.map((c, i) => (
            <li
              key={c.id}
              className={i === selected ? 'selected' : ''}
              onMouseEnter={() => setSelected(i)}
              onClick={() => { c.run(); onClose(); }}
            >
              {c.label}
            </li>
          ))}
        </ul>
      </div>
    </div>
  );
}
