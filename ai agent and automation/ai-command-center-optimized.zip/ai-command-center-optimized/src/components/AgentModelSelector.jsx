import React from 'react';
import { AGENTS } from '../agents/agents.js';
import { REGISTRY } from '../gateway/registry.js';

export default function AgentModelSelector({ store }) {
  const availableModels = REGISTRY.filter(m => m.enabled);

  return (
    <div className="chat-header">
      <div style={{ display: 'flex', flexWrap: 'wrap', gap: 12, flex: 1 }}>
        <div className="agent-picker">
          {AGENTS.map(a => (
            <div
              key={a.id}
              className={`pill ${store.activeAgentId === a.id ? 'active' : ''}`}
              onClick={() => store.setActiveAgent(a.id)}
              title={a.systemPrompt}
            >
              {a.icon} {a.name}
            </div>
          ))}
        </div>
        <div className="model-picker">
          {availableModels.map(m => (
            <div
              key={`${m.provider}-${m.model_id}`}
              className={`pill ${store.activeProvider === m.provider && store.activeModelId === m.model_id ? 'active' : ''}`}
              onClick={() => store.setActiveModel(m.provider, m.model_id)}
              title={`${m.cost_class} · ${m.latency_class} · ctx ${m.context_window}`}
            >
              {m.display_name}
            </div>
          ))}
          {store.localModels.map(m => (
            <div
              key={`local-native-${m.path}`}
              className={`pill ${store.activeProvider === 'local-native' && store.activeModelId === m.path ? 'active' : ''}`}
              onClick={() => store.setActiveModel('local-native', m.path)}
              title={`Self-owned local GGUF, no Ollama, no key · ${m.sizeGB} GB · first message loads it into memory`}
            >
              🗄️ {m.name}
            </div>
          ))}
        </div>
      </div>
      <button className="ghost" onClick={() => store.clearChat()} title="Clear the current conversation">🆕 New Chat</button>
    </div>
  );
}
