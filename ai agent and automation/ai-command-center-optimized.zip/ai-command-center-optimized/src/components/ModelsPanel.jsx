import React, { useEffect, useState } from 'react';
import { REGISTRY } from '../gateway/registry.js';

export default function ModelsPanel({ store }) {
  const [hardware, setHardware] = useState(null);
  const [gpuPref, setGpuPref] = useState('auto');
  const [loadingPath, setLoadingPath] = useState(null);
  const [loadResult, setLoadResult] = useState({});

  useEffect(() => {
    store.loadLocalModels();
    window.bridge?.localModel?.hardware().then(setHardware);
  }, []);

  const useThisModel = async (m) => {
    setLoadingPath(m.path);
    const res = await window.bridge.localModel.load(m.path);
    setLoadResult(r => ({ ...r, [m.path]: res }));
    setLoadingPath(null);
    if (res.ok) {
      store.setActiveModel('local-native', m.path);
      store.pushActivity(`Loaded local model: ${m.name}`);
    }
  };

  const applyGpu = async (pref) => {
    setGpuPref(pref);
    await window.bridge.localModel.setGpu(pref === 'auto' ? 'auto' : pref === 'cpu' ? false : pref);
    store.pushActivity(`Local inference GPU backend set to: ${pref}`);
  };

  return (
    <div className="settings-panel" style={{ maxWidth: 760 }}>
      <h2 style={{ marginTop: 0 }}>Models</h2>
      <p className="hint">
        Self-owned local inference — no Ollama, no API key, no account. Runs GGUF model
        files directly on this machine via <code>node-llama-cpp</code>.
      </p>

      <div className="provider-card">
        <div className="row"><strong>Hardware</strong></div>
        {hardware ? (
          <div className="hint">
            {hardware.cpuCores} CPU cores · {hardware.freeRamGB} GB free of {hardware.totalRamGB} GB RAM total.
            Models are checked against free RAM before loading — nothing loads that would clearly overrun your memory.
          </div>
        ) : <div className="hint">Detecting…</div>}
        <div className="row" style={{ marginTop: 10, gap: 8 }}>
          <span className="hint">GPU backend:</span>
          {['auto', 'cuda', 'vulkan', 'metal', 'cpu'].map(p => (
            <button key={p} className={gpuPref === p ? 'primary' : 'ghost'} onClick={() => applyGpu(p)}>{p}</button>
          ))}
        </div>
        <div className="hint">
          "auto" lets node-llama-cpp pick the best backend it detects. Forcing a backend that
          isn't actually available on this machine will make the next model load fail —
          switch back to "auto" if that happens. Takes effect on the next model load.
        </div>
      </div>

      <div className="provider-card">
        <div className="row">
          <strong>Local GGUF models</strong>
          <button className="ghost" onClick={() => store.loadLocalModels()}>Refresh</button>
        </div>
        <div className="hint">
          Drop <code>.gguf</code> files into: <code>{store.localModelsDir || '…'}</code>
          {store.workspaceRoot && <> or your open workspace's <code>models/</code> folder</>}.
          This app never downloads a model automatically — you choose and place the file yourself.
          Look for permissively-licensed GGUF builds (e.g. Qwen2.5-Instruct, Llama-3.2-Instruct) on
          Hugging Face; smaller Q4_K_M quantizations fit better on 8GB-class laptops.
        </div>

        {store.localModels.length === 0 && (
          <div className="hint" style={{ marginTop: 10 }}>No .gguf files found yet.</div>
        )}

        {store.localModels.map(m => {
          const isActive = store.activeProvider === 'local-native' && store.activeModelId === m.path;
          const result = loadResult[m.path];
          return (
            <div key={m.path} className="row" style={{ marginTop: 10, alignItems: 'flex-start' }}>
              <div>
                <div>{m.name} <span className="hint">({m.sizeGB} GB)</span></div>
                {result && !result.ok && <div className="hint">⚠️ {result.error}</div>}
              </div>
              <button
                className={isActive ? 'primary' : 'ghost'}
                disabled={loadingPath === m.path}
                onClick={() => useThisModel(m)}
              >
                {loadingPath === m.path ? 'Loading…' : isActive ? '✓ Active' : 'Use this model'}
              </button>
            </div>
          );
        })}
      </div>

      <div className="provider-card">
        <div className="row"><strong>Cloud &amp; other local providers</strong></div>
        <div className="hint">
          {REGISTRY.filter(m => m.enabled).map(m => `${m.display_name}`).join(' · ')}
        </div>
        <div className="hint">Manage API keys for the cloud ones in Settings.</div>
      </div>
    </div>
  );
}
