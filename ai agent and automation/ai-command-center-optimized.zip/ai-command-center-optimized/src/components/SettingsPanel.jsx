import React, { useEffect, useState } from 'react';
import { PROVIDERS } from '../gateway/registry.js';
import { listOllamaModels } from '../gateway/adapters/ollama.js';

export default function SettingsPanel({ store }) {
  const [drafts, setDrafts] = useState({});
  const [testResults, setTestResults] = useState({});
  const [ollamaModels, setOllamaModels] = useState([]);
  const [saveErrors, setSaveErrors] = useState({});
  const hasBridge = typeof window !== 'undefined' && !!window.bridge;

  useEffect(() => {
    if (!hasBridge) return; // nothing to load without the desktop bridge
    store.refreshProviderStatus();
    listOllamaModels().then(setOllamaModels);
  }, []);

  // Previously these three handlers called window.bridge directly with no
  // try/catch. Two real failure modes both looked identical from the UI —
  // "I click Save and the key is just gone when I come back":
  //   1. This page opened as a plain browser tab (no Electron shell), so
  //      window.bridge is undefined and the call throws immediately.
  //   2. Running inside Electron, but the OS-level secure storage the main
  //      process relies on (safeStorage) isn't available on this machine,
  //      so the *main process* throws and the rejection propagated back
  //      here — again silently, since nothing caught it.
  // Both are now caught and shown directly in the UI instead of failing
  // invisibly.

  const save = async (providerId) => {
    const key = drafts[providerId];
    if (!key) return;
    setSaveErrors(e => ({ ...e, [providerId]: null }));
    try {
      if (!hasBridge) throw new Error('Not running inside the desktop app — keys can only be saved from the Electron shell, not a browser tab.');
      await window.bridge.creds.save(providerId, key);
      setDrafts(d => ({ ...d, [providerId]: '' }));
      await store.refreshProviderStatus();
      store.pushActivity(`Saved credential for ${providerId}`);
    } catch (err) {
      setSaveErrors(e => ({ ...e, [providerId]: String(err?.message || err) }));
    }
  };

  const remove = async (providerId) => {
    try {
      if (!hasBridge) throw new Error('Not running inside the desktop app.');
      await window.bridge.creds.remove(providerId);
      await store.refreshProviderStatus();
      setTestResults(r => ({ ...r, [providerId]: null }));
      store.pushActivity(`Removed credential for ${providerId}`);
    } catch (err) {
      setSaveErrors(e => ({ ...e, [providerId]: String(err?.message || err) }));
    }
  };

  // BUG FIX: this used to only call creds.hasKey(), i.e. "is *something*
  // saved for this provider" — it never actually talked to Groq/Gemini/
  // OpenRouter. A revoked, typo'd, or expired key showed the exact same
  // "✅ ready" result as a working one. Now it sends one small, real
  // request via provider:test and reports what actually came back.
  const test = async (providerId) => {
    setTestResults(r => ({ ...r, [providerId]: 'testing' }));
    try {
      if (!hasBridge) throw new Error('Not running inside the desktop app.');
      const hasKey = await window.bridge.creds.hasKey(providerId);
      if (!hasKey) {
        setTestResults(r => ({ ...r, [providerId]: 'no-key' }));
        return;
      }
      const res = await window.bridge.provider.test(providerId);
      if (res.ok) {
        setTestResults(r => ({ ...r, [providerId]: 'ok' }));
        return;
      }
      const stateByError = {
        INVALID_KEY: 'invalid',
        QUOTA_EXCEEDED: 'quota',
        TIMEOUT: 'timeout',
        NETWORK_ERROR: 'network',
        LOCKDOWN_ACTIVE: 'lockdown',
        NO_CREDENTIAL: 'no-key',
        UNSUPPORTED_PROVIDER: 'error',
        PROVIDER_ERROR: 'error'
      };
      setTestResults(r => ({ ...r, [providerId]: stateByError[res.error] || 'error' }));
    } catch (err) {
      setSaveErrors(e => ({ ...e, [providerId]: String(err?.message || err) }));
      setTestResults(r => ({ ...r, [providerId]: 'error' }));
    }
  };

  return (
    <div className="settings-panel">
      <h2 style={{ marginTop: 0 }}>Provider Setup</h2>
      <p className="hint">
        Keys are encrypted at rest via your OS's secure storage and never leave this machine except
        in the actual request to that provider. Nothing is written into generated code, logs, or chat.
      </p>
      {!hasBridge && (
        <div className="provider-card" style={{ borderColor: '#c0392b' }}>
          <strong style={{ color: '#e74c3c' }}>⚠️ Desktop app not detected</strong>
          <p className="hint" style={{ marginBottom: 0 }}>
            This page is running as a plain browser tab (e.g. the Vite dev server directly), not inside the
            Electron desktop shell. Saved keys, chat with real providers, tool execution, and everything else
            that needs <code>window.bridge</code> won't work here — that's why keys disappear and chat hangs.
            Launch the actual desktop app with <code>npm run dev</code> (or the packaged build) instead of
            opening <code>localhost:5173</code> directly in a browser.
          </p>
        </div>
      )}

      {PROVIDERS.filter(p => p.requiresKey).map(p => {
        const status = store.providerStatus[p.id];
        return (
          <div className="provider-card" key={p.id}>
            <div className="row">
              <strong>{p.name}</strong>
              <span className={`status-chip ${status ? 'configured' : 'missing'}`}>
                {status ? `Configured (••••${status.last4})` : 'Missing'}
              </span>
            </div>
            <div className="row" style={{ marginTop: 10 }}>
              <input
                type="password"
                placeholder={`Paste your ${p.name} API key`}
                value={drafts[p.id] || ''}
                onChange={e => setDrafts(d => ({ ...d, [p.id]: e.target.value }))}
              />
              <button className="ghost" onClick={() => save(p.id)}>Save</button>
              <button className="ghost" onClick={() => test(p.id)}>Test Connection</button>
              {status && <button className="ghost" onClick={() => remove(p.id)}>Remove</button>}
            </div>
            {testResults[p.id] && (
              <div className="hint">
                {testResults[p.id] === 'testing' && 'Testing…'}
                {testResults[p.id] === 'ok' && '✅ Key is valid — the provider accepted it.'}
                {testResults[p.id] === 'no-key' && '⚠️ No key saved yet.'}
                {testResults[p.id] === 'invalid' && '❌ The provider rejected this key (invalid, revoked, or expired).'}
                {testResults[p.id] === 'quota' && '⚠️ Key is valid, but you\'re rate-limited or out of free-tier quota right now.'}
                {testResults[p.id] === 'timeout' && '⚠️ Timed out waiting for the provider — try again in a moment.'}
                {testResults[p.id] === 'network' && '⚠️ Network error reaching the provider — check your connection.'}
                {testResults[p.id] === 'lockdown' && '🔒 Lockdown Mode is active — turn it off in the Security Center to test.'}
                {testResults[p.id] === 'error' && '⚠️ Could not verify the key — see the error below, if any.'}
              </div>
            )}
            {saveErrors[p.id] && (
              <div className="hint" style={{ color: '#e74c3c' }}>⚠️ {saveErrors[p.id]}</div>
            )}
            {p.docsUrl && (
              <div className="hint">Get a free-tier key: <a href={p.docsUrl} target="_blank" rel="noreferrer">{p.docsUrl}</a></div>
            )}
          </div>
        );
      })}

      <div className="provider-card">
        <div className="row">
          <strong>Ollama (local)</strong>
          <span className={`status-chip ${ollamaModels.length ? 'configured' : 'missing'}`}>
            {ollamaModels.length ? `${ollamaModels.length} model(s) found` : 'Not detected'}
          </span>
        </div>
        <div className="hint">
          No key needed — runs fully offline on your machine. Install from{' '}
          <a href="https://ollama.com/download" target="_blank" rel="noreferrer">ollama.com/download</a>, then
          run <code>ollama pull llama3.2:3b</code>.
        </div>
        {ollamaModels.length > 0 && (
          <div className="hint">Installed: {ollamaModels.join(', ')}</div>
        )}
      </div>

      <div className="provider-card">
        <div className="row">
          <strong>Demo / Mock Mode</strong>
          <span className="status-chip configured">Always available</span>
        </div>
        <div className="hint">Works with zero configuration. Every simulated response is clearly labeled [DEMO MODE].</div>
      </div>
    </div>
  );
}
