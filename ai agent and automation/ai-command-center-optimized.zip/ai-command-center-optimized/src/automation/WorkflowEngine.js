// Workflow execution engine.
//
// A workflow is a directed graph of nodes (see nodes.js). Execution starts at
// a trigger node and walks `next` edges, passing each node's output into the
// next node's input. `condition` splits into trueNext/falseNext; `foreach`
// runs its bodyNext branch once per array item and collects the results.
//
// Every capability is INJECTED (see the `deps` argument) rather than imported.
// That keeps the engine free of React/zustand/Electron imports, which means it
// can be unit-tested with plain fakes and can't quietly reach around the
// permission system to call a provider or tool directly.
//
// SECURITY NOTE about the `code` and `condition` nodes: they evaluate
// JavaScript with `new Function`, which runs at full renderer privilege. This
// is NOT a sandbox. It is fine for workflows you wrote yourself — it is the
// same trust level as the rest of your app config — but a workflow JSON file
// imported from someone else should be read before it is run, exactly like
// you'd read a shell script before running it. The import UI says so.

const MAX_STEPS = 200;
const MAX_FOREACH_ITEMS = 50;

export class WorkflowCancelled extends Error {
  constructor() {
    super('Workflow cancelled.');
    this.name = 'WorkflowCancelled';
  }
}

/**
 * Resolve {{...}} templates in a config string.
 *   {{input}}          previous node's output
 *   {{node.Name}}      a named earlier node's output
 *   {{json.a.b}}       path into the previous output if it is an object
 *   {{now}}            ISO timestamp
 */
export function resolveTemplate(str, { input, byName }) {
  if (typeof str !== 'string') return str;
  return str.replace(/\{\{\s*([^}]+?)\s*\}\}/g, (_, expr) => {
    const e = String(expr).trim();
    if (e === 'input') return stringify(input);
    if (e === 'now') return new Date().toISOString();
    if (e.startsWith('node.')) return stringify(byName[e.slice(5)]);
    if (e.startsWith('json.')) return stringify(getPath(input, e.slice(5)));
    return '';
  });
}

function getPath(obj, path) {
  return String(path)
    .split('.')
    .reduce((acc, k) => (acc == null ? undefined : acc[k]), obj);
}

function stringify(v) {
  if (v == null) return '';
  if (typeof v === 'string') return v;
  try {
    return JSON.stringify(v, null, 2);
  } catch {
    return String(v);
  }
}

function resolveConfig(config, ctx) {
  const out = {};
  for (const [k, v] of Object.entries(config || {})) {
    out[k] = typeof v === 'string' ? resolveTemplate(v, ctx) : v;
  }
  return out;
}

function parseJSONField(raw, fallback) {
  if (raw == null || raw === '') return fallback;
  if (typeof raw === 'object') return raw;
  try {
    return JSON.parse(raw);
  } catch {
    return fallback;
  }
}

/**
 * @param {object} workflow  { id, name, nodes: [...] }
 * @param {object} deps      { callModel, callCouncil, callAgent, callTool, callMcp, sleep }
 * @param {object} [opts]    { onStep, shouldCancel, triggerInput }
 */
export async function runWorkflow(workflow, deps, opts = {}) {
  const { onStep = () => {}, shouldCancel = () => false, triggerInput } = opts;
  const runId = (globalThis.crypto?.randomUUID?.() || String(Date.now()));
  const startedAt = Date.now();

  const nodes = workflow.nodes || [];
  const byId = Object.fromEntries(nodes.map(n => [n.id, n]));
  const byName = {};
  const steps = [];
  let stepCount = 0;
  let lastOutput = null;

  const record = (node, status, output, error, ms) => {
    const step = {
      nodeId: node.id,
      nodeName: node.name || node.type,
      type: node.type,
      status,
      output: status === 'error' ? null : output,
      error: error || null,
      durationMs: ms,
      at: Date.now()
    };
    steps.push(step);
    onStep(step);
    return step;
  };

  const start = nodes.find(n => n.id === workflow.startNodeId) || nodes.find(n => String(n.type).startsWith('trigger.')) || nodes[0];
  if (!start) {
    return { ok: false, runId, error: 'Workflow has no nodes.', steps, durationMs: 0 };
  }

  /** Execute one node and return its output. */
  async function execNode(node, input) {
    if (shouldCancel()) throw new WorkflowCancelled();
    const t0 = Date.now();
    const ctx = { input, byName };
    const cfg = resolveConfig(node.config, ctx);

    try {
      let output;
      switch (node.type) {
        case 'trigger.manual':
        case 'trigger.schedule':
        case 'trigger.webhook':
          output = triggerInput !== undefined && triggerInput !== null && triggerInput !== ''
            ? triggerInput
            : (cfg.input || '');
          break;

        case 'llm':
          output = await deps.callModel({
            system: cfg.system || '',
            prompt: cfg.prompt || '',
            strength: cfg.strength || 'auto',
            temperature: Number(cfg.temperature ?? 0.7)
          });
          break;

        case 'council':
          output = await deps.callCouncil({
            prompt: cfg.prompt || '',
            members: Number(cfg.members || 3)
          });
          break;

        case 'agent':
          output = await deps.callAgent({ agentId: cfg.agentId, task: cfg.task || '' });
          break;

        case 'extract': {
          const fields = String(cfg.schema || '')
            .split(',')
            .map(f => f.trim())
            .filter(Boolean);
          const raw = await deps.callModel({
            system:
              'You extract structured data. Reply with ONE JSON object and nothing else — no prose, no code ' +
              'fences. Use null for any field you cannot find. Never invent a value.',
            prompt: `Extract these fields: ${fields.join(', ')}\n\nFrom this text:\n${cfg.source || ''}`,
            strength: 'structured',
            temperature: 0.1
          });
          const cleaned = String(raw).replace(/```json|```/g, '').trim();
          const match = cleaned.match(/\{[\s\S]*\}/);
          output = parseJSONField(match ? match[0] : cleaned, { _parseFailed: true, raw: cleaned });
          break;
        }

        case 'research': {
          const res = await deps.callTool('deep_research', {
            query: cfg.query || '',
            sources: cfg.sources
          });
          output = res?.result ?? res;
          break;
        }

        case 'readUrl': {
          const res = await deps.callTool('read_url', { url: String(cfg.url || '').trim() });
          output = res?.result ?? res;
          break;
        }

        case 'rag': {
          const res = await deps.callTool('rag_query', {
            question: cfg.question || '',
            topK: Number(cfg.topK || 5)
          });
          output = res?.result ?? res;
          break;
        }

        case 'http': {
          const res = await deps.callTool('http_request', {
            url: String(cfg.url || '').trim(),
            method: cfg.method || 'POST',
            headers: parseJSONField(cfg.headers, {}),
            body: cfg.body
          });
          output = res?.result ?? res;
          break;
        }

        case 'mcp':
          output = await deps.callMcp({
            connectionId: cfg.connectionId,
            toolName: cfg.toolName,
            args: parseJSONField(cfg.args, {})
          });
          break;

        case 'tool': {
          const res = await deps.callTool(cfg.toolName, parseJSONField(cfg.args, {}));
          output = res?.result ?? res;
          break;
        }

        case 'code': {
          // eslint-disable-next-line no-new-func
          const fn = new Function('input', 'nodes', node.config?.body || 'return input;');
          output = await fn(input, byName);
          break;
        }

        case 'condition': {
          // eslint-disable-next-line no-new-func
          const fn = new Function('input', 'nodes', node.config?.expression || 'return true;');
          output = { branch: (await fn(input, byName)) ? 'true' : 'false', input };
          break;
        }

        case 'delay':
          await deps.sleep(Number(cfg.seconds || 1) * 1000);
          output = input;
          break;

        case 'foreach':
          // Handled by the walker below — this node's own "output" is just
          // the (validated) list it is about to iterate.
          output = Array.isArray(input) ? input : [input];
          break;

        case 'output':
          output = input;
          break;

        default:
          throw new Error(`Unknown node type "${node.type}".`);
      }

      if (node.name) byName[node.name] = output;
      record(node, 'ok', output, null, Date.now() - t0);
      return output;
    } catch (err) {
      if (err instanceof WorkflowCancelled) throw err;
      record(node, 'error', null, String(err?.message || err), Date.now() - t0);
      throw err;
    }
  }

  /** Walk a chain of node ids sequentially, threading output -> input. */
  async function walk(nodeIds, input) {
    let current = input;
    const queue = [...(nodeIds || [])];

    while (queue.length) {
      if (++stepCount > MAX_STEPS) {
        throw new Error(`Workflow exceeded ${MAX_STEPS} steps — likely an unintended cycle.`);
      }
      const node = byId[queue.shift()];
      if (!node) continue;

      if (node.type === 'foreach') {
        const list = await execNode(node, current);
        const limit = Math.min(Number(node.config?.maxItems || 10), MAX_FOREACH_ITEMS);
        const collected = [];
        for (const item of list.slice(0, limit)) {
          collected.push(await walk(node.bodyNext || [], item));
        }
        current = collected;
        queue.push(...(node.next || []));
        continue;
      }

      if (node.type === 'condition') {
        const res = await execNode(node, current);
        const branch = res.branch === 'true' ? node.trueNext : node.falseNext;
        current = res.input;
        queue.push(...(branch || []));
        continue;
      }

      current = await execNode(node, current);
      queue.push(...(node.next || []));
    }
    return current;
  }

  try {
    lastOutput = await walk([start.id], triggerInput);
    return {
      ok: true,
      runId,
      workflowId: workflow.id,
      workflowName: workflow.name,
      output: lastOutput,
      steps,
      durationMs: Date.now() - startedAt,
      finishedAt: Date.now()
    };
  } catch (err) {
    const cancelled = err instanceof WorkflowCancelled;
    return {
      ok: false,
      cancelled,
      runId,
      workflowId: workflow.id,
      workflowName: workflow.name,
      error: cancelled ? 'Cancelled.' : String(err?.message || err),
      steps,
      durationMs: Date.now() - startedAt,
      finishedAt: Date.now()
    };
  }
}

/** Basic structural validation, surfaced in the builder before a run. */
export function validateWorkflow(workflow) {
  const problems = [];
  const nodes = workflow?.nodes || [];
  if (nodes.length === 0) problems.push('Workflow has no nodes.');

  const ids = new Set(nodes.map(n => n.id));
  if (ids.size !== nodes.length) problems.push('Duplicate node ids.');
  if (!nodes.some(n => String(n.type).startsWith('trigger.'))) problems.push('No trigger node — nothing can start this workflow.');

  for (const n of nodes) {
    for (const edge of ['next', 'trueNext', 'falseNext', 'bodyNext']) {
      for (const target of n[edge] || []) {
        if (!ids.has(target)) problems.push(`Node "${n.name || n.id}" points at a missing node (${target}).`);
      }
    }
  }
  return { ok: problems.length === 0, problems };
}
