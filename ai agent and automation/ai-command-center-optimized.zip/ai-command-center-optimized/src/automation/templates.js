// Starter workflows. These exist so the Automations panel is useful the
// moment it's opened rather than an empty canvas, and so each one doubles as
// a worked example of a different node category.
//
// All of them run on free tiers only. The ones that touch the network say so.

const id = () => (globalThis.crypto?.randomUUID?.() || `n${Math.random().toString(36).slice(2, 10)}`);

function wf(name, description, tags, build) {
  const nodes = build();
  return {
    id: id(),
    name,
    description,
    tags,
    nodes,
    startNodeId: nodes[0].id,
    createdAt: Date.now(),
    updatedAt: Date.now()
  };
}

export function buildTemplates() {
  return [
    // ------------------------------------------------------------------
    wf(
      'Research Briefing',
      'Research a topic across four free sources, read the best page in full, then write a sourced briefing. Needs internet.',
      ['research', 'internet'],
      () => {
        const t = id(), r = id(), pick = id(), read = id(), write = id(), out = id();
        return [
          { id: t, type: 'trigger.manual', name: 'Start', config: { input: 'state of open-weight LLMs' }, next: [r] },
          { id: r, type: 'research', name: 'Research', config: { query: '{{input}}', sources: ['duckduckgo', 'wikipedia', 'hackernews', 'arxiv'] }, next: [pick] },
          {
            id: pick,
            type: 'code',
            name: 'BestURL',
            config: { body: 'const hits = input?.results || [];\nconst best = hits.find(h => h.url && h.source !== "hackernews") || hits.find(h => h.url);\nreturn best ? best.url : "";' },
            next: [read]
          },
          { id: read, type: 'readUrl', name: 'ReadPage', config: { url: '{{input}}' }, next: [write] },
          {
            id: write,
            type: 'llm',
            name: 'Briefing',
            config: {
              system: 'You write short, sourced briefings. Cite the URL you were given. Never state a fact the source text does not support — if the page did not cover something, say so.',
              prompt: 'Source page:\n{{input}}\n\nEarlier multi-source snippets:\n{{node.Research}}\n\nWrite a 200-word briefing with a "Confidence" line at the end.',
              strength: 'general',
              temperature: 0.4
            },
            next: [out]
          },
          { id: out, type: 'output', name: 'Result', config: { label: 'Briefing' }, next: [] }
        ];
      }
    ),

    // ------------------------------------------------------------------
    wf(
      'Council Answer',
      'Ask three different free models the same hard question, then synthesise one answer that flags disagreement.',
      ['ai', 'quality'],
      () => {
        const t = id(), c = id(), out = id();
        return [
          { id: t, type: 'trigger.manual', name: 'Start', config: { input: 'Should this project use SQLite or Postgres?' }, next: [c] },
          { id: c, type: 'council', name: 'Panel', config: { prompt: '{{input}}', members: 3 }, next: [out] },
          { id: out, type: 'output', name: 'Result', config: { label: 'Consensus' }, next: [] }
        ];
      }
    ),

    // ------------------------------------------------------------------
    wf(
      'Codebase Security Sweep',
      'Scan the open workspace for secrets and risky dependencies, then have the security agent write a prioritised report. Fully offline.',
      ['security', 'offline'],
      () => {
        const t = id(), sec = id(), dep = id(), rep = id(), out = id();
        return [
          { id: t, type: 'trigger.manual', name: 'Start', config: {}, next: [sec] },
          { id: sec, type: 'tool', name: 'Secrets', config: { toolName: 'scan_secrets', args: '{}' }, next: [dep] },
          { id: dep, type: 'tool', name: 'Deps', config: { toolName: 'scan_dependencies', args: '{}' }, next: [rep] },
          {
            id: rep,
            type: 'llm',
            name: 'Report',
            config: {
              system: 'You are a security reviewer. Classify every finding Informational/Low/Medium/High/Critical with exploitability, impact and remediation. Never claim the codebase is secure or vulnerability-free — report residual uncertainty.',
              prompt: 'Secret scan:\n{{node.Secrets}}\n\nDependency scan:\n{{input}}\n\nWrite a prioritised report.',
              strength: 'reasoning',
              temperature: 0.2
            },
            next: [out]
          },
          { id: out, type: 'output', name: 'Result', config: { label: 'Security Report' }, next: [] }
        ];
      }
    ),

    // ------------------------------------------------------------------
    wf(
      'Daily Digest → Webhook',
      'On a schedule: research your topic, summarise it, and POST the summary to any webhook (Slack, Discord, Telegram, n8n, your own API). Edit the URL before running.',
      ['automation', 'integration', 'internet'],
      () => {
        const t = id(), r = id(), sum = id(), gate = id(), post = id(), out = id();
        return [
          { id: t, type: 'trigger.schedule', name: 'Daily', config: { everyMinutes: 1440, input: 'AI tooling news' }, next: [r] },
          { id: r, type: 'research', name: 'Research', config: { query: '{{input}}', sources: ['duckduckgo', 'hackernews'] }, next: [sum] },
          {
            id: sum,
            type: 'llm',
            name: 'Summary',
            config: {
              system: 'You write terse daily digests. Five bullets maximum. No filler, no preamble.',
              prompt: '{{input}}',
              strength: 'speed',
              temperature: 0.3
            },
            next: [gate]
          },
          {
            id: gate,
            type: 'condition',
            name: 'HasContent',
            config: { expression: 'return String(input).trim().length > 40;' },
            trueNext: [post],
            falseNext: [out]
          },
          {
            id: post,
            type: 'http',
            name: 'Send',
            config: {
              url: 'https://example.com/replace-me',
              method: 'POST',
              headers: '{"Content-Type": "application/json"}',
              body: '{"text": "{{input}}"}'
            },
            next: [out]
          },
          { id: out, type: 'output', name: 'Result', config: { label: 'Digest' }, next: [] }
        ];
      }
    ),

    // ------------------------------------------------------------------
    wf(
      'Bulk Extract to JSON',
      'Split input into lines, pull structured fields out of each one with a model, and collect the results as an array.',
      ['data', 'offline-capable'],
      () => {
        const t = id(), split = id(), each = id(), ex = id(), out = id();
        return [
          {
            id: t,
            type: 'trigger.manual',
            name: 'Start',
            config: { input: 'Ada Lovelace, 1843, analytical engine notes\nAlan Turing, 1936, computable numbers' },
            next: [split]
          },
          { id: split, type: 'code', name: 'Split', config: { body: 'return String(input).split("\\n").map(s => s.trim()).filter(Boolean);' }, next: [each] },
          {
            id: each,
            type: 'foreach',
            name: 'EachLine',
            config: { maxItems: 10 },
            bodyNext: [ex],
            next: [out]
          },
          { id: ex, type: 'extract', name: 'Extract', config: { schema: 'name, year, work', source: '{{input}}' }, next: [] },
          { id: out, type: 'output', name: 'Result', config: { label: 'Rows' }, next: [] }
        ];
      }
    )
  ];
}
