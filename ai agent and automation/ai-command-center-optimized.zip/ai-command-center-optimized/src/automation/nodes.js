// Node catalogue for the automation engine. This is the n8n-shaped layer:
// a workflow is a graph of typed nodes, each node takes the previous node's
// output as input, and every node type declares its own config fields so the
// builder UI can render a form without hardcoding anything per type.
//
// Design rule kept from the rest of the app: a node never gets a capability
// the equivalent chat tool wouldn't have. The HTTP node is risk-gated, the
// terminal/write tools still route through the same approval modal, and
// Lockdown Mode still cuts all outbound calls.

export const NODE_CATEGORIES = ['Trigger', 'AI', 'Data', 'Logic', 'Integration', 'Workspace'];

export const NODE_TYPES = {
  // ------------------------------------------------------------- triggers
  'trigger.manual': {
    label: 'Manual Trigger',
    category: 'Trigger',
    icon: '▶️',
    isTrigger: true,
    description: 'Runs when you press Run. Optional text becomes the first input.',
    fields: [{ key: 'input', label: 'Starting input', type: 'textarea', placeholder: 'Optional text passed to the first node' }]
  },
  'trigger.schedule': {
    label: 'Schedule',
    category: 'Trigger',
    icon: '⏰',
    isTrigger: true,
    description: 'Runs on a fixed interval while the app is open.',
    fields: [
      { key: 'everyMinutes', label: 'Every N minutes', type: 'number', default: 60 },
      { key: 'input', label: 'Starting input', type: 'textarea' }
    ]
  },
  'trigger.webhook': {
    label: 'Webhook',
    category: 'Trigger',
    icon: '🪝',
    isTrigger: true,
    description:
      'Runs when the app\'s Local API receives a POST to /webhook/<path>. Start the Local API server first ' +
      '(Sidebar → Local API); the request body arrives as the first input.',
    fields: [{ key: 'path', label: 'Webhook path', type: 'text', placeholder: 'my-hook' }]
  },

  // ------------------------------------------------------------------- AI
  llm: {
    label: 'AI Model',
    category: 'AI',
    icon: '🧠',
    description: 'Send a prompt to one free model. Use {{input}} to insert the previous node\'s output.',
    fields: [
      { key: 'system', label: 'System prompt', type: 'textarea', placeholder: 'You are a concise technical summariser.' },
      { key: 'prompt', label: 'Prompt', type: 'textarea', default: '{{input}}' },
      {
        key: 'strength',
        label: 'Route to',
        type: 'select',
        options: ['auto', 'general', 'reasoning', 'code', 'speed', 'long-context', 'structured'],
        default: 'auto',
        hint: 'Picks the best configured free model for that job instead of hardcoding one.'
      },
      { key: 'temperature', label: 'Temperature', type: 'number', default: 0.7 }
    ]
  },
  council: {
    label: 'AI Council',
    category: 'AI',
    icon: '⚖️',
    description:
      'Ask several different free models the same question in parallel, then have one synthesise a single ' +
      'answer that flags where they disagreed. Slower and higher quality than a single model.',
    fields: [
      { key: 'prompt', label: 'Question', type: 'textarea', default: '{{input}}' },
      { key: 'members', label: 'Panel size', type: 'number', default: 3 }
    ]
  },
  agent: {
    label: 'Agent (with tools)',
    category: 'AI',
    icon: '🤖',
    description: 'Run a full agent turn — it can read files, search the repo, run the tool loop. Risky tools still ask for approval.',
    fields: [
      { key: 'agentId', label: 'Agent', type: 'agent-select' },
      { key: 'task', label: 'Task', type: 'textarea', default: '{{input}}' }
    ]
  },
  extract: {
    label: 'Extract Structured Data',
    category: 'AI',
    icon: '🧾',
    description: 'Have a model pull named fields out of unstructured text and return strict JSON.',
    fields: [
      { key: 'schema', label: 'Fields (comma separated)', type: 'text', placeholder: 'title, author, date, sentiment' },
      { key: 'source', label: 'Text', type: 'textarea', default: '{{input}}' }
    ]
  },

  // ----------------------------------------------------------------- data
  research: {
    label: 'Web Research',
    category: 'Data',
    icon: '🔎',
    description: 'Query DuckDuckGo, Wikipedia, Hacker News and arXiv at once. Keyless and free.',
    fields: [
      { key: 'query', label: 'Query', type: 'textarea', default: '{{input}}' },
      {
        key: 'sources',
        label: 'Sources',
        type: 'multiselect',
        options: ['duckduckgo', 'wikipedia', 'hackernews', 'arxiv'],
        default: ['duckduckgo', 'wikipedia', 'hackernews', 'arxiv']
      }
    ]
  },
  readUrl: {
    label: 'Read Page',
    category: 'Data',
    icon: '📄',
    description: 'Fetch a URL and convert it to plain text for the next node.',
    fields: [{ key: 'url', label: 'URL', type: 'text', default: '{{input}}' }]
  },
  rag: {
    label: 'Knowledge Base Query',
    category: 'Data',
    icon: '📚',
    description: 'Retrieve relevant chunks from the RAG index with citations.',
    fields: [
      { key: 'question', label: 'Question', type: 'textarea', default: '{{input}}' },
      { key: 'topK', label: 'Chunks', type: 'number', default: 5 }
    ]
  },

  // ---------------------------------------------------------------- logic
  code: {
    label: 'Transform (JS)',
    category: 'Logic',
    icon: '🧮',
    description:
      'Run a small JavaScript expression over the input. `input` is the previous output, `nodes` is every ' +
      'prior node\'s output by name. Return the new value.',
    fields: [
      {
        key: 'body',
        label: 'Function body',
        type: 'textarea',
        default: '// return anything; it becomes this node\'s output\nreturn String(input).trim();'
      }
    ]
  },
  condition: {
    label: 'If / Else',
    category: 'Logic',
    icon: '🔀',
    description: 'Branch the workflow. Truthy result follows the "true" edge, falsy follows "false".',
    fields: [
      {
        key: 'expression',
        label: 'Condition',
        type: 'textarea',
        default: 'return String(input).length > 0;',
        hint: 'JavaScript. `input` and `nodes` are in scope.'
      }
    ]
  },
  foreach: {
    label: 'For Each',
    category: 'Logic',
    icon: '🔁',
    description: 'Run the downstream branch once per item in an array input, then collect every result.',
    fields: [
      { key: 'maxItems', label: 'Max items', type: 'number', default: 10, hint: 'Guard against a huge array burning your free quota.' }
    ]
  },
  delay: {
    label: 'Wait',
    category: 'Logic',
    icon: '⏳',
    description: 'Pause before the next node. Useful for staying under a free-tier rate limit.',
    fields: [{ key: 'seconds', label: 'Seconds', type: 'number', default: 5 }]
  },

  // ---------------------------------------------------------- integration
  http: {
    label: 'HTTP Request',
    category: 'Integration',
    icon: '🌐',
    description:
      'Call any REST API or webhook — Slack, Discord, Notion, Airtable, Telegram, Home Assistant, your own ' +
      'backend, an n8n instance. This is the "connect to anything" node.',
    fields: [
      { key: 'url', label: 'URL', type: 'text', placeholder: 'https://api.example.com/v1/items' },
      { key: 'method', label: 'Method', type: 'select', options: ['GET', 'POST', 'PUT', 'PATCH', 'DELETE'], default: 'POST' },
      { key: 'headers', label: 'Headers (JSON)', type: 'textarea', placeholder: '{"Content-Type": "application/json"}' },
      { key: 'body', label: 'Body', type: 'textarea', default: '{{input}}' }
    ]
  },
  mcp: {
    label: 'MCP Tool',
    category: 'Integration',
    icon: '🧷',
    description: 'Call a tool on a connected MCP server — reuses whatever MCP connections you set up in MCP Connections.',
    fields: [
      { key: 'connectionId', label: 'Connection ID', type: 'text' },
      { key: 'toolName', label: 'Tool name', type: 'text' },
      { key: 'args', label: 'Arguments (JSON)', type: 'textarea', default: '{}' }
    ]
  },

  // ------------------------------------------------------------ workspace
  tool: {
    label: 'Workspace Tool',
    category: 'Workspace',
    icon: '🛠️',
    description: 'Call any built-in tool directly (read_file, repo_search, scan_secrets, git_diff…). Risky tools still prompt for approval.',
    fields: [
      { key: 'toolName', label: 'Tool', type: 'tool-select' },
      { key: 'args', label: 'Arguments (JSON)', type: 'textarea', default: '{}' }
    ]
  },
  output: {
    label: 'Output',
    category: 'Workspace',
    icon: '📤',
    description: 'Terminal node. Whatever reaches it becomes the workflow result shown in the run log.',
    fields: [{ key: 'label', label: 'Label', type: 'text', default: 'Result' }]
  }
};

export function nodeDef(type) {
  return NODE_TYPES[type] || null;
}

export function defaultConfig(type) {
  const def = nodeDef(type);
  if (!def) return {};
  const cfg = {};
  for (const f of def.fields || []) {
    if (f.default !== undefined) cfg[f.key] = f.default;
  }
  return cfg;
}

export function typesByCategory() {
  const out = {};
  for (const cat of NODE_CATEGORIES) out[cat] = [];
  for (const [type, def] of Object.entries(NODE_TYPES)) {
    (out[def.category] = out[def.category] || []).push({ type, ...def });
  }
  return out;
}
