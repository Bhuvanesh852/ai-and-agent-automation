import { describe, it, expect, vi } from 'vitest';
import { runWorkflow, validateWorkflow, resolveTemplate } from './WorkflowEngine.js';

// The engine takes all of its capabilities as injected deps, so these tests
// use plain fakes — no Electron, no network, no model calls.
function fakeDeps(overrides = {}) {
  return {
    sleep: vi.fn().mockResolvedValue(undefined),
    callModel: vi.fn(async ({ prompt }) => `echo:${prompt}`),
    callCouncil: vi.fn(async () => 'consensus'),
    callAgent: vi.fn(async () => 'agent-done'),
    callTool: vi.fn(async (name) => ({ ok: true, result: `tool:${name}` })),
    callMcp: vi.fn(async () => 'mcp-done'),
    ...overrides
  };
}

const wf = (nodes, extra = {}) => ({ id: 'w1', name: 'test', nodes, startNodeId: nodes[0].id, ...extra });

describe('resolveTemplate', () => {
  it('substitutes input, named nodes and json paths', () => {
    const ctx = { input: { a: { b: 42 } }, byName: { Prev: 'hello' } };
    expect(resolveTemplate('{{node.Prev}}', ctx)).toBe('hello');
    expect(resolveTemplate('{{json.a.b}}', ctx)).toBe('42');
  });

  it('renders an unknown expression as empty rather than leaving the braces in the prompt', () => {
    expect(resolveTemplate('x{{nope}}y', { input: '', byName: {} })).toBe('xy');
  });
});

describe('runWorkflow', () => {
  it('threads output into the next node as input', async () => {
    const deps = fakeDeps();
    const res = await runWorkflow(
      wf([
        { id: 'a', type: 'trigger.manual', name: 'Start', config: { input: 'seed' }, next: ['b'] },
        { id: 'b', type: 'llm', name: 'Model', config: { prompt: '{{input}}!' }, next: ['c'] },
        { id: 'c', type: 'output', name: 'Out', config: {}, next: [] }
      ]),
      deps
    );

    expect(res.ok).toBe(true);
    expect(deps.callModel).toHaveBeenCalledWith(expect.objectContaining({ prompt: 'seed!' }));
    expect(res.output).toBe('echo:seed!');
    expect(res.steps).toHaveLength(3);
  });

  it('lets the run input override the trigger default', async () => {
    const deps = fakeDeps();
    await runWorkflow(
      wf([
        { id: 'a', type: 'trigger.manual', config: { input: 'default' }, next: ['b'] },
        { id: 'b', type: 'llm', name: 'M', config: { prompt: '{{input}}' }, next: [] }
      ]),
      deps,
      { triggerInput: 'override' }
    );
    expect(deps.callModel).toHaveBeenCalledWith(expect.objectContaining({ prompt: 'override' }));
  });

  it('follows the true branch and skips the false branch', async () => {
    const deps = fakeDeps();
    const res = await runWorkflow(
      wf([
        { id: 'a', type: 'trigger.manual', config: { input: 'yes' }, next: ['cond'] },
        { id: 'cond', type: 'condition', name: 'Check', config: { expression: 'return input === "yes";' }, trueNext: ['t'], falseNext: ['f'] },
        { id: 't', type: 'code', name: 'True', config: { body: 'return "TRUE";' }, next: [] },
        { id: 'f', type: 'code', name: 'False', config: { body: 'return "FALSE";' }, next: [] }
      ]),
      deps
    );
    expect(res.output).toBe('TRUE');
    expect(res.steps.some(s => s.nodeName === 'False')).toBe(false);
  });

  it('runs the foreach body once per item and collects results', async () => {
    const deps = fakeDeps();
    const res = await runWorkflow(
      wf([
        { id: 'a', type: 'trigger.manual', config: {}, next: ['split'] },
        { id: 'split', type: 'code', name: 'Split', config: { body: 'return ["x", "y", "z"];' }, next: ['loop'] },
        { id: 'loop', type: 'foreach', name: 'Loop', config: { maxItems: 10 }, bodyNext: ['body'], next: ['out'] },
        { id: 'body', type: 'code', name: 'Body', config: { body: 'return input.toUpperCase();' }, next: [] },
        { id: 'out', type: 'output', name: 'Out', config: {}, next: [] }
      ]),
      deps
    );
    expect(res.output).toEqual(['X', 'Y', 'Z']);
  });

  it('honours the foreach maxItems cap so a huge array cannot burn free-tier quota', async () => {
    const deps = fakeDeps();
    const res = await runWorkflow(
      wf([
        { id: 'a', type: 'trigger.manual', config: {}, next: ['split'] },
        { id: 'split', type: 'code', name: 'Split', config: { body: 'return Array.from({length: 100}, (_, i) => i);' }, next: ['loop'] },
        { id: 'loop', type: 'foreach', name: 'Loop', config: { maxItems: 3 }, bodyNext: ['body'], next: [] },
        { id: 'body', type: 'llm', name: 'Body', config: { prompt: '{{input}}' }, next: [] }
      ]),
      deps
    );
    expect(res.ok).toBe(true);
    expect(deps.callModel).toHaveBeenCalledTimes(3);
  });

  it('records the failing node and stops the run', async () => {
    const deps = fakeDeps({ callModel: vi.fn(async () => { throw new Error('rate limited'); }) });
    const res = await runWorkflow(
      wf([
        { id: 'a', type: 'trigger.manual', config: {}, next: ['b'] },
        { id: 'b', type: 'llm', name: 'Model', config: { prompt: 'hi' }, next: ['c'] },
        { id: 'c', type: 'output', name: 'Out', config: {}, next: [] }
      ]),
      deps
    );
    expect(res.ok).toBe(false);
    expect(res.error).toContain('rate limited');
    expect(res.steps.find(s => s.nodeName === 'Model').status).toBe('error');
    expect(res.steps.some(s => s.nodeName === 'Out')).toBe(false);
  });

  it('stops when cancellation is requested', async () => {
    const deps = fakeDeps();
    let calls = 0;
    const res = await runWorkflow(
      wf([
        { id: 'a', type: 'trigger.manual', config: {}, next: ['b'] },
        { id: 'b', type: 'llm', name: 'M', config: { prompt: 'x' }, next: ['c'] },
        { id: 'c', type: 'llm', name: 'N', config: { prompt: 'y' }, next: [] }
      ]),
      deps,
      { shouldCancel: () => ++calls > 2 }
    );
    expect(res.ok).toBe(false);
    expect(res.cancelled).toBe(true);
  });

  it('breaks out of a cycle instead of hanging', async () => {
    const deps = fakeDeps();
    const res = await runWorkflow(
      wf([
        { id: 'a', type: 'trigger.manual', config: {}, next: ['b'] },
        { id: 'b', type: 'code', name: 'Loop', config: { body: 'return input;' }, next: ['b'] }
      ]),
      deps
    );
    expect(res.ok).toBe(false);
    expect(res.error).toMatch(/exceeded/i);
  });

  it('routes tool nodes through the injected callTool, never around it', async () => {
    const deps = fakeDeps();
    await runWorkflow(
      wf([
        { id: 'a', type: 'trigger.manual', config: {}, next: ['b'] },
        { id: 'b', type: 'tool', name: 'T', config: { toolName: 'scan_secrets', args: '{}' }, next: [] }
      ]),
      deps
    );
    expect(deps.callTool).toHaveBeenCalledWith('scan_secrets', {});
  });
});

describe('validateWorkflow', () => {
  it('flags a missing trigger', () => {
    const res = validateWorkflow({ nodes: [{ id: 'a', type: 'output', next: [] }] });
    expect(res.ok).toBe(false);
    expect(res.problems.join(' ')).toMatch(/trigger/i);
  });

  it('flags a dangling edge', () => {
    const res = validateWorkflow({ nodes: [{ id: 'a', type: 'trigger.manual', name: 'S', next: ['ghost'] }] });
    expect(res.ok).toBe(false);
    expect(res.problems.join(' ')).toMatch(/missing node/i);
  });

  it('accepts a well-formed workflow', () => {
    const res = validateWorkflow({
      nodes: [
        { id: 'a', type: 'trigger.manual', next: ['b'] },
        { id: 'b', type: 'output', next: [] }
      ]
    });
    expect(res.ok).toBe(true);
  });
});
