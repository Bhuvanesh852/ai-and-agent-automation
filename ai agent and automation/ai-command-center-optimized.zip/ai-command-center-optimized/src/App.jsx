import React, { useEffect, useState } from 'react';
import Sidebar from './components/Sidebar.jsx';
import TopBar from './components/TopBar.jsx';
import ChatArea from './components/ChatArea.jsx';
import ContextPanel from './components/ContextPanel.jsx';
import SettingsPanel from './components/SettingsPanel.jsx';
import FilesPanel from './components/FilesPanel.jsx';
import SecurityCenter from './components/SecurityCenter.jsx';
import ModelsPanel from './components/ModelsPanel.jsx';
import RagPanel from './components/RagPanel.jsx';
import LocalApiPanel from './components/LocalApiPanel.jsx';
import RepoPanel from './components/RepoPanel.jsx';
import CommandPalette from './components/CommandPalette.jsx';
import ToolApprovalModal from './components/ToolApprovalModal.jsx';
import ProjectsPanel from './components/ProjectsPanel.jsx';
import MCPPanel from './components/MCPPanel.jsx';
import AutomationsPanel from './components/AutomationsPanel.jsx';
import AgentsPanel from './components/AgentsPanel.jsx';
import LogsPanel from './components/LogsPanel.jsx';
import CouncilPanel from './components/CouncilPanel.jsx';
import Footer from './components/Footer.jsx';
import { useAppStore } from './store/useAppStore.js';

export default function App() {
  const store = useAppStore();
  const [view, setView] = useState('chat');
  const [paletteOpen, setPaletteOpen] = useState(false);

  useEffect(() => {
    store.loadHardwareProfile();
    store.refreshProviderStatus();
    store.loadWorkspace();
    store.loadSecurityState();
    store.loadLocalModels();

    const handler = (e) => {
      if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'k') {
        e.preventDefault();
        setPaletteOpen(o => !o);
      }
    };
    window.addEventListener('keydown', handler);
    return () => window.removeEventListener('keydown', handler);
  }, []);

  return (
    <div className="app-shell">
      <Sidebar activeView={view} onSelect={setView} />
      <TopBar store={store} onOpenPalette={() => setPaletteOpen(true)} />

      <div className="main">
        {view === 'chat' && (
          <>
            <ChatArea store={store} />
            <ContextPanel store={store} />
          </>
        )}
        {view === 'settings' && <SettingsPanel store={store} />}
        {view === 'files' && <FilesPanel store={store} />}
        {view === 'security' && <SecurityCenter store={store} />}
        {view === 'models' && <ModelsPanel store={store} />}
        {view === 'rag' && <RagPanel store={store} />}
        {view === 'localapi' && <LocalApiPanel store={store} />}
        {view === 'repo' && <RepoPanel store={store} />}
        {view === 'projects' && <ProjectsPanel store={store} onOpenProject={() => setView('chat')} />}
        {view === 'mcp' && <MCPPanel store={store} />}
        {view === 'automations' && <AutomationsPanel />}
        {view === 'agents' && <AgentsPanel store={store} />}
        {view === 'council' && <CouncilPanel store={store} />}
        {view === 'logs' && <LogsPanel store={store} />}
        {view === 'tests' && (
          <div className="settings-panel">
            <h2 style={{ marginTop: 0 }}>Tests</h2>
            <p className="hint">
              Not built yet — and deliberately not faked. Test running works today through the QA agent's
              <code>run_tests</code> tool and the Workspace Tool node in Automations; this screen would only be a
              thinner wrapper around those. See README.md → "Extending the app".
            </p>
          </div>
        )}
      </div>

      {paletteOpen && (
        <CommandPalette store={store} onClose={() => setPaletteOpen(false)} onNavigate={setView} />
      )}
      <ToolApprovalModal store={store} />
      <Footer />
    </div>
  );
}
