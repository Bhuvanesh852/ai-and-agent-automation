import { create } from 'zustand';
import { runWorkflow, validateWorkflow } from '../automation/WorkflowEngine.js';
import { buildTemplates } from '../automation/templates.js';
import { defaultConfig } from '../automation/nodes.js';
import { dispatchChat } from '../gateway/ModelGateway.js';
import { pickModel } from '../gateway/registry.js';
import { councilToText } from '../ensemble/council.js';
import { toolByName } from '../agents/tools.js';
import { getAgent } from '../agents/agents.js';
import { runAgentTurn } from '../agents/AgentRuntime.js';
import { useAppStore } from './useAppStore.js';

const MAX_RUNS_KEPT = 50;
const newId = () => (globalThis.crypto?.randomUUID?.() || `w${Math.random().toString(36).slice(2, 10)}`);
const sleep = (ms) => new Promise(r => setTimeout(r, ms));

// Live setInterval handles for schedule triggers, keyed by workflow id. Kept
// out of zustand state on purpose — timer ids aren't renderable data, and
// putting them in state would make every tick a re-render.
const timers = new Map();

/**
 * Build the capability object the engine runs against. Everything the engine
 * can do flows through here, which means the permission/approval/lockdown
 * rules the chat path already enforces apply identically to workflows — a
 * workflow is not a privilege escalation route.
 */
function buildDeps() {
  const app = useAppStore.getState();

  return {
    sleep,

    async callModel({ system, prompt, strength, temperature }) {
      const chosen =
        strength && strength !== 'auto'
          ? pickModel(strength, app.providerStatus)
          : { provider: app.activeProvider, model_id: app.activeModelId };

      const res = await dispatchChat({
        provider: chosen.provider,
        modelId: chosen.model_id,
        messages: [
          ...(system ? [{ role: 'system', content: system }] : []),
          { role: 'user', content: String(prompt ?? '') }
        ],
        fallbackChain: [{ provider: 'offline', model_id: 'offline-assistant' }],
        hints: { creativityMode: temperature >= 0.9 ? 'high' : temperature <= 0.3 ? 'low' : 'medium' },
        requestId: `wf-${newId()}`
      });
      if (!res.ok) throw new Error(res.error || 'Model call failed.');
      return res.content;
    },

    async callCouncil({ prompt, members }) {
      return councilToText({
        prompt: String(prompt ?? ''),
        members,
        providerStatus: useAppStore.getState().providerStatus
      });
    },

    async callAgent({ agentId, task }) {
      const agent = getAgent(agentId);
      const state = useAppStore.getState();
      const messages = [
        { role: 'system', content: agent.systemPrompt },
        { role: 'user', content: String(task ?? '') }
      ];

      const res = await runAgentTurn({
        agent,
        provider: agent.defaultModelPreference.provider,
        modelId: agent.defaultModelPreference.model_id,
        messages,
        requestApproval: state.requestApproval,
        requestId: `wf-agent-${newId()}`,
        onEvent: () => {}
      });

      // The agent's preferred provider may not support tool calling on this
      // machine (no key, or a text-only local model). Degrade to a plain
      // chat turn with the same persona rather than failing the workflow.
      if (res?.unsupported) {
        const fallback = await dispatchChat({
          provider: state.activeProvider,
          modelId: state.activeModelId,
          messages,
          fallbackChain: [{ provider: 'offline', model_id: 'offline-assistant' }],
          requestId: `wf-agent-${newId()}`
        });
        if (!fallback.ok) throw new Error(fallback.error || 'Agent call failed.');
        return fallback.content;
      }
      if (!res?.ok) throw new Error(res?.error || 'Agent call failed.');
      return res.content;
    },

    async callTool(name, args) {
      if (!window.bridge) throw new Error('Tool nodes require the Electron desktop shell.');
      const def = toolByName(name);
      if (!def) throw new Error(`Unknown tool "${name}".`);

      // Same approval checkpoint the agent tool loop uses. A workflow author
      // cannot bypass it by wrapping a risky tool in a node.
      if (def.riskLevel === 'risky') {
        const approved = await useAppStore.getState().requestApproval({
          name,
          args,
          riskLevel: def.riskLevel,
          origin: 'workflow'
        });
        if (!approved) throw new Error(`Tool "${name}" was denied by the user.`);
      }

      const res = await window.bridge.tools.execute(name, args);
      if (res && res.ok === false) throw new Error(typeof res.result === 'string' ? res.result : `Tool "${name}" failed.`);
      return res;
    },

    async callMcp({ connectionId, toolName, args }) {
      if (!window.bridge) throw new Error('MCP nodes require the Electron desktop shell.');
      const res = await window.bridge.mcp.callTool(connectionId, toolName, args);
      if (!res?.ok) throw new Error(res?.error || 'MCP tool call failed.');
      return res.result;
    }
  };
}

export const useAutomationStore = create((set, get) => ({
  workflows: [],
  runs: [],
  activeWorkflowId: null,
  _webhookUnsub: null,
  runningWorkflowId: null,
  liveSteps: [],
  cancelRequested: false,
  loaded: false,

  // ------------------------------------------------------------ lifecycle
  load: async () => {
    let workflows = [];
    let runs = [];
    try {
      workflows = (await window.bridge?.config.get('workflows')) || [];
      runs = (await window.bridge?.config.get('workflowRuns')) || [];
    } catch { /* first run, or no bridge (browser tab) */ }

    if (workflows.length === 0) workflows = buildTemplates();
    set({ workflows, runs, loaded: true, activeWorkflowId: workflows[0]?.id || null });
    get().syncSchedules();
    get().listenForWebhooks();
  },

  // Inbound webhooks arrive from the main process (Local API server). One
  // listener for the whole app: attaching per-workflow would re-register on
  // every edit and fire duplicates.
  listenForWebhooks: () => {
    if (get()._webhookUnsub || !window.bridge?.webhook) return;
    const unsub = window.bridge.webhook.onReceived(({ path, payload }) => {
      const matches = get().workflows.filter(w =>
        w.webhookEnabled && w.nodes?.some(n => n.type === 'trigger.webhook' && n.config?.path === path)
      );
      for (const w of matches) {
        get().run(w.id, typeof payload === 'string' ? payload : JSON.stringify(payload), { source: 'webhook' });
      }
      if (matches.length === 0) {
        useAppStore.getState().pushActivity(`Webhook "${path}" received, but no enabled workflow matches it.`, 'automation');
      }
    });
    set({ _webhookUnsub: unsub });
  },

  toggleWebhook: (workflowId) => {
    const wf = get().workflows.find(w => w.id === workflowId);
    if (!wf) return;
    get().updateWorkflow(workflowId, { webhookEnabled: !wf.webhookEnabled });
  },

  persist: async () => {
    try {
      await window.bridge?.config.set('workflows', get().workflows);
      await window.bridge?.config.set('workflowRuns', get().runs.slice(0, MAX_RUNS_KEPT));
    } catch { /* best effort — a failed save must not break the run */ }
  },

  // ------------------------------------------------------------ authoring
  activeWorkflow: () => get().workflows.find(w => w.id === get().activeWorkflowId) || null,
  setActiveWorkflow: (id) => set({ activeWorkflowId: id, liveSteps: [] }),

  createWorkflow: (name = 'New workflow') => {
    const triggerId = newId();
    const outId = newId();
    const workflow = {
      id: newId(),
      name,
      description: '',
      tags: [],
      startNodeId: triggerId,
      nodes: [
        { id: triggerId, type: 'trigger.manual', name: 'Start', config: defaultConfig('trigger.manual'), next: [outId] },
        { id: outId, type: 'output', name: 'Result', config: defaultConfig('output'), next: [] }
      ],
      createdAt: Date.now(),
      updatedAt: Date.now()
    };
    set(s => ({ workflows: [workflow, ...s.workflows], activeWorkflowId: workflow.id }));
    get().persist();
    return workflow.id;
  },

  updateWorkflow: (id, patch) => {
    set(s => ({
      workflows: s.workflows.map(w => (w.id === id ? { ...w, ...patch, updatedAt: Date.now() } : w))
    }));
    get().persist();
    get().syncSchedules();
  },

  deleteWorkflow: (id) => {
    get().stopSchedule(id);
    set(s => {
      const workflows = s.workflows.filter(w => w.id !== id);
      return { workflows, activeWorkflowId: s.activeWorkflowId === id ? workflows[0]?.id || null : s.activeWorkflowId };
    });
    get().persist();
  },

  duplicateWorkflow: (id) => {
    const src = get().workflows.find(w => w.id === id);
    if (!src) return;
    // Remap every node id so the copy's internal edges point at the copy's
    // own nodes rather than sharing ids with the original.
    const idMap = Object.fromEntries(src.nodes.map(n => [n.id, newId()]));
    const remap = (arr) => (arr || []).map(x => idMap[x]).filter(Boolean);
    const copy = {
      ...src,
      id: newId(),
      name: `${src.name} (copy)`,
      startNodeId: idMap[src.startNodeId],
      nodes: src.nodes.map(n => ({
        ...n,
        id: idMap[n.id],
        next: remap(n.next),
        trueNext: remap(n.trueNext),
        falseNext: remap(n.falseNext),
        bodyNext: remap(n.bodyNext)
      })),
      createdAt: Date.now(),
      updatedAt: Date.now()
    };
    set(s => ({ workflows: [copy, ...s.workflows], activeWorkflowId: copy.id }));
    get().persist();
  },

  addNode: (workflowId, type, afterNodeId) => {
    const wf = get().workflows.find(w => w.id === workflowId);
    if (!wf) return;
    const node = { id: newId(), type, name: '', config: defaultConfig(type), next: [] };
    const nodes = wf.nodes.map(n => {
      if (n.id !== afterNodeId) return n;
      // Splice in: the new node inherits the old node's outgoing edges.
      node.next = [...(n.next || [])];
      return { ...n, next: [node.id] };
    });
    get().updateWorkflow(workflowId, { nodes: [...nodes, node] });
  },

  updateNode: (workflowId, nodeId, patch) => {
    const wf = get().workflows.find(w => w.id === workflowId);
    if (!wf) return;
    get().updateWorkflow(workflowId, {
      nodes: wf.nodes.map(n => (n.id === nodeId ? { ...n, ...patch } : n))
    });
  },

  removeNode: (workflowId, nodeId) => {
    const wf = get().workflows.find(w => w.id === workflowId);
    if (!wf) return;
    const victim = wf.nodes.find(n => n.id === nodeId);
    const inherited = victim?.next || [];
    const strip = (arr) => (arr || []).flatMap(x => (x === nodeId ? inherited : [x]));
    get().updateWorkflow(workflowId, {
      nodes: wf.nodes
        .filter(n => n.id !== nodeId)
        .map(n => ({
          ...n,
          next: strip(n.next),
          trueNext: strip(n.trueNext),
          falseNext: strip(n.falseNext),
          bodyNext: strip(n.bodyNext)
        }))
    });
  },

  // -------------------------------------------------------------- running
  run: async (workflowId, triggerInput, { source = 'manual' } = {}) => {
    const wf = get().workflows.find(w => w.id === workflowId);
    if (!wf) return null;
    if (get().runningWorkflowId) {
      // One at a time. Concurrent runs against the same workspace would
      // interleave file writes and burn parallel free-tier quota.
      return null;
    }

    const check = validateWorkflow(wf);
    if (!check.ok) {
      const failed = { ok: false, runId: newId(), workflowId, workflowName: wf.name, error: check.problems.join(' '), steps: [], source, finishedAt: Date.now(), durationMs: 0 };
      set(s => ({ runs: [failed, ...s.runs].slice(0, MAX_RUNS_KEPT) }));
      get().persist();
      return failed;
    }

    set({ runningWorkflowId: workflowId, liveSteps: [], cancelRequested: false });
    useAppStore.getState().pushActivity(`Workflow started: ${wf.name} (${source})`, 'automation');

    const result = await runWorkflow(wf, buildDeps(), {
      triggerInput,
      onStep: (step) => set(s => ({ liveSteps: [...s.liveSteps, step] })),
      shouldCancel: () => get().cancelRequested
    });

    const record = { ...result, source, workflowName: wf.name };
    set(s => ({ runs: [record, ...s.runs].slice(0, MAX_RUNS_KEPT), runningWorkflowId: null, cancelRequested: false }));
    get().persist();

    useAppStore
      .getState()
      .pushActivity(
        result.ok ? `Workflow finished: ${wf.name}` : `Workflow failed: ${wf.name} — ${result.error}`,
        'automation'
      );
    return record;
  },

  cancelRun: () => set({ cancelRequested: true }),
  clearRuns: () => {
    set({ runs: [] });
    get().persist();
  },

  // ------------------------------------------------------------ schedules
  // Timers only live while the app is open. That's a real limitation, not a
  // bug to paper over: a desktop app with no background service cannot fire a
  // schedule when it isn't running, and the UI says so rather than implying
  // cron-like reliability.
  syncSchedules: () => {
    for (const wf of get().workflows) {
      const trigger = wf.nodes?.find(n => n.type === 'trigger.schedule');
      const shouldRun = !!trigger && wf.scheduleEnabled;
      const running = timers.has(wf.id);
      if (shouldRun && !running) {
        const minutes = Math.max(1, Number(trigger.config?.everyMinutes || 60));
        timers.set(
          wf.id,
          setInterval(() => get().run(wf.id, undefined, { source: 'schedule' }), minutes * 60 * 1000)
        );
      } else if (!shouldRun && running) {
        get().stopSchedule(wf.id);
      }
    }
  },

  stopSchedule: (workflowId) => {
    const t = timers.get(workflowId);
    if (t) {
      clearInterval(t);
      timers.delete(workflowId);
    }
  },

  toggleSchedule: (workflowId) => {
    const wf = get().workflows.find(w => w.id === workflowId);
    if (!wf) return;
    get().updateWorkflow(workflowId, { scheduleEnabled: !wf.scheduleEnabled });
  },

  isScheduled: (workflowId) => timers.has(workflowId),

  // -------------------------------------------------------- import/export
  exportWorkflow: (id) => {
    const wf = get().workflows.find(w => w.id === id);
    return wf ? JSON.stringify(wf, null, 2) : '';
  },

  importWorkflow: (json) => {
    let parsed;
    try {
      parsed = JSON.parse(json);
    } catch {
      return { ok: false, error: 'That is not valid JSON.' };
    }
    if (!parsed?.nodes || !Array.isArray(parsed.nodes)) {
      return { ok: false, error: 'Missing a "nodes" array — this does not look like a workflow export.' };
    }
    const workflow = { ...parsed, id: newId(), createdAt: Date.now(), updatedAt: Date.now(), scheduleEnabled: false };
    const check = validateWorkflow(workflow);
    set(s => ({ workflows: [workflow, ...s.workflows], activeWorkflowId: workflow.id }));
    get().persist();
    return { ok: true, problems: check.problems };
  },

  restoreTemplates: () => {
    set(s => ({ workflows: [...buildTemplates(), ...s.workflows] }));
    get().persist();
  }
}));
