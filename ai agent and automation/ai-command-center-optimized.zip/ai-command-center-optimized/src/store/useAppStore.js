import { create } from 'zustand';
import { AGENTS, getAgent } from '../agents/agents.js';
import { dispatchChat, dispatchHybrid, buildDefaultFallbackChain } from '../gateway/ModelGateway.js';
import { runAgentTurn, providerSupportsTools, agentHasTools } from '../agents/AgentRuntime.js';

const REALTIME_HINT_RE = /\b(today|latest|current|currently|news|update|stock|price|weather|right now)\b/i;

function formatToolResult(result) {
  if (typeof result === 'string') return result.slice(0, 500);
  try {
    return JSON.stringify(result).slice(0, 500);
  } catch {
    return String(result).slice(0, 500);
  }
}

export const useAppStore = create((set, get) => ({
  activeAgentId: AGENTS[0].id,
  // Default provider is the real, zero-setup Offline Brain (no API key, no
  // model download, no network) rather than the canned Demo adapter — see
  // src/gateway/adapters/offlineBrain.js. Switching agents still moves to
  // that agent's preferred provider (setActiveAgent below); this default
  // only governs first launch / the Generative-agent-agnostic case.
  activeProvider: 'offline',
  activeModelId: 'offline-assistant',
  providerStatus: {},
  hardwareProfile: null,
  lowResourceMode: false,
  messages: [],
  activity: [],
  isGenerating: false,
  activeGenerationId: null,
  isPlanRunning: false,

  workspaceRoot: null,
  pendingApproval: null, // { name, args, riskLevel, resolve }

  localModels: [],
  localModelsDir: null,

  lockdownMode: false,
  stopAllActive: false,
  auditLog: [],
  securityFindings: { secrets: null, dependencies: null, network: null, lastScanAt: null },

  setActiveAgent: (id) => {
    const agent = getAgent(id);
    set({
      activeAgentId: id,
      activeProvider: agent.defaultModelPreference.provider,
      activeModelId: agent.defaultModelPreference.model_id
    });
    get().pushActivity(`Switched to agent: ${agent.name}`);
  },

  setActiveModel: (provider, modelId) => {
    set({ activeProvider: provider, activeModelId: modelId });
    get().pushActivity(`Switched model: ${provider}/${modelId}`);
  },

  pushActivity: (text, category = 'general') => {
    set(s => ({
      activity: [...s.activity, { id: crypto.randomUUID(), text, ts: Date.now() }].slice(-200)
    }));
    // Mirror into the persistent, redaction-safe audit log (main process
    // caps message length and never receives raw file/tool content here —
    // callers only ever pass short summaries).
    window.bridge?.security?.auditAppend({ category, message: text });
  },

  loadSecurityState: async () => {
    if (!window.bridge?.security) return;
    const [lockdown, stopAll, auditLog] = await Promise.all([
      window.bridge.security.getLockdown(),
      window.bridge.security.getStopAll(),
      window.bridge.security.auditGet()
    ]);
    set({ lockdownMode: lockdown, stopAllActive: stopAll, auditLog });
  },

  toggleLockdown: async () => {
    const next = !get().lockdownMode;
    await window.bridge.security.setLockdown(next);
    set({ lockdownMode: next });
    get().pushActivity(next ? '🔒 Lockdown Mode ENABLED — external network calls and privileged tools disabled.' : '🔓 Lockdown Mode disabled.', 'security');
  },

  setStopAll: async (enabled) => {
    await window.bridge.security.setStopAll(enabled);
    set({ stopAllActive: enabled });
    get().pushActivity(enabled ? '🛑 STOP ALL AGENTS triggered.' : '▶️ Agents resumed.', 'security');
  },

  runSecurityScan: async (scope = 'quick') => {
    get().pushActivity(`Security Center: running ${scope} scan…`, 'security');
    const secretsRes = await window.bridge.security.scanSecrets();
    let depsRes = { ok: true, result: null };
    let networkRes = { ok: true, result: null };
    if (scope !== 'quick') {
      depsRes = await window.bridge.security.scanDependencies();
      networkRes = await window.bridge.security.scanNetwork();
    }
    set({
      securityFindings: {
        secrets: secretsRes.ok ? secretsRes.result : { error: secretsRes.result },
        dependencies: depsRes.ok ? depsRes.result : { error: depsRes.result },
        network: networkRes.ok ? networkRes.result : { error: networkRes.result },
        lastScanAt: Date.now()
      }
    });
    get().pushActivity(`Security Center: ${scope} scan complete.`, 'security');
  },

  loadHardwareProfile: async () => {
    if (!window.bridge) return;
    const profile = await window.bridge.system.hardwareProfile();
    set({ hardwareProfile: profile, lowResourceMode: profile.recommendedMode === 'low-resource' });
  },

  refreshProviderStatus: async () => {
    if (!window.bridge) return;
    const status = await window.bridge.creds.status();
    set({ providerStatus: status });
  },

  loadWorkspace: async () => {
    if (!window.bridge) return;
    const root = await window.bridge.workspace.current();
    set({ workspaceRoot: root });
  },

  loadLocalModels: async () => {
    if (!window.bridge?.localModel) return;
    const res = await window.bridge.localModel.list();
    if (res.ok) {
      set({ localModels: res.models, localModelsDir: res.modelsDir });
    }
  },

  selectWorkspace: async () => {
    const root = await window.bridge.workspace.select();
    if (root) {
      set({ workspaceRoot: root });
      get().pushActivity(`Opened workspace folder: ${root}`);
    }
    return root;
  },

  // Called by AgentRuntime when a risky tool needs a human decision.
  // Resolves once resolveApproval(true/false) is called from the UI.
  requestApproval: (toolCall) => {
    return new Promise((resolve) => {
      set({ pendingApproval: { ...toolCall, resolve } });
    });
  },
  resolveApproval: (approved) => {
    const pending = get().pendingApproval;
    if (!pending) return;
    set({ pendingApproval: null });
    pending.resolve(approved);
  },

  sendMessage: async (userText, { fromPlan = false } = {}) => {
    const state = get();
    if (state.isPlanRunning && !fromPlan) {
      get().pushActivity('Blocked a new request: Plan Mode is currently running. Wait for it to finish or cancel it first.', 'security');
      return;
    }
    if (state.stopAllActive) {
      get().pushActivity('Blocked a new request: STOP ALL AGENTS is active. Resume from the Security Center first.', 'security');
      set(s => ({
        messages: [...s.messages,
          { id: crypto.randomUUID(), role: 'user', content: userText, agentId: state.activeAgentId },
          { id: crypto.randomUUID(), role: 'assistant', content: '🛑 Agents are stopped. Resume from Security Center → STOP ALL AGENTS to continue.', agentId: state.activeAgentId }
        ]
      }));
      return;
    }
    const agent = getAgent(state.activeAgentId);
    const userMsg = { id: crypto.randomUUID(), role: 'user', content: userText, agentId: agent.id };
    const genId = crypto.randomUUID();
    set(s => ({ messages: [...s.messages, userMsg], isGenerating: true, activeGenerationId: genId }));
    const shouldCancel = () => get().activeGenerationId !== genId;
    get().pushActivity(`${agent.name} received a request`);

    const priorTurns = get().messages
      .filter(m => m.role === 'user' || m.role === 'assistant')
      .map(m => ({ role: m.role, content: m.content }));

    const history = [{ role: 'system', content: agent.systemPrompt }, ...priorTurns];
    if (agentHasTools(agent) && REALTIME_HINT_RE.test(userText)) {
      history.splice(1, 0, { role: 'system', content: 'This request may need up-to-date information — consider using the web_search tool before answering, if you have it available.' });
    }

    const canUseTools = providerSupportsTools(state.activeProvider) && agentHasTools(agent);

    const assistantId = crypto.randomUUID();
    set(s => ({
      messages: [...s.messages, { id: assistantId, role: 'assistant', content: '', agentId: agent.id, streaming: true }]
    }));

    if (canUseTools) {
      let result;
      try {
        result = await runAgentTurn({
        agent,
        provider: state.activeProvider,
        modelId: state.activeModelId,
        messages: history,
        requestApproval: get().requestApproval,
        shouldCancel,
        requestId: genId,
        onEvent: (evt) => {
          if (evt.type === 'tool_call_proposed') {
            get().pushActivity(`${agent.name} proposed tool: ${evt.tool}(${JSON.stringify(evt.args)})`, 'security');
            set(s => ({
              messages: [...s.messages, {
                id: crypto.randomUUID(), role: 'tool', content: `Proposed: ${evt.tool}(${JSON.stringify(evt.args)})`, agentId: agent.id
              }]
            }));
          }
          if (evt.type === 'tool_call_denied') {
            get().pushActivity(`Tool call denied: ${evt.tool}`, 'security');
          }
          if (evt.type === 'tool_result') {
            get().pushActivity(`Tool ${evt.tool} ${evt.ok ? 'succeeded' : 'failed'}`, 'security');
            set(s => ({
              messages: [...s.messages, {
                id: crypto.randomUUID(),
                role: 'tool',
                content: `${evt.ok ? '✅' : '⚠️'} ${evt.tool} → ${formatToolResult(evt.result)}`,
                agentId: agent.id
              }]
            }));
          }
        }
        });
      } catch (err) {
        // Last-resort safety net: even though the tool loop itself no longer
        // throws, this guarantees the streaming placeholder is always
        // resolved instead of hanging forever if something unexpected slips
        // through (e.g. a bug in a future tool or adapter).
        result = { ok: false, error: String(err?.message || err) };
      }

      set(s => ({
        messages: s.messages.map(m => m.id === assistantId
          ? {
              ...m,
              content: result.ok ? result.content : `⚠️ ${result.error || 'Tool-using request failed.'}`,
              streaming: false,
              providerUsed: state.activeProvider,
              modelUsed: state.activeModelId
            }
          : m),
        isGenerating: shouldCancel() ? s.isGenerating : false
      }));
      if (!result.cancelled) {
        get().pushActivity(`${agent.name} completed a tool-using response via ${state.activeProvider}/${state.activeModelId}`);
      }
      return;
    }

    // Plain chat path (no tools): existing gateway with fallback chain.
    const fallbackChain = buildDefaultFallbackChain(state.activeProvider);
    const hints = {
      reasoningMode: state.reasoningMode,
      creativityMode: state.creativityMode,
      safetyFilterOn: state.safetyFilterOn
    };

    // Model Merge = "hybrid": fan out to a second model and show both,
    // instead of the normal single-answer + fallback-chain path.
    if (state.modelMerge === 'hybrid') {
      const secondary = fallbackChain[0] || { provider: 'offline', model_id: 'offline-assistant' };
      const { a, b } = await dispatchHybrid({
        primary: { provider: state.activeProvider, model_id: state.activeModelId },
        secondary,
        messages: history,
        hints,
        requestId: genId
      });
      if (shouldCancel()) return;
      const merged = [
        `**${a.providerUsed}/${a.modelUsed}:**\n${a.ok ? a.content : `⚠️ ${a.error}`}`,
        `**${b.providerUsed}/${b.modelUsed}:**\n${b.ok ? b.content : `⚠️ ${b.error}`}`
      ].join('\n\n---\n\n');
      set(s => ({
        messages: s.messages.map(m => m.id === assistantId
          ? { ...m, content: merged, streaming: false, providerUsed: `${a.providerUsed}+${b.providerUsed}`, modelUsed: 'hybrid' }
          : m),
        isGenerating: false
      }));
      get().pushActivity(`${agent.name} completed a Hybrid (model-merge) response via ${a.providerUsed} + ${b.providerUsed}`);
      return;
    }

    const result = await dispatchChat({
      provider: state.activeProvider,
      modelId: state.activeModelId,
      messages: history,
      fallbackChain,
      requestId: genId,
      hints,
      onStreamToken: (token) => {
        if (shouldCancel()) return;
        set(s => ({
          messages: s.messages.map(m => m.id === assistantId ? { ...m, content: m.content + token } : m)
        }));
      }
    });

    if (shouldCancel()) return; // a newer generation (or a cancel) has already taken over the UI

    set(s => ({
      messages: s.messages.map(m => m.id === assistantId
        ? {
            ...m,
            content: result.ok ? (result.content || m.content) : `⚠️ ${result.error || 'Request failed.'}`,
            streaming: false,
            providerUsed: result.providerUsed,
            modelUsed: result.modelUsed,
            fellBack: !!result.fellBackFrom
          }
        : m)
      , isGenerating: false
    }));

    if (result.fellBackFrom) {
      get().pushActivity(`Fell back from ${result.fellBackFrom.provider}/${result.fellBackFrom.model_id} to ${result.providerUsed}/${result.modelUsed}`);
    }
    if (state.debugMode) {
      get().pushActivity(`[debug] provider=${result.providerUsed} model=${result.modelUsed} hints=${JSON.stringify(hints)}`, 'general');
    }
    get().pushActivity(`${agent.name} completed a response via ${result.providerUsed}/${result.modelUsed}`);
  },

  cancelGeneration: () => {
    const genId = get().activeGenerationId;
    if (!genId) return;
    // Actually abort the in-flight network call in the main process — not
    // just the UI state. Without this, Stop only stops the UI from updating
    // while the real request (and provider quota/time) keeps running.
    window.bridge?.request?.cancel(genId);
    set({ activeGenerationId: null, isGenerating: false });
    set(s => ({
      messages: s.messages.map(m => (m.streaming ? { ...m, content: m.content || '⏹ Cancelled.', streaming: false } : m))
    }));
    get().pushActivity('Generation cancelled by user.');
  },

  runPlan: async (goal) => {
    const state = get();
    if (state.stopAllActive) {
      get().pushActivity('Blocked Plan Mode: STOP ALL AGENTS is active.', 'security');
      return;
    }
    if (state.isPlanRunning) {
      get().pushActivity('Blocked Plan Mode: a plan is already running.', 'security');
      return;
    }
    if (state.isGenerating) {
      get().pushActivity('Blocked Plan Mode: a message is already generating.', 'security');
      return;
    }
    set({ isPlanRunning: true });
    try {
      await get()._runPlanInner(goal);
    } finally {
      set({ isPlanRunning: false });
    }
  },

  // Internal — the actual plan body, split out so runPlan can guarantee
  // isPlanRunning is always cleared (even on error) via try/finally above.
  _runPlanInner: async (goal) => {
    const state = get();
    const agent = getAgent(state.activeAgentId);
    get().pushActivity(`Plan Mode: planning "${goal.slice(0, 80)}"`);

    // 1. PLAN — one plain (no-tool) call asking for a short numbered plan.
    const planRes = await dispatchChat({
      provider: state.activeProvider,
      modelId: state.activeModelId,
      messages: [
        { role: 'system', content: 'Respond with ONLY a JSON array of 2-6 short, concrete step strings needed to accomplish the user\'s goal. No prose, no markdown fencing.' },
        { role: 'user', content: goal }
      ],
      fallbackChain: buildDefaultFallbackChain(state.activeProvider)
    });

    let steps;
    try {
      const match = (planRes.content || '').match(/\[[\s\S]*\]/);
      steps = JSON.parse(match ? match[0] : planRes.content);
      if (!Array.isArray(steps) || steps.length === 0) throw new Error('empty');
    } catch {
      get().pushActivity('Plan Mode: could not parse a plan — falling back to a single direct step.', 'security');
      steps = [goal];
    }

    set(s => ({ messages: [...s.messages, { id: crypto.randomUUID(), role: 'tool', content: `📋 Plan:\n${steps.map((s2, i) => `${i + 1}. ${s2}`).join('\n')}`, agentId: agent.id }] }));

    // 2. EXECUTE — run each step through the normal tool-enabled turn.
    for (let i = 0; i < steps.length; i++) {
      if (get().stopAllActive) break;
      get().pushActivity(`Plan Mode: executing step ${i + 1}/${steps.length}`);
      await get().sendMessage(`(Plan step ${i + 1}/${steps.length}) ${steps[i]}`, { fromPlan: true });
    }

    // 3. VERIFY — ask the agent to check its own work (tests if it has them).
    get().pushActivity('Plan Mode: verifying');
    await get().sendMessage(
      'Verify the plan above actually succeeded: if this project has tests, discover and run them and report pass/fail; otherwise review what changed and state clearly whether the original goal was met. If anything failed, describe exactly what failed.',
      { fromPlan: true }
    );

    const lastMsg = [...get().messages].reverse().find(m => m.role === 'assistant');
    const looksFailed = /\bfail|error|did not|broken|unsuccessful/i.test(lastMsg?.content || '');

    // 4. REPAIR — one bounded retry if verification looks like a failure.
    if (looksFailed) {
      get().pushActivity('Plan Mode: verification indicated a failure — attempting one repair pass.', 'security');
      await get().sendMessage('The verification above indicates a failure. Fix exactly that issue, then briefly confirm the fix.', { fromPlan: true });
    } else {
      get().pushActivity('Plan Mode: verification passed.', 'security');
    }
  },

  clearChat: () => set({ messages: [] }),

  // --- Advanced generation toggles (Section 5 of the UI spec) -------------
  // These are real generation hints threaded through to the gateway/agent
  // runtime (see ModelGateway.dispatchChat's `hints` param), not decorative
  // switches — reasoningMode/creativityMode adjust temperature and the
  // system-prompt framing; safetyFilter toggles the agent's content-policy
  // preamble; debugMode surfaces raw provider/tool payloads in Activity;
  // modelMerge ('hybrid') fans a prompt out to two enabled models and shows
  // both replies side by side for comparison instead of picking one.
  reasoningMode: 'balanced', // 'fast' | 'balanced' | 'deep'
  creativityMode: 'medium', // 'low' | 'medium' | 'high'
  safetyFilterOn: true,
  debugMode: false,
  modelMerge: 'single', // 'single' | 'hybrid'
  setReasoningMode: (v) => set({ reasoningMode: v }),
  setCreativityMode: (v) => set({ creativityMode: v }),
  toggleSafetyFilter: () => set(s => ({ safetyFilterOn: !s.safetyFilterOn })),
  toggleDebugMode: () => set(s => ({ debugMode: !s.debugMode })),
  setModelMerge: (v) => set({ modelMerge: v }),

  // --- Feedback (thumbs + star rating/comment) -----------------------------
  feedbackLog: [],
  rateMessage: (messageId, rating) => {
    set(s => ({ messages: s.messages.map(m => m.id === messageId ? { ...m, rating } : m) }));
    get().pushActivity(`Feedback: ${rating > 0 ? '👍' : '👎'} on a response`, 'feedback');
  },
  submitFeedback: async ({ stars, comment }) => {
    const entry = { id: crypto.randomUUID(), stars, comment, ts: Date.now() };
    set(s => ({ feedbackLog: [...s.feedbackLog, entry].slice(-200) }));
    try {
      const existing = (await window.bridge?.config.get('feedbackLog')) || [];
      await window.bridge?.config.set('feedbackLog', [...existing, entry].slice(-500));
    } catch { /* best-effort persistence */ }
    get().pushActivity(`Feedback submitted: ${stars}★`, 'feedback');
  },

  // --- Export / edit-prompt helpers for the Feature Buttons panel ---------
  exportChat: (format) => {
    const messages = get().messages;
    if (format === 'json') return JSON.stringify(messages, null, 2);
    if (format === 'markdown') {
      return messages.map(m => `**${m.role}**: ${m.content || ''}`).join('\n\n');
    }
    if (format === 'csv') {
      const esc = (s) => `"${String(s || '').replace(/"/g, '""')}"`;
      return ['role,content,timestamp', ...messages.map(m => `${esc(m.role)},${esc(m.content)},${esc(m.ts || '')}`)].join('\n');
    }
    return '';
  },
  lastUserMessage: () => [...get().messages].reverse().find(m => m.role === 'user')?.content || '',

  // --- Projects dashboard (Section 6) — persisted through electron-store ---
  projects: [],
  loadProjects: async () => {
    try {
      const projects = (await window.bridge?.config.get('projects')) || [];
      set({ projects });
    } catch { /* not running in the desktop shell yet */ }
  },
  createProject: async ({ title, description, category }) => {
    const project = { id: crypto.randomUUID(), title, description, category, updatedAt: Date.now() };
    const projects = [project, ...get().projects];
    set({ projects });
    await window.bridge?.config.set('projects', projects);
    return project;
  },
  updateProject: async (id, patch) => {
    const projects = get().projects.map(p => p.id === id ? { ...p, ...patch, updatedAt: Date.now() } : p);
    set({ projects });
    await window.bridge?.config.set('projects', projects);
  },
  deleteProject: async (id) => {
    const projects = get().projects.filter(p => p.id !== id);
    set({ projects });
    await window.bridge?.config.set('projects', projects);
  }
}));
