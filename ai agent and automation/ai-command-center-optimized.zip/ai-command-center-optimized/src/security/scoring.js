import { AGENTS } from '../agents/agents.js';

const SEVERITY_WEIGHT = { Critical: 25, High: 12, Medium: 5, Low: 2, Informational: 0 };

export function severityCounts(items = [], key = 'severity') {
  const counts = { Critical: 0, High: 0, Medium: 0, Low: 0 };
  for (const item of items) {
    const sev = item[key];
    if (counts[sev] !== undefined) counts[sev]++;
  }
  return counts;
}

export function computeAgentPermissionRisks() {
  // Real check against the agent registry: an agent that can execute
  // commands or write files with NO approval gate at all would be a
  // genuine finding. Currently every agent that has either capability
  // requires approval, so this legitimately reports zero — it's not a
  // placeholder, it reflects the actual permission profiles below.
  const risks = [];
  for (const agent of AGENTS) {
    const p = agent.permissionProfile;
    if (!p) {
      risks.push({ agent: agent.name, severity: 'Medium', reason: 'No explicit permission profile declared.' });
      continue;
    }
    if (p.executeCommands === true) {
      risks.push({ agent: agent.name, severity: 'Critical', reason: 'Can execute commands with no approval gate.' });
    }
    if (p.writeFiles === true && p.deleteFiles === true) {
      risks.push({ agent: agent.name, severity: 'Medium', reason: 'Has unconditional write + delete file access.' });
    }
    if (p.credentialManagement === true) {
      risks.push({ agent: agent.name, severity: 'High', reason: 'Has direct credential management access.' });
    }
  }
  return risks;
}

export function computeScore({ secretFindings = [], dependencyFindings = [], networkFindings = [], permissionRisks = [] }) {
  const all = [
    ...secretFindings.map(f => ({ severity: f.severity })),
    ...dependencyFindings.map(f => ({ severity: f.severity })),
    ...networkFindings.map(f => ({ severity: f.severity })),
    ...permissionRisks.map(f => ({ severity: f.severity }))
  ];
  let score = 100;
  for (const item of all) {
    score -= SEVERITY_WEIGHT[item.severity] || 0;
  }
  score = Math.max(0, Math.min(100, score));
  return { score, counts: severityCounts(all) };
}
