# AI Command Center

A multi-model, multi-agent desktop AI workspace built with Electron + React. Runs offline in Demo Mode with no API key, and upgrades as you add your own free-tier or paid API keys.

**Supports:** Ollama (local), Groq, Google Gemini, OpenRouter, OpenAI, Anthropic, and custom HTTP endpoints.

## Quick Start

```bash
npm install
npm run dev        # Hot-reload dev (Vite + Electron)
npm run build:win  # Build Windows installer → release/
```

**Note:** First `npm install` fetches `node-llama-cpp` for local GGUF inference — may take longer than usual.

## Get Free Model Access

### 1. Ollama (Local, Zero Cost)
- Download: https://ollama.com/download
- `ollama pull llama3.2:3b` or `ollama pull qwen2.5:7b`
- App auto-detects models in Settings

### 2. Groq (Cloud, Generous Free Tier)
- Get key: https://console.groq.com/keys
- Add in Settings → Groq

### 3. Google Gemini (Free Tier, Huge Context)
- Get key: https://aistudio.google.com/app/apikey
- Add in Settings → Google

### 4. Other Providers
- **OpenRouter** (free model pool): https://openrouter.ai
- **OpenAI** (trial credits): https://platform.openai.com
- **Anthropic** (free tier via OpenRouter)

## Features

### Core
- **Demo Mode** – Explore UI with no setup required
- **Multi-Model** – Run multiple models in parallel, compare outputs
- **Agents** – Autonomous workflows with tools (web search, file access, HTTP requests)
- **Internet Access** – Search via DuckDuckGo, Wikipedia, Hacker News, arXiv
- **Streaming** – Real-time token output, no wait for full response
- **History** – Persistent chat memory

### Advanced
- **Ensembling** – Panel mode runs 3 models, surfaces disagreement → real uncertainty detection
- **Vision** – Image analysis with Claude, GPT-4, Gemini
- **Code Execution** – Run JavaScript/Node.js code safely in sandbox
- **Workspace** – Organize chats by project
- **Export** – Save conversations as JSON or Markdown

## Architecture

```
├── electron/         # Electron main process, native integrations
├── src/
│   ├── components/   # React UI
│   ├── pages/        # Chat, Settings, Agents
│   ├── lib/          # Core logic (models, streaming, memory)
│   └── styles/       # CSS
├── shared/           # Shared utilities
├── package.json      # Dependencies
├── vite.config.js    # Build config
└── jsconfig.json     # Path aliases
```

## Models

| Provider | Free Tier | Best For |
|----------|-----------|----------|
| **Ollama** | ✅ Local | Code, reasoning (with 7B+ models) |
| **Groq** | ✅ Cloud | Fast inference, chat |
| **Google Gemini** | ✅ Cloud | Long context (1M tokens) |
| **OpenRouter** | ✅ Free pool | Access many models one key |
| **OpenAI** | Trial | GPT-4 vision, latest models |
| **Anthropic** | Via OpenRouter | Claude models |

## Development

- **Vite** – Fast HMR during dev
- **ESLint** – Code linting
- **Vitest** – Unit testing

```bash
npm run lint         # Check code style
npm run test         # Run tests
npm run build:win    # Create installer (Windows only)
```

## Settings

Open **Settings** to:
- Add/remove provider API keys
- Select default model for each provider
- Toggle features (streaming, web search, vision)
- Configure Ollama connection
- Manage workspaces

## Privacy

- **Demo Mode** runs entirely locally, no external calls
- API calls only sent to configured providers
- No telemetry, no account signup required
- Workspace data stored locally in `~/.config/ai-command-center/` (or Windows equivalent)

## Troubleshooting

**"Model not found"** → Download via Ollama or add provider key in Settings

**Slow startup** → First run compiles node-llama-cpp; subsequent runs are fast

**Out of memory** → Use smaller models (llama3.2:3b) or switch to cloud (Groq, Gemini)

**HTTP tool fails** → Check CORS/network; loopback/private IPs blocked for security

## License

MIT

## Quick Links

- **Ollama**: https://ollama.com/download
- **Groq Console**: https://console.groq.com/keys
- **Google AI Studio**: https://aistudio.google.com/app/apikey
- **OpenRouter**: https://openrouter.ai
